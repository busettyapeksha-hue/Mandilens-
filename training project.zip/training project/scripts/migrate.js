import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import pg from 'pg';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function runMigrations() {
  console.log('[Migration] Connecting to Supabase PostgreSQL in ap-northeast-1...');
  const client = new pg.Client({
    host: 'aws-0-ap-northeast-1.pooler.supabase.com',
    port: 5432,
    user: 'postgres.xgxtnevljlzjpmufzziy',
    password: 'Apeksha@270908',
    database: 'postgres',
    ssl: { rejectUnauthorized: false }
  });

  try {
    await client.connect();
    console.log('[Migration] Connected successfully to Supabase PostgreSQL database!');

    const migration1Path = path.join(__dirname, '..', 'supabase', 'migrations', '20261027000001_create_mandilens_schema.sql');
    const migration2Path = path.join(__dirname, '..', 'supabase', 'migrations', '20261027000002_rls_and_security.sql');

    console.log('[Migration] Executing Migration 1: Schema creation...');
    const sql1 = fs.readFileSync(migration1Path, 'utf8');
    await client.query(sql1);
    console.log('[Migration] Schema migration applied successfully!');

    console.log('[Migration] Executing Migration 2: RLS and Security policies...');
    const sql2 = fs.readFileSync(migration2Path, 'utf8');
    await client.query(sql2);
    console.log('[Migration] RLS & Security policies applied successfully!');

    // Verify all created tables
    const res = await client.query(`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      ORDER BY table_name;
    `);
    console.log('[Migration] Tables successfully verified in Supabase:');
    res.rows.forEach(r => console.log('  ✓', r.table_name));

  } catch (err) {
    console.error('[Migration] Migration error:', err.message);
  } finally {
    await client.end();
  }
}

runMigrations();
