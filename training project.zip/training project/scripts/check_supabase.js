import { supabaseClient, isSupabaseConfigured } from '../src/config/database.js';

console.log('Is Supabase Configured:', isSupabaseConfigured);

async function verifyAll() {
  const tables = ['user_profiles', 'crops', 'mandis', 'market_prices', 'selling_decisions'];
  for (const table of tables) {
    const { data, error, count } = await supabaseClient.from(table).select('*', { count: 'exact' });
    if (error) {
      console.error(`❌ Table ${table} error:`, error.message);
    } else {
      console.log(`✓ Table ${table} verified in Supabase! Total records: ${data?.length}`);
    }
  }
}

verifyAll();
