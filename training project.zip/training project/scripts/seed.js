import { localStore, SEED_USERS, SEED_CROPS, SEED_MANDIS, SEED_PRICES, SEED_DECISIONS } from '../src/services/db.js';
import { supabaseClient, isSupabaseConfigured } from '../src/config/database.js';

async function runSeed() {
  console.log('[Seed] Starting deterministic seed procedure...');

  if (isSupabaseConfigured && supabaseClient) {
    console.log('[Seed] Inserting records into remote Supabase PostgreSQL...');
    try {
      // 1. User Profiles
      const { error: userErr } = await supabaseClient.from('user_profiles').upsert(SEED_USERS);
      if (userErr) console.warn('[Seed] Warning on user_profiles upsert:', userErr.message);

      // 2. Crops
      const { error: cropErr } = await supabaseClient.from('crops').upsert(SEED_CROPS);
      if (cropErr) console.warn('[Seed] Warning on crops upsert:', cropErr.message);

      // 3. Mandis
      const { error: mandiErr } = await supabaseClient.from('mandis').upsert(SEED_MANDIS);
      if (mandiErr) console.warn('[Seed] Warning on mandis upsert:', mandiErr.message);

      // 4. Market Prices
      const { error: priceErr } = await supabaseClient.from('market_prices').upsert(SEED_PRICES);
      if (priceErr) console.warn('[Seed] Warning on market_prices upsert:', priceErr.message);

      // 5. Selling Decisions
      const { error: decErr } = await supabaseClient.from('selling_decisions').upsert(SEED_DECISIONS);
      if (decErr) console.warn('[Seed] Warning on selling_decisions upsert:', decErr.message);

      console.log('[Seed] Supabase remote seed completed successfully.');
    } catch (err) {
      console.warn('[Seed] Supabase remote error:', err.message);
    }
  }

  localStore.reset();
  console.log(`[Seed] In-process repository deterministically reset:`);
  console.log(`  - Users: ${SEED_USERS.length}`);
  console.log(`  - Crops: ${SEED_CROPS.length}`);
  console.log(`  - Mandis: ${SEED_MANDIS.length}`);
  console.log(`  - Price Quotes: ${SEED_PRICES.length}`);
  console.log(`  - Selling Decisions: ${SEED_DECISIONS.length}`);
  console.log('[Seed] Finished successfully.');
}

runSeed();
