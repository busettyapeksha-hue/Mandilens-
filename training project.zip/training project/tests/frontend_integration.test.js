import test from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../src/app.js';
import { localStore } from '../src/services/db.js';

test.beforeEach(() => {
  localStore.reset();
});

test('Frontend static assets: GET / serves index.html with valid semantic markup', async () => {
  const res = await request(app).get('/');
  assert.equal(res.status, 200);
  assert.ok(res.headers['content-type'].includes('text/html'));
  assert.ok(res.text.includes('<title>MandiLens'));
  assert.ok(res.text.includes('Net Realization Calculator'));
  assert.ok(res.text.includes('Selling Decision Journal'));
});

test('Frontend static assets: GET /styles.css serves agricultural design stylesheet', async () => {
  const res = await request(app).get('/styles.css');
  assert.equal(res.status, 200);
  assert.ok(res.headers['content-type'].includes('text/css'));
  assert.ok(res.text.includes('--primary'));
  assert.ok(res.text.includes('--status-planned'));
});

test('Frontend static assets: GET /app.js serves vanilla JavaScript application code', async () => {
  const res = await request(app).get('/app.js');
  assert.equal(res.status, 200);
  assert.ok(
    res.headers['content-type'].includes('application/javascript') ||
      res.headers['content-type'].includes('text/javascript')
  );
  assert.ok(res.text.includes('state = {'));
  assert.ok(res.text.includes('runCalculator'));
});

test('End-to-end Farmer Journey: Price Log -> Comparative Calculator -> Decision Execution -> Dashboard Metrics', async () => {
  // Step 1: Fetch master crops and mandis
  const cropsRes = await request(app).get('/api/crops');
  const mandisRes = await request(app).get('/api/mandis');
  const crop = cropsRes.body.data.find((c) => c.name.includes('Mustard'));
  const mandi = mandisRes.body.data.find((m) => m.name.includes('Gondal'));

  assert.ok(crop);
  assert.ok(mandi);

  // Step 2: Record new spot price quote for Mustard at Gondal APMC
  const priceRes = await request(app)
    .post('/api/prices')
    .set('x-demo-role', 'operator')
    .send({
      crop_id: crop.id,
      mandi_id: mandi.id,
      min_price: 5350,
      modal_price: 5500,
      max_price: 5650,
      price_date: '2026-10-27',
      quality_grade: 'Grade A / FAQ',
      data_source: 'market_survey',
      transport_estimate_per_unit: 70,
      commission_pct_applied: 1.5,
      cess_pct_applied: 0.8,
      notes: 'Strong demand from Saurashtra oil expellers.'
    });

  assert.equal(priceRes.status, 201);
  assert.equal(priceRes.body.data.modal_price, 5500);

  // Step 3: Run comparative calculator for 150 Quintals
  const calcRes = await request(app)
    .post('/api/calculator/compare')
    .send({
      crop_id: crop.id,
      quantity: 150,
      unit: 'Quintal',
      quality_grade: 'Grade A / FAQ'
    });

  assert.equal(calcRes.status, 200);
  assert.ok(calcRes.body.data.best_recommendation);
  const bestMandi = calcRes.body.data.best_recommendation.mandi_name;
  assert.ok(bestMandi);

  // Step 4: Create a Planned Selling Decision
  const decRes = await request(app)
    .post('/api/decisions')
    .set('x-demo-role', 'member')
    .send({
      crop_id: crop.id,
      chosen_mandi_id: mandi.id,
      quantity: 150,
      expected_gross_price: 5500,
      expected_freight_cost: 10500,
      expected_commission_fee: 12375,
      expected_handling_fee: 1800,
      decision_rationale: 'Comparative simulation verified Gondal yields optimal net return after 95km transport.'
    });

  assert.equal(decRes.status, 201);
  const decisionId = decRes.body.data.id;
  assert.equal(decRes.body.data.status, 'PLANNED');

  // Step 5: Execute the sale lot with actual figures
  const execRes = await request(app)
    .patch(`/api/decisions/${decisionId}/status`)
    .set('x-demo-role', 'member')
    .send({
      status: 'EXECUTED',
      actual_sale_date: '2026-10-27',
      actual_gross_price: 5520, // +Rs 20 premium achieved at auction
      actual_freight_cost: 10500,
      actual_commission_fee: 12420,
      actual_handling_fee: 1800,
      buyer_name: 'Gujarat Edible Oils Ltd',
      commission_agent_name: 'Patel & Brothers Aadathiya',
      settlement_status: 'RECEIVED',
      payment_mode: 'NEFT_RTGS'
    });

  assert.equal(execRes.status, 200);
  assert.equal(execRes.body.data.status, 'EXECUTED');
  // Actual Net = (5520 * 150) - (10500 + 12420 + 1800) = 828000 - 24720 = 803280.
  assert.equal(execRes.body.data.actual_total_net_realization, 803280);

  // Step 6: Verify Dashboard dynamically reflects the new volume & revenue
  const dashRes = await request(app).get('/api/analytics/dashboard').set('x-demo-role', 'member');
  assert.equal(dashRes.status, 200);
  // Volume should include 150 Qtl
  assert.ok(dashRes.body.data.overview.total_volume_quintals >= 150);
  // Executed decisions should include the new execution
  assert.ok(dashRes.body.data.decisions_pipeline.executed >= 1);

  // Step 7: Verify Audit trail captures the events
  const auditRes = await request(app).get('/api/audit-logs').set('x-demo-role', 'admin');
  assert.equal(auditRes.status, 200);
  assert.ok(auditRes.body.data.some((a) => a.action === 'CREATE_PRICE' && a.entity_id === priceRes.body.data.id));
  assert.ok(auditRes.body.data.some((a) => a.action === 'STATUS_TRANSITION' && a.entity_id === decisionId));
});
