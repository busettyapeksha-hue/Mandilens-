import test from 'node:test';
import assert from 'node:assert/strict';
import request from 'supertest';
import app from '../src/app.js';
import { isSupabaseConfigured } from '../src/config/database.js';
import { localStore } from '../src/services/db.js';

test.beforeEach(() => {
  localStore.reset();
});

test('GET /api/health returns operational status and database engine info', async () => {
  const res = await request(app).get('/api/health');
  assert.equal(res.status, 200);
  assert.equal(res.body.success, true);
  assert.equal(res.body.service, 'MandiLens API');
  assert.ok(res.body.database);
});

test('Security headers are enforced by Helmet', async () => {
  const res = await request(app).get('/api/health');
  assert.equal(res.headers['x-content-type-options'], 'nosniff');
  assert.ok(res.headers['content-security-policy']);
});

test('GET /api/crops returns list of active monitored crops', async () => {
  const res = await request(app).get('/api/crops');
  assert.equal(res.status, 200);
  assert.equal(res.body.success, true);
  assert.ok(Array.isArray(res.body.data));
  assert.ok(res.body.data.length >= 8);
  assert.ok(res.body.data.some((c) => c.name.includes('Wheat')));
});

test('GET /api/mandis returns list of APMC markets with cess and commission rates', async () => {
  const res = await request(app).get('/api/mandis');
  assert.equal(res.status, 200);
  assert.equal(res.body.success, true);
  assert.ok(Array.isArray(res.body.data));
  assert.ok(res.body.data.length >= 6);
  assert.ok(res.body.data.some((m) => m.name.includes('Azadpur')));
});

test('POST /api/prices validates that min_price <= modal_price <= max_price', async () => {
  const cropsRes = await request(app).get('/api/crops');
  const mandisRes = await request(app).get('/api/mandis');
  const cropId = cropsRes.body.data[0].id;
  const mandiId = mandisRes.body.data[0].id;

  // Invalid: min_price > modal_price
  const invalidRes = await request(app)
    .post('/api/prices')
    .set('x-demo-role', 'operator')
    .send({
      crop_id: cropId,
      mandi_id: mandiId,
      min_price: 3000,
      modal_price: 2500,
      max_price: 3200,
      price_date: '2026-10-27',
      quality_grade: 'Grade A / FAQ',
      data_source: 'manual_entry'
    });

  assert.equal(invalidRes.status, 400);
  assert.equal(invalidRes.body.success, false);
  assert.ok(invalidRes.body.details.some((msg) => msg.includes('min_price cannot exceed modal_price')));
});

test('POST /api/prices creates a verified price record when submitted by Operator', async () => {
  const cropsRes = await request(app).get('/api/crops');
  const mandisRes = await request(app).get('/api/mandis');
  const cropId = cropsRes.body.data[0].id;
  const mandiId = mandisRes.body.data[2].id;

  const res = await request(app)
    .post('/api/prices')
    .set('x-demo-role', 'operator')
    .send({
      crop_id: cropId,
      mandi_id: mandiId,
      min_price: 2400,
      modal_price: 2480,
      max_price: 2550,
      price_date: '2026-10-27',
      quality_grade: 'Grade A / FAQ',
      data_source: 'manual_entry',
      verified: true,
      transport_estimate_per_unit: 45,
      commission_pct_applied: 2.0,
      labor_fee_per_unit_applied: 14.0,
      cess_pct_applied: 1.0,
      notes: 'Freshly harvested lot arrival'
    });

  assert.equal(res.status, 201);
  assert.equal(res.body.success, true);
  assert.equal(res.body.data.modal_price, 2480);
  assert.equal(res.body.data.verified, true);
  assert.ok(res.body.data.estimated_net_realization > 0);
  // Net realization should equal modal - transport - labor - (modal * 0.03)
  // 2480 - 45 - 14 - (2480 * 0.03) = 2480 - 59 - 74.40 = 2346.60
  assert.equal(res.body.data.estimated_net_realization, 2346.6);
});

test('POST /api/prices prevents duplicate submissions for the same crop, market, date, grade, and source', async () => {
  const cropsRes = await request(app).get('/api/crops');
  const mandisRes = await request(app).get('/api/mandis');
  const cropId = cropsRes.body.data[0].id;
  const mandiId = mandisRes.body.data[0].id;

  const payload = {
    crop_id: cropId,
    mandi_id: mandiId,
    min_price: 2200,
    modal_price: 2300,
    max_price: 2400,
    price_date: '2026-10-28',
    quality_grade: 'Grade A / FAQ',
    data_source: 'manual_entry'
  };

  const first = await request(app).post('/api/prices').set('x-demo-role', 'operator').send(payload);
  assert.equal(first.status, 201);

  // Second submission with exact same key attributes
  const second = await request(app).post('/api/prices').set('x-demo-role', 'operator').send(payload);
  assert.equal(second.status, 409);
  assert.ok(second.body.error.includes('Duplicate Price Entry'));
});

test('POST /api/calculator/compare computes net realization and ranks mandis by profit', async () => {
  const cropsRes = await request(app).get('/api/crops');
  const wheat = cropsRes.body.data.find((c) => c.name.includes('Wheat'));

  const res = await request(app)
    .post('/api/calculator/compare')
    .send({
      crop_id: wheat.id,
      quantity: 100,
      unit: 'Quintal',
      quality_grade: 'Grade A / FAQ'
    });

  assert.equal(res.status, 200);
  assert.equal(res.body.success, true);
  assert.ok(res.body.data.best_recommendation);
  assert.ok(Array.isArray(res.body.data.comparisons));
  assert.ok(res.body.data.comparisons.length >= 2);

  // Top ranked mandi must have rank 1 and highest net realization
  const top = res.body.data.comparisons[0];
  assert.equal(top.rank, 1);
  assert.equal(top.is_highest_profit, true);
  assert.ok(top.total_financials.net_realization >= res.body.data.comparisons[1].total_financials.net_realization);
});

test('Selling Decision Lifecycle: PLANNED -> IN_TRANSIT -> EXECUTED -> SETTLED with variance', async () => {
  const cropsRes = await request(app).get('/api/crops');
  const mandisRes = await request(app).get('/api/mandis');
  const cropId = cropsRes.body.data[0].id;
  const mandiId = mandisRes.body.data[0].id;

  // 1. Create Planned Lot
  const createRes = await request(app)
    .post('/api/decisions')
    .set('x-demo-role', 'member')
    .send({
      crop_id: cropId,
      chosen_mandi_id: mandiId,
      quantity: 50,
      expected_gross_price: 2500,
      expected_freight_cost: 3500,
      expected_commission_fee: 2500,
      expected_handling_fee: 800,
      decision_rationale: 'Delhi mandi price premium justifies 120km freight.'
    });

  assert.equal(createRes.status, 201);
  const decisionId = createRes.body.data.id;
  assert.equal(createRes.body.data.status, 'PLANNED');
  assert.equal(createRes.body.data.expected_total_net_realization, 125000 - 6800); // 118200

  // 2. Transition PLANNED -> IN_TRANSIT
  const transitRes = await request(app)
    .patch(`/api/decisions/${decisionId}/status`)
    .set('x-demo-role', 'member')
    .send({ status: 'IN_TRANSIT' });

  assert.equal(transitRes.status, 200);
  assert.equal(transitRes.body.data.status, 'IN_TRANSIT');

  // 3. Transition IN_TRANSIT -> EXECUTED with actual gross price & deductions
  const execRes = await request(app)
    .patch(`/api/decisions/${decisionId}/status`)
    .set('x-demo-role', 'member')
    .send({
      status: 'EXECUTED',
      actual_sale_date: '2026-10-27',
      actual_gross_price: 2550, // Rs 50/qtl higher than expected
      actual_freight_cost: 3500,
      actual_commission_fee: 2550,
      actual_handling_fee: 800,
      buyer_name: 'Haryana Flour Millers Ltd',
      commission_agent_name: 'Gupta Traders',
      settlement_status: 'PARTIAL'
    });

  assert.equal(execRes.status, 200);
  assert.equal(execRes.body.data.status, 'EXECUTED');
  // Actual gross = 2550 * 50 = 127500. Total deductions = 3500 + 2550 + 800 = 6850.
  // Net realization = 127500 - 6850 = 120650.
  // Expected net = 118200.
  // Variance = 120650 - 118200 = +2450.
  assert.equal(execRes.body.data.actual_total_net_realization, 120650);
  assert.equal(execRes.body.data.variance_net_revenue, 2450);

  // 4. Transition EXECUTED -> SETTLED
  const settleRes = await request(app)
    .patch(`/api/decisions/${decisionId}/status`)
    .set('x-demo-role', 'member')
    .send({
      status: 'SETTLED',
      settlement_status: 'RECEIVED',
      payment_mode: 'NEFT_RTGS'
    });

  assert.equal(settleRes.status, 200);
  assert.equal(settleRes.body.data.status, 'SETTLED');
  assert.equal(settleRes.body.data.settlement_status, 'RECEIVED');

  // 5. Invalid transition: SETTLED cannot go back to PLANNED directly
  const invalidTransition = await request(app)
    .patch(`/api/decisions/${decisionId}/status`)
    .set('x-demo-role', 'member')
    .send({ status: 'PLANNED' });

  assert.equal(invalidTransition.status, 400);
  assert.ok(invalidTransition.body.error.includes('Invalid status transition'));
});

test('Role Authorization: Member cannot access audit logs; Operator and Admin can', async () => {
  // Member request
  const memberRes = await request(app).get('/api/audit-logs').set('x-demo-role', 'member');
  assert.equal(memberRes.status, 403);

  // Operator request
  const operatorRes = await request(app).get('/api/audit-logs').set('x-demo-role', 'operator');
  assert.equal(operatorRes.status, 200);
  assert.ok(Array.isArray(operatorRes.body.data));

  // Admin request
  const adminRes = await request(app).get('/api/audit-logs').set('x-demo-role', 'admin');
  assert.equal(adminRes.status, 200);
  assert.ok(Array.isArray(adminRes.body.data));
});

test('GET /api/analytics/dashboard computes metrics from persisted records', async () => {
  const res = await request(app).get('/api/analytics/dashboard').set('x-demo-role', 'member');
  assert.equal(res.status, 200);
  assert.equal(res.body.success, true);
  const data = res.body.data;
  assert.ok(data.overview.active_crops > 0);
  assert.ok(data.overview.total_price_records > 0);
  assert.ok(data.overview.total_volume_quintals > 0);
  assert.ok(data.overview.total_realized_revenue > 0);
  assert.ok(data.sources_breakdown.seeded_demo > 0);
  assert.ok(data.decisions_pipeline.settled > 0);
  assert.ok(Array.isArray(data.crop_summaries));
});

test('POST /api/crops enforces Admin-only role authorization', async () => {
  // Member attempt
  const memberRes = await request(app)
    .post('/api/crops')
    .set('x-demo-role', 'member')
    .send({ name: 'Sunflower Seeds', category: 'Oilseeds' });
  assert.equal(memberRes.status, 403);

  // Operator attempt
  const operatorRes = await request(app)
    .post('/api/crops')
    .set('x-demo-role', 'operator')
    .send({ name: 'Sunflower Seeds', category: 'Oilseeds' });
  assert.equal(operatorRes.status, 403);

  // Admin attempt
  const adminRes = await request(app)
    .post('/api/crops')
    .set('x-demo-role', 'admin')
    .send({
      name: 'Sunflower Seeds (Hybrid 99)',
      hindi_name: 'सूरजमुखी बीज',
      category: 'Oilseeds',
      standard_unit: 'Quintal',
      standard_moisture_pct: 9.0
    });
  assert.equal(adminRes.status, 201);
  assert.equal(adminRes.body.data.name, 'Sunflower Seeds (Hybrid 99)');
});

test('POST /api/mandis enforces Operator and Admin role authorization', async () => {
  // Member attempt
  const memberRes = await request(app)
    .post('/api/mandis')
    .set('x-demo-role', 'member')
    .send({ name: 'Meerut Mandi', code: 'UP-MRT', state: 'Uttar Pradesh', district: 'Meerut' });
  assert.equal(memberRes.status, 403);

  // Operator attempt
  const operatorRes = await request(app)
    .post('/api/mandis')
    .set('x-demo-role', 'operator')
    .send({
      name: 'Meerut Grain Mandi',
      code: 'UP-MRT',
      state: 'Uttar Pradesh',
      district: 'Meerut',
      standard_cess_pct: 1.0,
      commission_agent_pct: 2.0,
      hamali_fee_per_unit: 11.0,
      default_distance_km: 72.0
    });
  assert.equal(operatorRes.status, 201);
  assert.equal(operatorRes.body.data.code, 'UP-MRT');
});

test('POST /api/decisions prevents duplicate lot references', async () => {
  const cropsRes = await request(app).get('/api/crops');
  const mandisRes = await request(app).get('/api/mandis');
  const cropId = cropsRes.body.data[0].id;
  const mandiId = mandisRes.body.data[0].id;

  const lotRef = 'LOT-TEST-DUP-01';
  const payload = {
    lot_reference: lotRef,
    crop_id: cropId,
    chosen_mandi_id: mandiId,
    quantity: 40,
    expected_gross_price: 2400,
    expected_freight_cost: 1500,
    decision_rationale: 'Testing duplicate lot reference protection.'
  };

  const first = await request(app).post('/api/decisions').set('x-demo-role', 'member').send(payload);
  assert.equal(first.status, 201);

  const second = await request(app).post('/api/decisions').set('x-demo-role', 'member').send(payload);
  assert.equal(second.status, 409);
  assert.ok(second.body.error.includes('already exists'));
});

test('POST /api/calculator/compare handles custom fee overrides correctly', async () => {
  const cropsRes = await request(app).get('/api/crops');
  const mandisRes = await request(app).get('/api/mandis');
  const crop = cropsRes.body.data[0];
  const mandi = mandisRes.body.data[0];

  const res = await request(app)
    .post('/api/calculator/compare')
    .send({
      crop_id: crop.id,
      quantity: 100,
      unit: 'Quintal',
      quality_grade: 'Grade A / FAQ',
      mandi_ids: [mandi.id],
      overrides: {
        [mandi.id]: {
          freight_per_unit: 50.0,
          commission_pct: 1.0,
          labor_per_unit: 10.0
        }
      }
    });

  assert.equal(res.status, 200);
  const comparison = res.body.data.comparisons[0];
  assert.equal(comparison.cost_breakdown_per_unit.freight, 50.0);
  assert.equal(comparison.cost_breakdown_per_unit.labor, 10.0);
});

test('POST /api/system/reset-demo resets state to deterministic baseline', async () => {
  const resetRes = await request(app)
    .post('/api/system/reset-demo')
    .set('x-demo-role', 'admin');
  assert.equal(resetRes.status, 200);
  assert.equal(resetRes.body.success, true);

  const dashRes = await request(app).get('/api/analytics/dashboard').set('x-demo-role', 'admin');
  assert.equal(dashRes.status, 200);
  assert.ok(dashRes.body.data.overview.total_price_records >= 8);
});

test('Remote Supabase PostgreSQL integration check', async () => {
  if (isSupabaseConfigured) {
    // If live credentials are supplied in .env
    const cropsRes = await request(app).get('/api/crops');
    assert.equal(cropsRes.status, 200);
    console.log('[Integration Test] Live Supabase PostgreSQL query verified.');
  } else {
    // Report truthfully as blocked per prompt guardrails
    console.log(
      '[Integration Test] Remote Supabase PostgreSQL live test blocked: SUPABASE_URL / SUPABASE_KEY not configured in environment. Safe Local Repository passed.'
    );
    assert.ok(true, 'Local repository verification passed.');
  }
});
