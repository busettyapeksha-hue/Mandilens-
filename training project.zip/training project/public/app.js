/**
 * MandiLens — Agricultural Market Price Comparison & Selling Decision Log
 * Vanilla JavaScript Frontend Architecture
 */

// Application State
const state = {
  currentRole: 'member',
  user: null,
  activeTab: 'overview',
  crops: [],
  mandis: [],
  prices: [],
  decisions: [],
  dashboard: null,
  auditLogs: [],
  priceFilters: {
    search: '',
    crop_id: '',
    mandi_id: '',
    data_source: '',
    verified: ''
  },
  decisionFilters: {
    search: '',
    status: '',
    crop_id: ''
  },
  lastCalcResult: null
};

// --- Toast Notifications ---
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span style="font-weight: 700;">${type === 'success' ? '✓' : type === 'error' ? '✕' : 'ℹ'}</span>
    <span>${message}</span>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.25s ease-out';
    setTimeout(() => toast.remove(), 250);
  }, 4000);
}

// --- Unified API Client ---
async function apiRequest(endpoint, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    'x-demo-role': state.currentRole,
    ...(options.headers || {})
  };

  try {
    const res = await fetch(`/api${endpoint}`, {
      ...options,
      headers
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      const errorMsg = data.error || (data.details ? data.details.join('; ') : `HTTP ${res.status}`);
      throw new Error(errorMsg);
    }

    return data;
  } catch (err) {
    console.error(`API Error on [${options.method || 'GET'} ${endpoint}]:`, err.message);
    showToast(err.message, 'error');
    throw err;
  }
}

// --- Formatting Helpers ---
function formatCurrency(val) {
  if (val === null || val === undefined || isNaN(val)) return '₹0';
  return '₹' + Number(val).toLocaleString('en-IN', { maximumFractionDigits: 2 });
}

function formatDate(isoStr) {
  if (!isoStr) return '-';
  const d = new Date(isoStr);
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

function getStatusBadge(status) {
  const s = status || 'PLANNED';
  return `<span class="badge badge-${s.toLowerCase()}">${s.replace('_', ' ')}</span>`;
}

function getSourceBadge(source) {
  const map = {
    manual_entry: { label: 'Manual Entry', cls: 'badge-manual' },
    market_survey: { label: 'Yard Survey', cls: 'badge-survey' },
    seeded_demo: { label: 'Demo Benchmark', cls: 'badge-seed' },
    verified_live_api: { label: 'Verified Live Feed', cls: 'badge-live' }
  };
  const item = map[source] || { label: source, cls: 'badge-seed' };
  return `<span class="badge ${item.cls}">${item.label}</span>`;
}

// --- DOM Navigation & Tabs ---
function switchTab(tabId) {
  state.activeTab = tabId;

  document.querySelectorAll('.nav-tab-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.tab === tabId);
  });

  document.querySelectorAll('.tab-section').forEach((sec) => {
    sec.classList.toggle('active', sec.id === `tab-${tabId}`);
  });

  window.location.hash = tabId;

  // Tab-specific refreshes
  if (tabId === 'overview') loadDashboard();
  if (tabId === 'prices') loadPrices();
  if (tabId === 'decisions') loadDecisions();
  if (tabId === 'mandis') loadMandis();
  if (tabId === 'audit') loadAuditLogs();
}

// --- Modals Management ---
function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add('active');
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove('active');
}

// Bind modal close buttons
document.querySelectorAll('[data-close]').forEach((btn) => {
  btn.addEventListener('click', (e) => {
    const target = e.currentTarget.getAttribute('data-close');
    closeModal(target);
  });
});

document.querySelectorAll('.modal-overlay').forEach((overlay) => {
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      overlay.classList.remove('active');
    }
  });
});

// --- System & Database Status ---
async function checkSystemHealth() {
  try {
    const res = await apiRequest('/health');
    const badgeText = document.getElementById('dbStatusText');
    const dot = document.querySelector('.db-dot');

    if (res.database.includes('supabase')) {
      badgeText.textContent = 'Supabase PostgreSQL';
      dot.style.backgroundColor = '#22c55e';
    } else {
      badgeText.textContent = 'Local Repository Sandbox';
      dot.style.backgroundColor = '#38bdf8';
    }

    state.user = res.user;
  } catch (err) {
    document.getElementById('dbStatusText').textContent = 'Disconnected';
  }
}

// --- Data Loading Functions ---
async function loadMasterData() {
  try {
    const [cropsRes, mandisRes] = await Promise.all([apiRequest('/crops'), apiRequest('/mandis')]);

    state.crops = cropsRes.data || [];
    state.mandis = mandisRes.data || [];

    populateCropSelects();
    populateMandiSelects();
  } catch (err) {
    console.error('Failed to load crops or mandis:', err);
  }
}

function populateCropSelects() {
  const selects = [
    document.getElementById('filterPriceCrop'),
    document.getElementById('filterDecisionCrop'),
    document.getElementById('chartCropSelect'),
    document.getElementById('calcCropSelect'),
    document.getElementById('priceCrop'),
    document.getElementById('decisionCrop')
  ];

  selects.forEach((sel) => {
    if (!sel) return;
    const isFilter = sel.id.startsWith('filter');
    const currentVal = sel.value;

    sel.innerHTML = isFilter ? '<option value="">All Crops</option>' : '';

    state.crops.forEach((c) => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = `${c.name} (${c.hindi_name})`;
      sel.appendChild(opt);
    });

    if (currentVal) sel.value = currentVal;
  });
}

function populateMandiSelects() {
  const selects = [
    document.getElementById('filterPriceMandi'),
    document.getElementById('priceMandi'),
    document.getElementById('decisionMandi')
  ];

  selects.forEach((sel) => {
    if (!sel) return;
    const isFilter = sel.id.startsWith('filter');
    const currentVal = sel.value;

    sel.innerHTML = isFilter ? '<option value="">All Mandis</option>' : '';

    state.mandis.forEach((m) => {
      const opt = document.createElement('option');
      opt.value = m.id;
      opt.textContent = `${m.name} (${m.state}) [${m.code}]`;
      sel.appendChild(opt);
    });

    if (currentVal) sel.value = currentVal;
  });
}

// --- Dashboard & Visualizations ---
async function loadDashboard() {
  try {
    const res = await apiRequest('/analytics/dashboard');
    state.dashboard = res.data;

    const ov = state.dashboard.overview;
    document.getElementById('kpiTotalRevenue').textContent = formatCurrency(ov.total_realized_revenue);
    document.getElementById('kpiNetOptimization').textContent = formatCurrency(ov.net_optimization_value);
    document.getElementById('kpiVolumeQuintals').textContent = `${ov.total_volume_quintals.toLocaleString('en-IN')} Qtl`;
    document.getElementById('kpiPriceQuotes').textContent = ov.total_price_records;
    document.getElementById('kpiVerifiedCount').textContent = `${ov.verified_prices_count} Verified quotes`;

    // Data Source Provenance
    const sb = state.dashboard.sources_breakdown;
    document.getElementById('provenanceContainer').innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 12px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>${getSourceBadge('manual_entry')}</span>
          <strong>${sb.manual_entry} records</strong>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>${getSourceBadge('market_survey')}</span>
          <strong>${sb.market_survey} records</strong>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>${getSourceBadge('seeded_demo')}</span>
          <strong>${sb.seeded_demo} records</strong>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>${getSourceBadge('verified_live_api')}</span>
          <strong>${sb.verified_live_api} records</strong>
        </div>
      </div>
    `;

    // Decision Pipeline
    const dp = state.dashboard.decisions_pipeline;
    document.getElementById('decisionPipelineContainer').innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 12px;">
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>${getStatusBadge('PLANNED')}</span>
          <strong>${dp.planned} lots</strong>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>${getStatusBadge('IN_TRANSIT')}</span>
          <strong>${dp.in_transit} lots</strong>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>${getStatusBadge('EXECUTED')}</span>
          <strong>${dp.executed} lots</strong>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>${getStatusBadge('SETTLED')}</span>
          <strong style="color: #15803d;">${dp.settled} lots</strong>
        </div>
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>${getStatusBadge('CANCELLED')}</span>
          <strong style="color: #64748b;">${dp.cancelled} lots</strong>
        </div>
      </div>
    `;

    renderChart();
  } catch (err) {
    console.error('Failed to load dashboard:', err);
  }
}

// Custom SVG Price Spread & Realization Chart
function renderChart() {
  const container = document.getElementById('chartContainer');
  if (!container) return;

  const cropSelect = document.getElementById('chartCropSelect');
  const cropId = cropSelect?.value || (state.crops[0] ? state.crops[0].id : null);

  if (!cropId) {
    container.innerHTML = '<div style="padding: 20px; color: #64748b;">No crops available for visualization.</div>';
    return;
  }

  // Filter quotes for selected crop
  const quotes = state.prices.filter((p) => p.crop_id === cropId);

  if (quotes.length === 0) {
    container.innerHTML = `
      <div style="padding: 30px; text-align: center; color: #64748b;">
        No active quotes logged for this crop yet. Record a spot price to see comparison.
      </div>
    `;
    return;
  }

  // Find max value for scaling
  const maxVal = Math.max(...quotes.map((q) => q.modal_price), 1000) * 1.15;
  const svgHeight = 220;
  const svgWidth = Math.max(540, quotes.length * 110);
  const barWidth = 32;

  let barsSvg = '';
  quotes.forEach((q, i) => {
    const x = 50 + i * 105;
    const modalH = (q.modal_price / maxVal) * (svgHeight - 60);
    const modalY = svgHeight - 35 - modalH;

    const netH = (q.estimated_net_realization / maxVal) * (svgHeight - 60);
    const netY = svgHeight - 35 - netH;

    const shortMandi = q.mandi_name.replace('APMC', '').replace('Grain Market', '').trim();

    barsSvg += `
      <!-- Modal Quoted Price Bar -->
      <rect x="${x}" y="${modalY}" width="${barWidth}" height="${modalH}" fill="#3b82f6" rx="3" opacity="0.85">
        <title>Nominal Quoted Price: ₹${q.modal_price} / Qtl</title>
      </rect>
      <!-- True Net Realization Bar -->
      <rect x="${x + barWidth + 4}" y="${netY}" width="${barWidth}" height="${netH}" fill="#16a34a" rx="3">
        <title>Net Realization: ₹${q.estimated_net_realization} / Qtl</title>
      </rect>
      <!-- Label Quoted -->
      <text x="${x + 16}" y="${modalY - 5}" font-size="10" font-weight="700" fill="#1e40af" text-anchor="middle">₹${Math.round(q.modal_price)}</text>
      <!-- Label Net -->
      <text x="${x + barWidth + 20}" y="${netY - 5}" font-size="10" font-weight="700" fill="#15803d" text-anchor="middle">₹${Math.round(q.estimated_net_realization)}</text>
      <!-- Mandi Name Axis Label -->
      <text x="${x + 34}" y="${svgHeight - 14}" font-size="11" font-weight="600" fill="#475569" text-anchor="middle">${shortMandi}</text>
      <text x="${x + 34}" y="${svgHeight - 2}" font-size="9" fill="#94a3b8" text-anchor="middle">${q.mandi_state}</text>
    `;
  });

  container.innerHTML = `
    <div style="display: flex; gap: 16px; margin-bottom: 8px; font-size: 0.8rem; font-weight: 600;">
      <span style="display: flex; align-items: center; gap: 6px;"><span style="width: 12px; height: 12px; background: #3b82f6; border-radius: 2px;"></span> Nominal Quoted Spot Price</span>
      <span style="display: flex; align-items: center; gap: 6px;"><span style="width: 12px; height: 12px; background: #16a34a; border-radius: 2px;"></span> Effective Net Realization (After Freight & Fees)</span>
    </div>
    <svg width="100%" height="${svgHeight}" viewBox="0 0 ${svgWidth} ${svgHeight}" style="overflow: visible;">
      <line x1="20" y1="${svgHeight - 35}" x2="${svgWidth - 20}" y2="${svgHeight - 35}" stroke="#cbd5e1" stroke-width="1"/>
      ${barsSvg}
    </svg>
  `;
}

// Chart crop selector change event
document.getElementById('chartCropSelect')?.addEventListener('change', renderChart);

// --- TAB 2: MARKET PRICES CRUD ---
async function loadPrices() {
  try {
    const params = new URLSearchParams();
    if (state.priceFilters.crop_id) params.append('crop_id', state.priceFilters.crop_id);
    if (state.priceFilters.mandi_id) params.append('mandi_id', state.priceFilters.mandi_id);
    if (state.priceFilters.data_source) params.append('data_source', state.priceFilters.data_source);
    if (state.priceFilters.verified) params.append('verified', state.priceFilters.verified);
    if (state.priceFilters.search) params.append('search', state.priceFilters.search);

    const res = await apiRequest(`/prices?${params.toString()}`);
    state.prices = res.data || [];

    const tbody = document.getElementById('pricesTableBody');
    const emptyState = document.getElementById('pricesEmptyState');
    tbody.innerHTML = '';

    if (state.prices.length === 0) {
      emptyState.style.display = 'block';
      return;
    }
    emptyState.style.display = 'none';

    state.prices.forEach((p) => {
      const tr = document.createElement('tr');

      const verifiedHtml = p.verified
        ? '<span style="color: #16a34a; font-weight: 700; display: flex; align-items: center; gap: 4px;">✓ Verified</span>'
        : '<span style="color: #94a3b8; font-size: 0.8rem;">Unverified</span>';

      // Permissions check for Edit/Delete
      const canEdit = state.currentRole === 'admin' || state.currentRole === 'operator' || p.created_by === state.user?.id;

      tr.innerHTML = `
        <td style="font-weight: 600;">${formatDate(p.price_date)}</td>
        <td>
          <div style="font-weight: 700; color: var(--primary-dark);">${p.crop_name}</div>
          <div style="font-size: 0.78rem; color: var(--text-muted);">${p.crop_hindi}</div>
        </td>
        <td>
          <div style="font-weight: 600;">${p.mandi_name}</div>
          <div style="font-size: 0.78rem; color: var(--text-muted);">${p.mandi_state} • ${p.distance_km} km</div>
        </td>
        <td><span style="font-size: 0.82rem; font-weight: 600;">${p.quality_grade}</span></td>
        <td>
          <div style="font-weight: 700; color: #1e40af;">${formatCurrency(p.modal_price)}</div>
          <div style="font-size: 0.75rem; color: #64748b;">Range: ${formatCurrency(p.min_price)} - ${formatCurrency(p.max_price)}</div>
        </td>
        <td>
          <div style="font-weight: 800; color: #15803d;">${formatCurrency(p.estimated_net_realization)}</div>
          <div style="font-size: 0.75rem; color: #166534;">Deductions: ₹${Math.round(p.modal_price - p.estimated_net_realization)}/Qtl</div>
        </td>
        <td>${getSourceBadge(p.data_source)}</td>
        <td>${verifiedHtml}</td>
        <td style="text-align: right; white-space: nowrap;">
          <button class="btn btn-outline btn-sm btn-view-price" data-id="${p.id}" title="Inspect Breakdown">
            Breakdown
          </button>
          ${
            canEdit
              ? `
              <button class="btn btn-outline btn-sm btn-edit-price" data-id="${p.id}" title="Edit Quote">Edit</button>
              <button class="btn btn-danger btn-sm btn-delete-price" data-id="${p.id}" title="Delete Quote">Delete</button>
            `
              : ''
          }
        </td>
      `;

      tbody.appendChild(tr);
    });

    // Re-render chart if crops match
    renderChart();
  } catch (err) {
    console.error('Failed to load prices:', err);
  }
}

// Price Filters Listeners
document.getElementById('filterPriceSearch')?.addEventListener('input', (e) => {
  state.priceFilters.search = e.target.value.trim();
  loadPrices();
});
document.getElementById('filterPriceCrop')?.addEventListener('change', (e) => {
  state.priceFilters.crop_id = e.target.value;
  loadPrices();
});
document.getElementById('filterPriceMandi')?.addEventListener('change', (e) => {
  state.priceFilters.mandi_id = e.target.value;
  loadPrices();
});
document.getElementById('filterPriceSource')?.addEventListener('change', (e) => {
  state.priceFilters.data_source = e.target.value;
  loadPrices();
});
document.getElementById('filterPriceVerified')?.addEventListener('change', (e) => {
  state.priceFilters.verified = e.target.value;
  loadPrices();
});
document.getElementById('btnResetPriceFilters')?.addEventListener('click', () => {
  state.priceFilters = { search: '', crop_id: '', mandi_id: '', data_source: '', verified: '' };
  document.getElementById('filterPriceSearch').value = '';
  document.getElementById('filterPriceCrop').value = '';
  document.getElementById('filterPriceMandi').value = '';
  document.getElementById('filterPriceSource').value = '';
  document.getElementById('filterPriceVerified').value = '';
  loadPrices();
});

// Price Modal Open & Reactive Realization Calculation
function updatePriceModalNetPreview() {
  const modalP = Number(document.getElementById('priceModal').value) || 0;
  const freight = Number(document.getElementById('priceTransport').value) || 0;
  const comm = Number(document.getElementById('priceCommission').value) || 0;
  const cess = 1.0; // standard benchmark cess
  const labor = 14.0; // hamali

  const totalPctDeductions = modalP * ((comm + cess) / 100);
  const net = Math.max(0, modalP - freight - labor - totalPctDeductions);
  document.getElementById('priceNetPreview').textContent = `${formatCurrency(net)} / Unit`;
}

['priceModal', 'priceTransport', 'priceCommission'].forEach((id) => {
  document.getElementById(id)?.addEventListener('input', updatePriceModalNetPreview);
});

document.getElementById('btnOpenNewPriceModal')?.addEventListener('click', () => {
  document.getElementById('priceEditId').value = '';
  document.getElementById('modalPriceTitle').textContent = 'Record Mandi Spot Price';
  document.getElementById('formPrice').reset();
  document.getElementById('priceDate').value = new Date().toISOString().split('T')[0];

  const canVerify = state.currentRole === 'operator' || state.currentRole === 'admin';
  document.getElementById('groupPriceVerified').style.display = canVerify ? 'flex' : 'none';

  updatePriceModalNetPreview();
  openModal('modalPrice');
});

// Price Form Submission
document.getElementById('formPrice')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const editId = document.getElementById('priceEditId').value;

  const payload = {
    crop_id: document.getElementById('priceCrop').value,
    mandi_id: document.getElementById('priceMandi').value,
    price_date: document.getElementById('priceDate').value,
    quality_grade: document.getElementById('priceGrade').value,
    min_price: Number(document.getElementById('priceMin').value),
    modal_price: Number(document.getElementById('priceModal').value),
    max_price: Number(document.getElementById('priceMax').value),
    data_source: document.getElementById('priceSource').value,
    unit: document.getElementById('priceUnit').value,
    transport_estimate_per_unit: Number(document.getElementById('priceTransport').value) || 0,
    commission_pct_applied: Number(document.getElementById('priceCommission').value) || 2.0,
    notes: document.getElementById('priceNotes').value,
    verified: document.getElementById('priceVerifiedCheck').checked
  };

  try {
    if (editId) {
      await apiRequest(`/prices/${editId}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });
      showToast('Spot price quote updated successfully.', 'success');
    } else {
      await apiRequest('/prices', {
        method: 'POST',
        body: JSON.stringify(payload)
      });
      showToast('Spot price quote logged successfully.', 'success');
    }

    closeModal('modalPrice');
    loadPrices();
    loadDashboard();
  } catch (err) {
    // Toast handles error display
  }
});

// Delegate table buttons: Breakdown, Edit, Delete
document.getElementById('pricesTableBody')?.addEventListener('click', async (e) => {
  const viewBtn = e.target.closest('.btn-view-price');
  const editBtn = e.target.closest('.btn-edit-price');
  const delBtn = e.target.closest('.btn-delete-price');

  if (viewBtn) {
    const id = viewBtn.dataset.id;
    const price = state.prices.find((p) => p.id === id);
    if (!price) return;

    document.getElementById('priceDetailsTitle').textContent = `${price.crop_name} @ ${price.mandi_name}`;
    const deductions = price.modal_price - price.estimated_net_realization;

    document.getElementById('priceDetailsBody').innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 16px;">
        <div>
          <span style="font-size: 0.8rem; color: #64748b;">Quoted Spot Price:</span>
          <div style="font-size: 1.5rem; font-weight: 800; color: #1e40af;">${formatCurrency(price.modal_price)} / ${price.unit}</div>
        </div>
        <div style="text-align: right;">
          <span style="font-size: 0.8rem; color: #166534;">Effective Net Realization:</span>
          <div style="font-size: 1.5rem; font-weight: 800; color: #15803d;">${formatCurrency(price.estimated_net_realization)} / ${price.unit}</div>
        </div>
      </div>

      <h4 style="font-size: 0.95rem; font-weight: 700; margin-bottom: 10px; color: var(--primary-dark);">Deductions Breakdown (₹${Math.round(deductions)} / ${price.unit})</h4>
      <div style="display: flex; flex-direction: column; gap: 8px; font-size: 0.88rem;">
        <div style="display: flex; justify-content: space-between; padding: 6px 10px; background: #f8fafc; border-radius: 6px;">
          <span>Freight Transit (${price.distance_km} km):</span>
          <strong>${formatCurrency(price.transport_estimate_per_unit)}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; padding: 6px 10px; background: #f8fafc; border-radius: 6px;">
          <span>Aadathiya Commission (${price.commission_pct_applied}%):</span>
          <strong>${formatCurrency(price.modal_price * (price.commission_pct_applied / 100))}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; padding: 6px 10px; background: #f8fafc; border-radius: 6px;">
          <span>APMC Market Cess (${price.cess_pct_applied}%):</span>
          <strong>${formatCurrency(price.modal_price * (price.cess_pct_applied / 100))}</strong>
        </div>
        <div style="display: flex; justify-content: space-between; padding: 6px 10px; background: #f8fafc; border-radius: 6px;">
          <span>Hamali & Labor Charges:</span>
          <strong>${formatCurrency(price.labor_fee_per_unit_applied)}</strong>
        </div>
      </div>

      <div style="margin-top: 20px; padding: 12px; background: #f1f5f9; border-radius: 8px; font-size: 0.82rem;">
        <div><strong>Data Source:</strong> ${getSourceBadge(price.data_source)}</div>
        <div style="margin-top: 6px;"><strong>Verification Status:</strong> ${price.verified ? 'Verified by Mandi Surveyor' : 'Unverified Field Entry'}</div>
        ${price.notes ? `<div style="margin-top: 6px;"><strong>Notes:</strong> ${price.notes}</div>` : ''}
      </div>
    `;

    openModal('modalPriceDetails');
  }

  if (editBtn) {
    const id = editBtn.dataset.id;
    const price = state.prices.find((p) => p.id === id);
    if (!price) return;

    document.getElementById('priceEditId').value = price.id;
    document.getElementById('modalPriceTitle').textContent = 'Edit Mandi Spot Price';
    document.getElementById('priceCrop').value = price.crop_id;
    document.getElementById('priceMandi').value = price.mandi_id;
    document.getElementById('priceDate').value = price.price_date;
    document.getElementById('priceGrade').value = price.quality_grade;
    document.getElementById('priceMin').value = price.min_price;
    document.getElementById('priceModal').value = price.modal_price;
    document.getElementById('priceMax').value = price.max_price;
    document.getElementById('priceSource').value = price.data_source;
    document.getElementById('priceUnit').value = price.unit;
    document.getElementById('priceTransport').value = price.transport_estimate_per_unit;
    document.getElementById('priceCommission').value = price.commission_pct_applied;
    document.getElementById('priceNotes').value = price.notes || '';
    document.getElementById('priceVerifiedCheck').checked = Boolean(price.verified);

    const canVerify = state.currentRole === 'operator' || state.currentRole === 'admin';
    document.getElementById('groupPriceVerified').style.display = canVerify ? 'flex' : 'none';

    updatePriceModalNetPreview();
    openModal('modalPrice');
  }

  if (delBtn) {
    const id = delBtn.dataset.id;
    if (!confirm('Are you sure you want to delete this price record? This action cannot be undone.')) return;

    try {
      await apiRequest(`/prices/${id}`, { method: 'DELETE' });
      showToast('Price quote deleted successfully.', 'success');
      loadPrices();
      loadDashboard();
    } catch (err) {
      // Toast handles error display
    }
  }
});

// --- TAB 3: NET REALIZATION CALCULATOR ---
document.getElementById('btnRunCalculator')?.addEventListener('click', runCalculator);

async function runCalculator() {
  const cropId = document.getElementById('calcCropSelect').value;
  const quantity = Number(document.getElementById('calcQuantity').value);
  const unit = document.getElementById('calcUnit').value;
  const grade = document.getElementById('calcGrade').value;

  if (!cropId || quantity <= 0) {
    showToast('Please select a crop and enter a valid quantity.', 'error');
    return;
  }

  try {
    const res = await apiRequest('/calculator/compare', {
      method: 'POST',
      body: JSON.stringify({
        crop_id: cropId,
        quantity,
        unit,
        quality_grade: grade
      })
    });

    state.lastCalcResult = res.data;
    renderCalculatorResults(res.data);
  } catch (err) {
    // Toast handles error display
  }
}

function renderCalculatorResults(data) {
  const container = document.getElementById('calcResultsContainer');
  const banner = document.getElementById('calcRecommendationBanner');

  if (!data || !data.comparisons || data.comparisons.length === 0) {
    container.innerHTML = '<div class="empty-state"><h3>No Mandis available for comparison.</h3></div>';
    banner.style.display = 'none';
    return;
  }

  const rec = data.best_recommendation;
  if (rec && rec.mandi_name) {
    banner.style.display = 'block';
    document.getElementById('recommendMandiName').textContent = rec.mandi_name;
    document.getElementById('recommendNetPrice').textContent = formatCurrency(rec.net_price_per_unit);
    document.getElementById('recommendNetTotal').textContent = formatCurrency(rec.total_net_realization);
    document.getElementById('recommendAdvantage').textContent = `+${formatCurrency(rec.net_advantage)}`;
  }

  let cardsHtml = '';
  data.comparisons.forEach((item) => {
    const fin = item.total_financials;
    const cost = item.cost_breakdown_per_unit;
    const isTop = item.is_highest_profit;

    // Segment percentages for visual bar
    const totalDeduct = cost.total_deductions_per_unit || 1;
    const freightPct = Math.round((cost.freight / totalDeduct) * 100);
    const commPct = Math.round((cost.commission / totalDeduct) * 100);
    const cessPct = Math.round((cost.cess / totalDeduct) * 100);
    const laborPct = Math.round((cost.labor / totalDeduct) * 100);

    cardsHtml += `
      <div class="mandi-rank-card ${isTop ? 'top-profit' : ''}">
        <span class="mandi-rank-badge">Rank #${item.rank}</span>

        <div style="display: flex; justify-content: space-between; align-items: baseline; flex-wrap: wrap; gap: 8px;">
          <div>
            <h4 style="font-size: 1.15rem; font-weight: 700; color: var(--primary-dark);">
              ${item.mandi_name}
              ${isTop ? '<span style="font-size: 0.75rem; color: #166534; font-weight: 700;">★ HIGHEST NET PROFIT</span>' : ''}
            </h4>
            <div style="font-size: 0.8rem; color: var(--text-muted);">
              ${item.state} • Distance: ${item.distance_km} km • Quote Source: ${getSourceBadge(item.quote_source)}
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 0.75rem; text-transform: uppercase; font-weight: 600; color: var(--text-muted);">True Net Realization</div>
            <div style="font-size: 1.5rem; font-weight: 800; color: #15803d;">${formatCurrency(fin.net_price_per_unit)} <span style="font-size: 0.8rem;">/ ${fin.unit}</span></div>
            <div style="font-size: 0.85rem; font-weight: 700; color: var(--text-main);">Total Lot Return: ${formatCurrency(fin.net_realization)}</div>
          </div>
        </div>

        <div style="margin: 14px 0 6px; font-size: 0.8rem; display: flex; justify-content: space-between;">
          <span>Nominal Quoted Price: <strong>${formatCurrency(item.nominal_prices.modal)}</strong></span>
          <span>Total Deductions: <strong style="color: #b91c1c;">-${formatCurrency(cost.total_deductions_per_unit)}</strong></span>
        </div>

        <!-- Visual Cost Breakdown Bar -->
        <div class="cost-breakdown-bar" title="Freight (${freightPct}%), Commission (${commPct}%), Cess (${cessPct}%), Labor (${laborPct}%)">
          <div class="cost-segment freight" style="width: ${freightPct}%;"></div>
          <div class="cost-segment commission" style="width: ${commPct}%;"></div>
          <div class="cost-segment cess" style="width: ${cessPct}%;"></div>
          <div class="cost-segment labor" style="width: ${laborPct}%;"></div>
        </div>

        <div style="display: flex; justify-content: space-between; font-size: 0.75rem; color: var(--text-muted); flex-wrap: wrap;">
          <span>Freight: ₹${cost.freight}</span>
          <span>Comm: ₹${Math.round(cost.commission)}</span>
          <span>Cess: ₹${Math.round(cost.cess)}</span>
          <span>Labor: ₹${cost.labor}</span>
          ${item.incremental_gain_vs_lowest > 0 ? `<strong style="color: #15803d;">+${formatCurrency(item.incremental_gain_vs_lowest)} vs Lowest</strong>` : ''}
        </div>
      </div>
    `;
  });

  container.innerHTML = cardsHtml;
}

// Log Decision directly from Calculator recommendation
document.getElementById('btnLogDecisionFromCalc')?.addEventListener('click', () => {
  if (!state.lastCalcResult) return;
  const top = state.lastCalcResult.comparisons[0];
  if (!top) return;

  document.getElementById('decisionCrop').value = state.lastCalcResult.crop.id;
  document.getElementById('decisionMandi').value = top.mandi_id;
  document.getElementById('decisionQuantity').value = state.lastCalcResult.input_quantity;
  document.getElementById('decisionExpectedGross').value = top.nominal_prices.modal;
  document.getElementById('decisionFreight').value = top.total_financials.total_freight;
  document.getElementById('decisionCommission').value = top.total_financials.total_commission;
  document.getElementById('decisionHandling').value = top.total_financials.total_labor;

  document.getElementById('decisionRationale').value = `Selected ${top.mandi_name} after comparative analysis: Yields highest net realization of Rs ${top.total_financials.net_price_per_unit}/qtl, generating Rs ${top.incremental_gain_vs_lowest} incremental net profit.`;

  updateDecisionModalNetPreview();
  openModal('modalDecision');
});

// --- TAB 4: SELLING DECISION JOURNAL ---
async function loadDecisions() {
  try {
    const params = new URLSearchParams();
    if (state.decisionFilters.status) params.append('status', state.decisionFilters.status);
    if (state.decisionFilters.crop_id) params.append('crop_id', state.decisionFilters.crop_id);
    if (state.decisionFilters.search) params.append('search', state.decisionFilters.search);

    const res = await apiRequest(`/decisions?${params.toString()}`);
    state.decisions = res.data || [];

    const tbody = document.getElementById('decisionsTableBody');
    const emptyState = document.getElementById('decisionsEmptyState');
    tbody.innerHTML = '';

    if (state.decisions.length === 0) {
      emptyState.style.display = 'block';
      return;
    }
    emptyState.style.display = 'none';

    state.decisions.forEach((d) => {
      const tr = document.createElement('tr');

      const expectedNetTotal = d.expected_total_net_realization;
      const actualNetTotal = d.actual_total_net_realization;
      const variance = d.variance_net_revenue;

      let varianceHtml = '<span style="color: #94a3b8;">Pending Execution</span>';
      if (variance !== null && variance !== undefined) {
        if (variance >= 0) {
          varianceHtml = `<span style="color: #15803d; font-weight: 700;">+${formatCurrency(variance)}</span>`;
        } else {
          varianceHtml = `<span style="color: #b91c1c; font-weight: 700;">${formatCurrency(variance)}</span>`;
        }
      }

      // Lifecycle action buttons based on status
      let actionsHtml = '';
      if (d.status === 'PLANNED') {
        actionsHtml = `
          <button class="btn btn-outline btn-sm btn-trans-status" data-id="${d.id}" data-status="IN_TRANSIT">Mark In-Transit</button>
          <button class="btn btn-primary btn-sm btn-trans-status" data-id="${d.id}" data-status="EXECUTED">Record Sale</button>
        `;
      } else if (d.status === 'IN_TRANSIT') {
        actionsHtml = `
          <button class="btn btn-primary btn-sm btn-trans-status" data-id="${d.id}" data-status="EXECUTED">Record Sale</button>
        `;
      } else if (d.status === 'EXECUTED') {
        actionsHtml = `
          <button class="btn btn-primary btn-sm btn-trans-status" data-id="${d.id}" data-status="SETTLED">Confirm Payment</button>
        `;
      } else if (d.status === 'SETTLED') {
        actionsHtml = `<span style="color: #15803d; font-weight: 700; font-size: 0.8rem;">✓ Settled</span>`;
      }

      tr.innerHTML = `
        <td>
          <div style="font-weight: 700; font-family: var(--font-mono); font-size: 0.85rem;">${d.lot_reference}</div>
          <div style="font-size: 0.75rem; color: #64748b;">${formatDate(d.created_at)}</div>
        </td>
        <td>
          <div style="font-weight: 700;">${d.crop_name}</div>
          <div style="font-size: 0.8rem; color: var(--text-muted);">${d.quantity} ${d.unit} (${d.quality_grade})</div>
        </td>
        <td>
          <div style="font-weight: 600;">${d.chosen_mandi_name}</div>
          <div style="font-size: 0.78rem; color: var(--text-muted);">${d.chosen_mandi_state}</div>
        </td>
        <td>${getStatusBadge(d.status)}</td>
        <td>
          <div style="font-weight: 700;">${formatCurrency(expectedNetTotal)}</div>
          <div style="font-size: 0.75rem; color: var(--text-muted);">${formatCurrency(d.expected_net_price_per_unit)}/${d.unit}</div>
        </td>
        <td>
          <div style="font-weight: 700; color: #15803d;">${actualNetTotal ? formatCurrency(actualNetTotal) : '-'}</div>
          <div style="font-size: 0.75rem; color: var(--text-muted);">${d.actual_net_price_per_unit ? formatCurrency(d.actual_net_price_per_unit) + '/' + d.unit : ''}</div>
        </td>
        <td>${varianceHtml}</td>
        <td style="max-width: 240px;">
          <div style="font-size: 0.82rem; color: var(--text-secondary); text-overflow: ellipsis; overflow: hidden; white-space: nowrap;" title="${d.decision_rationale}">
            ${d.decision_rationale}
          </div>
          ${d.buyer_name ? `<div style="font-size: 0.75rem; color: #0369a1; font-weight: 600;">Buyer: ${d.buyer_name}</div>` : ''}
        </td>
        <td style="text-align: right; white-space: nowrap;">
          ${actionsHtml}
          <button class="btn btn-danger btn-sm btn-delete-decision" data-id="${d.id}" title="Delete Lot">×</button>
        </td>
      `;

      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error('Failed to load decisions:', err);
  }
}

// Decision Filters Listeners
document.getElementById('filterDecisionSearch')?.addEventListener('input', (e) => {
  state.decisionFilters.search = e.target.value.trim();
  loadDecisions();
});
document.getElementById('filterDecisionStatus')?.addEventListener('change', (e) => {
  state.decisionFilters.status = e.target.value;
  loadDecisions();
});
document.getElementById('filterDecisionCrop')?.addEventListener('change', (e) => {
  state.decisionFilters.crop_id = e.target.value;
  loadDecisions();
});
document.getElementById('btnResetDecisionFilters')?.addEventListener('click', () => {
  state.decisionFilters = { search: '', status: '', crop_id: '' };
  document.getElementById('filterDecisionSearch').value = '';
  document.getElementById('filterDecisionStatus').value = '';
  document.getElementById('filterDecisionCrop').value = '';
  loadDecisions();
});

// Decision Modal Open & Reactive Realization Calculation
function updateDecisionModalNetPreview() {
  const qty = Number(document.getElementById('decisionQuantity').value) || 0;
  const gross = Number(document.getElementById('decisionExpectedGross').value) || 0;
  const freight = Number(document.getElementById('decisionFreight').value) || 0;
  const comm = Number(document.getElementById('decisionCommission').value) || 0;
  const handling = Number(document.getElementById('decisionHandling').value) || 0;

  const totalGross = gross * qty;
  const totalDeductions = freight + comm + handling;
  const net = Math.max(0, totalGross - totalDeductions);
  const netPerUnit = qty > 0 ? net / qty : 0;

  document.getElementById('decisionNetPreview').textContent = `${formatCurrency(net)} Total Net`;
  document.getElementById('decisionNetPerUnitPreview').textContent = `${formatCurrency(netPerUnit)} / Unit`;
}

['decisionQuantity', 'decisionExpectedGross', 'decisionFreight', 'decisionCommission', 'decisionHandling'].forEach((id) => {
  document.getElementById(id)?.addEventListener('input', updateDecisionModalNetPreview);
});

document.getElementById('btnOpenNewDecisionModal')?.addEventListener('click', () => {
  document.getElementById('formDecision').reset();
  updateDecisionModalNetPreview();
  openModal('modalDecision');
});
document.getElementById('btnQuickNewDecision')?.addEventListener('click', () => {
  document.getElementById('formDecision').reset();
  updateDecisionModalNetPreview();
  openModal('modalDecision');
});

// Decision Form Submission
document.getElementById('formDecision')?.addEventListener('submit', async (e) => {
  e.preventDefault();

  const payload = {
    crop_id: document.getElementById('decisionCrop').value,
    chosen_mandi_id: document.getElementById('decisionMandi').value,
    quantity: Number(document.getElementById('decisionQuantity').value),
    expected_gross_price: Number(document.getElementById('decisionExpectedGross').value),
    expected_freight_cost: Number(document.getElementById('decisionFreight').value) || 0,
    expected_commission_fee: Number(document.getElementById('decisionCommission').value) || 0,
    expected_handling_fee: Number(document.getElementById('decisionHandling').value) || 0,
    decision_rationale: document.getElementById('decisionRationale').value
  };

  try {
    await apiRequest('/decisions', {
      method: 'POST',
      body: JSON.stringify(payload)
    });

    showToast('Selling decision lot recorded successfully.', 'success');
    closeModal('modalDecision');
    loadDecisions();
    loadDashboard();
  } catch (err) {
    // Toast handles error display
  }
});

// Decision Table Lifecycle Buttons
document.getElementById('decisionsTableBody')?.addEventListener('click', async (e) => {
  const transBtn = e.target.closest('.btn-trans-status');
  const delBtn = e.target.closest('.btn-delete-decision');

  if (transBtn) {
    const id = transBtn.dataset.id;
    const targetStatus = transBtn.dataset.status;
    const decision = state.decisions.find((d) => d.id === id);
    if (!decision) return;

    if (targetStatus === 'IN_TRANSIT') {
      try {
        await apiRequest(`/decisions/${id}/status`, {
          method: 'PATCH',
          body: JSON.stringify({ status: 'IN_TRANSIT' })
        });
        showToast(`Lot ${decision.lot_reference} marked as In-Transit.`, 'success');
        loadDecisions();
        loadDashboard();
      } catch (err) {}
      return;
    }

    if (targetStatus === 'EXECUTED' || targetStatus === 'SETTLED') {
      document.getElementById('transDecisionId').value = decision.id;
      document.getElementById('transTargetStatus').value = targetStatus;
      document.getElementById('transLotRef').textContent = decision.lot_reference;
      document.getElementById('transStatusBadge').textContent = targetStatus;

      // Pre-fill defaults from expected values
      document.getElementById('transActualGross').value = decision.actual_gross_price || decision.expected_gross_price;
      document.getElementById('transSaleDate').value = decision.actual_sale_date || new Date().toISOString().split('T')[0];
      document.getElementById('transFreight').value = decision.actual_freight_cost ?? decision.expected_freight_cost;
      document.getElementById('transCommission').value = decision.actual_commission_fee ?? decision.expected_commission_fee;
      document.getElementById('transHandling').value = decision.actual_handling_fee ?? decision.expected_handling_fee;
      document.getElementById('transBuyer').value = decision.buyer_name || '';
      document.getElementById('transAgent').value = decision.commission_agent_name || '';
      document.getElementById('transSettlementStatus').value = targetStatus === 'SETTLED' ? 'RECEIVED' : 'PARTIAL';

      openModal('modalStatusTransition');
      return;
    }
  }

  if (delBtn) {
    const id = delBtn.dataset.id;
    if (!confirm('Are you sure you want to delete this selling decision record?')) return;

    try {
      await apiRequest(`/decisions/${id}`, { method: 'DELETE' });
      showToast('Decision lot deleted.', 'success');
      loadDecisions();
      loadDashboard();
    } catch (err) {}
  }
});

// Status Transition Form Submission
document.getElementById('formStatusTransition')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('transDecisionId').value;
  const status = document.getElementById('transTargetStatus').value;

  const payload = {
    status,
    actual_gross_price: Number(document.getElementById('transActualGross').value),
    actual_sale_date: document.getElementById('transSaleDate').value,
    actual_freight_cost: Number(document.getElementById('transFreight').value) || 0,
    actual_commission_fee: Number(document.getElementById('transCommission').value) || 0,
    actual_handling_fee: Number(document.getElementById('transHandling').value) || 0,
    buyer_name: document.getElementById('transBuyer').value,
    commission_agent_name: document.getElementById('transAgent').value,
    settlement_status: document.getElementById('transSettlementStatus').value,
    payment_mode: document.getElementById('transPaymentMode').value
  };

  try {
    await apiRequest(`/decisions/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify(payload)
    });

    showToast(`Status successfully updated to ${status}.`, 'success');
    closeModal('modalStatusTransition');
    loadDecisions();
    loadDashboard();
  } catch (err) {}
});

// --- TAB 5: MANDIS DIRECTORY ---
async function loadMandis() {
  try {
    const res = await apiRequest('/mandis');
    state.mandis = res.data || [];

    const tbody = document.getElementById('mandisTableBody');
    tbody.innerHTML = '';

    const isStaff = state.currentRole === 'operator' || state.currentRole === 'admin';
    document.getElementById('mandiAdminActions').style.display = isStaff ? 'block' : 'none';

    state.mandis.forEach((m) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong style="font-family: var(--font-mono);">${m.code}</strong></td>
        <td><strong>${m.name}</strong></td>
        <td>${m.district}, ${m.state}</td>
        <td>${m.standard_cess_pct}%</td>
        <td>${m.commission_agent_pct}%</td>
        <td>₹${m.hamali_fee_per_unit}</td>
        <td>₹${m.weighment_fee_per_unit}</td>
        <td>${m.default_distance_km} km</td>
        <td style="text-align: right;">
          <button class="btn btn-outline btn-sm btn-filter-mandi-prices" data-id="${m.id}">View Quotes</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error('Failed to load mandis:', err);
  }
}

document.getElementById('mandisTableBody')?.addEventListener('click', (e) => {
  const btn = e.target.closest('.btn-filter-mandi-prices');
  if (btn) {
    const mandiId = btn.dataset.id;
    state.priceFilters.mandi_id = mandiId;
    document.getElementById('filterPriceMandi').value = mandiId;
    switchTab('prices');
  }
});

document.getElementById('btnOpenNewMandiModal')?.addEventListener('click', () => {
  document.getElementById('formMandi').reset();
  openModal('modalMandi');
});

document.getElementById('formMandi')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    name: document.getElementById('mandiName').value,
    code: document.getElementById('mandiCode').value,
    state: document.getElementById('mandiState').value,
    district: document.getElementById('mandiDistrict').value,
    standard_cess_pct: Number(document.getElementById('mandiCess').value),
    commission_agent_pct: Number(document.getElementById('mandiComm').value),
    hamali_fee_per_unit: Number(document.getElementById('mandiLabor').value),
    default_distance_km: Number(document.getElementById('mandiDistance').value)
  };

  try {
    await apiRequest('/mandis', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    showToast('Mandi profile added successfully.', 'success');
    closeModal('modalMandi');
    loadMandis();
    loadMasterData();
  } catch (err) {}
});

// --- TAB 6: AUDIT LOGS ---
async function loadAuditLogs() {
  if (state.currentRole === 'member') {
    document.getElementById('auditTableBody').innerHTML = `
      <tr>
        <td colspan="6" style="text-align: center; color: #b91c1c; padding: 24px;">
          Forbidden: Audit trail access requires Operator or Admin authorization.
        </td>
      </tr>
    `;
    return;
  }

  try {
    const res = await apiRequest('/audit-logs');
    state.auditLogs = res.data || [];

    const tbody = document.getElementById('auditTableBody');
    tbody.innerHTML = '';

    if (state.auditLogs.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px;">No audit records.</td></tr>';
      return;
    }

    state.auditLogs.forEach((log) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td style="font-size: 0.8rem; color: #64748b;">${new Date(log.created_at).toLocaleString('en-IN')}</td>
        <td><strong style="color: #0369a1;">${log.action}</strong></td>
        <td><span class="badge" style="background: #e2e8f0;">${log.role}</span></td>
        <td>${log.entity_type}</td>
        <td style="font-family: var(--font-mono); font-size: 0.75rem;">${JSON.stringify(log.details)}</td>
        <td style="font-size: 0.8rem; color: #94a3b8;">${log.ip_address || '127.0.0.1'}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {}
}

document.getElementById('btnResetDemoData')?.addEventListener('click', async () => {
  if (!confirm('Reset all prices, decisions, and mandis back to initial deterministic seed data?')) return;

  try {
    await apiRequest('/system/reset-demo', { method: 'POST' });
    showToast('System reset to deterministic demo seed.', 'success');
    await loadMasterData();
    await loadDashboard();
    await loadPrices();
    await loadDecisions();
    await loadAuditLogs();
  } catch (err) {}
});

// --- Quick Navigation Buttons ---
document.getElementById('btnRefreshOverview')?.addEventListener('click', () => {
  loadDashboard();
  showToast('Overview metrics refreshed.', 'info');
});

document.getElementById('btnGoToCalculator')?.addEventListener('click', () => {
  switchTab('calculator');
});

// --- Role Switcher ---
document.getElementById('roleSelector')?.addEventListener('change', (e) => {
  state.currentRole = e.target.value;
  showToast(`Switched active role to: ${state.currentRole.toUpperCase()}`, 'info');

  // Adjust role visibility
  const isStaff = state.currentRole === 'operator' || state.currentRole === 'admin';
  document.getElementById('auditNavTab').style.display = isStaff ? 'flex' : 'none';

  // Reload current tab with new permissions
  switchTab(state.activeTab);
});

// Navigation Click Handler
document.querySelectorAll('.nav-tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    switchTab(btn.dataset.tab);
  });
});

// --- App Initialization ---
async function initApp() {
  await checkSystemHealth();
  await loadMasterData();

  // Check URL hash for direct tab navigation
  const hash = window.location.hash.replace('#', '');
  if (['overview', 'prices', 'calculator', 'decisions', 'mandis', 'audit'].includes(hash)) {
    switchTab(hash);
  } else {
    switchTab('overview');
  }

  // Pre-load calculator default comparison
  setTimeout(() => {
    if (state.crops.length > 0) {
      document.getElementById('calcCropSelect').value = state.crops[0].id;
      runCalculator();
    }
  }, 300);
}

// Start app on DOMContentLoaded
document.addEventListener('DOMContentLoaded', initApp);
