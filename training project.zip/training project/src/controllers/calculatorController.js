import { dbService } from '../services/db.js';

export const calculatorController = {
  compareMandis(req, res, next) {
    try {
      const { crop_id, quantity, unit, quality_grade, mandi_ids, overrides } = req.body;
      const comparisonResult = dbService.compareMandis({
        crop_id,
        quantity,
        unit,
        quality_grade,
        mandi_ids,
        overrides
      });
      res.json({
        success: true,
        data: comparisonResult
      });
    } catch (err) {
      next(err);
    }
  }
};
