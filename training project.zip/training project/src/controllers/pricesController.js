import { dbService } from '../services/db.js';

export const pricesController = {
  async listPrices(req, res, next) {
    try {
      const filters = {
        crop_id: req.query.crop_id,
        mandi_id: req.query.mandi_id,
        grade: req.query.grade,
        data_source: req.query.data_source,
        verified: req.query.verified,
        date_from: req.query.date_from,
        date_to: req.query.date_to,
        search: req.query.search
      };
      const prices = await dbService.getMarketPrices(filters);
      res.json({
        success: true,
        count: prices.length,
        data: prices
      });
    } catch (err) {
      next(err);
    }
  },

  async getPrice(req, res, next) {
    try {
      const price = await dbService.getMarketPriceById(req.params.id);
      if (!price) {
        return res.status(404).json({ success: false, error: 'Market price record not found.' });
      }
      res.json({ success: true, data: price });
    } catch (err) {
      next(err);
    }
  },

  async createPrice(req, res, next) {
    try {
      const ip = req.ip || req.socket?.remoteAddress;
      const created = await dbService.createMarketPrice(req.body, req.user, ip);
      res.status(201).json({
        success: true,
        message: 'Market price quote successfully logged.',
        data: created
      });
    } catch (err) {
      next(err);
    }
  },

  async updatePrice(req, res, next) {
    try {
      const ip = req.ip || req.socket?.remoteAddress;
      const updated = await dbService.updateMarketPrice(req.params.id, req.body, req.user, ip);
      if (!updated) {
        return res.status(404).json({ success: false, error: 'Market price record not found.' });
      }
      res.json({
        success: true,
        message: 'Market price quote successfully updated.',
        data: updated
      });
    } catch (err) {
      next(err);
    }
  },

  async deletePrice(req, res, next) {
    try {
      const ip = req.ip || req.socket?.remoteAddress;
      const deleted = await dbService.deleteMarketPrice(req.params.id, req.user, ip);
      if (!deleted) {
        return res.status(404).json({ success: false, error: 'Market price record not found.' });
      }
      res.json({
        success: true,
        message: 'Market price quote successfully deleted.'
      });
    } catch (err) {
      next(err);
    }
  }
};
