import { dbService } from '../services/db.js';

export const masterDataController = {
  // Crops
  async listCrops(req, res, next) {
    try {
      const crops = await dbService.getCrops();
      res.json({ success: true, count: crops.length, data: crops });
    } catch (err) {
      next(err);
    }
  },

  async createCrop(req, res, next) {
    try {
      const { name, hindi_name, category, standard_unit, standard_moisture_pct } = req.body;
      if (!name || typeof name !== 'string') {
        return res.status(400).json({ success: false, error: 'Crop name is required.' });
      }
      const crop = await dbService.createCrop(
        { name, hindi_name, category, standard_unit, standard_moisture_pct },
        req.user
      );
      res.status(201).json({ success: true, message: 'Crop created successfully', data: crop });
    } catch (err) {
      next(err);
    }
  },

  // Mandis
  async listMandis(req, res, next) {
    try {
      const mandis = await dbService.getMandis();
      res.json({ success: true, count: mandis.length, data: mandis });
    } catch (err) {
      next(err);
    }
  },

  async createMandi(req, res, next) {
    try {
      const { name, code, state, district, standard_cess_pct, commission_agent_pct, hamali_fee_per_unit, default_distance_km } = req.body;
      if (!name || !code || !state || !district) {
        return res.status(400).json({
          success: false,
          error: 'name, code, state, and district are required fields for a Mandi.'
        });
      }
      const mandi = await dbService.createMandi(req.body, req.user);
      res.status(201).json({ success: true, message: 'Mandi created successfully', data: mandi });
    } catch (err) {
      next(err);
    }
  },

  async updateMandi(req, res, next) {
    try {
      const mandi = await dbService.updateMandi(req.params.id, req.body, req.user);
      if (!mandi) {
        return res.status(404).json({ success: false, error: 'Mandi not found.' });
      }
      res.json({ success: true, message: 'Mandi fee rules updated successfully', data: mandi });
    } catch (err) {
      next(err);
    }
  }
};
