import { dbService, localStore, SEED_USERS } from '../services/db.js';
import { isSupabaseConfigured } from '../config/database.js';

export const systemController = {
  getHealth(req, res) {
    res.json({
      success: true,
      service: 'MandiLens API',
      version: '1.0.0',
      status: 'operational',
      database: isSupabaseConfigured ? 'supabase_postgresql_connected' : 'local_storage_engine',
      user: {
        id: req.user?.id,
        role: req.user?.role,
        full_name: req.user?.full_name
      },
      timestamp: new Date().toISOString()
    });
  },

  async getAuditLogs(req, res, next) {
    try {
      const limit = Number(req.query.limit) || 50;
      const logs = await dbService.getAuditLogs(limit);
      res.json({
        success: true,
        count: logs.length,
        data: logs
      });
    } catch (err) {
      next(err);
    }
  },

  getAvailableUsers(req, res) {
    const safeUsers = SEED_USERS.map((u) => ({
      id: u.id,
      email: u.email,
      full_name: u.full_name,
      role: u.role,
      hub_location: u.hub_location
    }));
    res.json({
      success: true,
      data: safeUsers
    });
  },

  resetDemo(req, res, next) {
    try {
      dbService.resetDemoData(req.user);
      res.json({
        success: true,
        message: 'System database reset to initial deterministic demo seed.'
      });
    } catch (err) {
      next(err);
    }
  }
};
