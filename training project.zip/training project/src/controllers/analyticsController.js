import { dbService } from '../services/db.js';

export const analyticsController = {
  getDashboard(req, res, next) {
    try {
      const stats = dbService.getDashboardMetrics(req.user);
      res.json({
        success: true,
        data: stats
      });
    } catch (err) {
      next(err);
    }
  }
};
