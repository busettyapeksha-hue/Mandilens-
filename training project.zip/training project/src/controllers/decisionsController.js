import { dbService } from '../services/db.js';

export const decisionsController = {
  async listDecisions(req, res, next) {
    try {
      const filters = {
        status: req.query.status,
        crop_id: req.query.crop_id,
        chosen_mandi_id: req.query.chosen_mandi_id,
        search: req.query.search
      };
      const decisions = await dbService.getSellingDecisions(filters, req.user);
      res.json({
        success: true,
        count: decisions.length,
        data: decisions
      });
    } catch (err) {
      next(err);
    }
  },

  async getDecision(req, res, next) {
    try {
      const decision = await dbService.getSellingDecisionById(req.params.id, req.user);
      if (!decision) {
        return res.status(404).json({ success: false, error: 'Selling decision not found.' });
      }
      res.json({ success: true, data: decision });
    } catch (err) {
      next(err);
    }
  },

  async createDecision(req, res, next) {
    try {
      const ip = req.ip || req.socket?.remoteAddress;
      const created = await dbService.createSellingDecision(req.body, req.user, ip);
      res.status(201).json({
        success: true,
        message: 'Selling decision lot created successfully.',
        data: created
      });
    } catch (err) {
      next(err);
    }
  },

  async transitionStatus(req, res, next) {
    try {
      const ip = req.ip || req.socket?.remoteAddress;
      const updated = await dbService.updateDecisionStatus(req.params.id, req.body, req.user, ip);
      if (!updated) {
        return res.status(404).json({ success: false, error: 'Selling decision not found.' });
      }
      res.json({
        success: true,
        message: `Status successfully changed to ${updated.status}`,
        data: updated
      });
    } catch (err) {
      next(err);
    }
  },

  async deleteDecision(req, res, next) {
    try {
      const ip = req.ip || req.socket?.remoteAddress;
      const deleted = await dbService.deleteSellingDecision(req.params.id, req.user, ip);
      if (!deleted) {
        return res.status(404).json({ success: false, error: 'Selling decision not found.' });
      }
      res.json({
        success: true,
        message: 'Selling decision lot deleted successfully.'
      });
    } catch (err) {
      next(err);
    }
  }
};
