import dotenv from 'dotenv';
import ws from 'ws';
import { createClient } from '@supabase/supabase-js';

dotenv.config();

if (typeof globalThis.WebSocket === 'undefined') {
  globalThis.WebSocket = ws;
}

const SUPABASE_URL = process.env.SUPABASE_URL || '';
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY || '';

const isPlaceholder = (val) => {
  if (!val) return true;
  return (
    val.includes('your-project-id') ||
    val.includes('...') ||
    val.trim() === ''
  );
};

export const isSupabaseConfigured = Boolean(
  SUPABASE_URL &&
  SUPABASE_KEY &&
  !isPlaceholder(SUPABASE_URL) &&
  !isPlaceholder(SUPABASE_KEY)
);

let supabaseClient = null;

if (isSupabaseConfigured) {
  try {
    supabaseClient = createClient(SUPABASE_URL, SUPABASE_KEY, {
      auth: { persistSession: false }
    });
    console.log('[Database] Initialized official Supabase client for remote PostgreSQL.');
  } catch (err) {
    console.warn('[Database] Failed to initialize Supabase client:', err.message);
  }
} else {
  console.log('[Database] Remote Supabase credentials not configured or using placeholders. Safe Local Repository active.');
}

export { supabaseClient };
