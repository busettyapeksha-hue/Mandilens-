import crypto from 'crypto';
import { supabaseClient, isSupabaseConfigured } from '../config/database.js';

// Initial Seed Datasets matching supabase/seed.sql
export const SEED_USERS = [
  {
    id: '11111111-1111-4111-8111-111111111111',
    email: 'farmer.ramesh@mandilens.in',
    full_name: 'Ramesh Kumar (Kisan)',
    role: 'member',
    phone: '+91 98120 44211',
    hub_location: 'Karnal, Haryana'
  },
  {
    id: '22222222-2222-4222-8222-222222222222',
    email: 'farmer.sunita@mandilens.in',
    full_name: 'Sunita Patil (FPO Lead)',
    role: 'member',
    phone: '+91 94220 88319',
    hub_location: 'Nashik, Maharashtra'
  },
  {
    id: '33333333-3333-4333-8333-333333333333',
    email: 'operator.rajesh@mandilens.in',
    full_name: 'Rajesh Sharma (Mandi Surveyor)',
    role: 'operator',
    phone: '+91 97110 55321',
    hub_location: 'Azadpur Yard 4'
  },
  {
    id: '44444444-4444-4444-8444-444444444444',
    email: 'admin.director@mandilens.in',
    full_name: 'Devendra Singh (APMC Admin)',
    role: 'admin',
    phone: '+91 99990 00100',
    hub_location: 'New Delhi APMC Board'
  }
];

export const SEED_CROPS = [
  {
    id: 'c1010101-0000-0000-0000-000000000001',
    name: 'Wheat (Sharbati/HD-2967)',
    hindi_name: 'गेहूं (शरबती / HD-2967)',
    category: 'Cereals',
    standard_unit: 'Quintal',
    standard_moisture_pct: 12.0,
    active: true
  },
  {
    id: 'c1010101-0000-0000-0000-000000000002',
    name: 'Basmati Rice (1121 Paddy)',
    hindi_name: 'बासमती धान (1121 पैडी)',
    category: 'Cereals',
    standard_unit: 'Quintal',
    standard_moisture_pct: 13.5,
    active: true
  },
  {
    id: 'c1010101-0000-0000-0000-000000000003',
    name: 'Chana (Desi Bengal Gram)',
    hindi_name: 'चना (देसी चना)',
    category: 'Pulses',
    standard_unit: 'Quintal',
    standard_moisture_pct: 11.0,
    active: true
  },
  {
    id: 'c1010101-0000-0000-0000-000000000004',
    name: 'Mustard (Sarson / Black)',
    hindi_name: 'सरसों (काली सरसों)',
    category: 'Oilseeds',
    standard_unit: 'Quintal',
    standard_moisture_pct: 8.0,
    active: true
  },
  {
    id: 'c1010101-0000-0000-0000-000000000005',
    name: 'Soybean (Yellow Seed)',
    hindi_name: 'सोयाबीन (पीला दाना)',
    category: 'Oilseeds',
    standard_unit: 'Quintal',
    standard_moisture_pct: 10.0,
    active: true
  },
  {
    id: 'c1010101-0000-0000-0000-000000000006',
    name: 'Onion (Nashik Red)',
    hindi_name: 'प्याज (नासिक लाल)',
    category: 'Vegetables',
    standard_unit: 'Quintal',
    standard_moisture_pct: 14.0,
    active: true
  },
  {
    id: 'c1010101-0000-0000-0000-000000000007',
    name: 'Tomato (Hybrid Desi)',
    hindi_name: 'टमाटर (हाइब्रिड)',
    category: 'Vegetables',
    standard_unit: 'Crate',
    standard_moisture_pct: 15.0,
    active: true
  },
  {
    id: 'c1010101-0000-0000-0000-000000000008',
    name: 'Potato (Kufri Jyoti)',
    hindi_name: 'आलू (कुफरी ज्योति)',
    category: 'Vegetables',
    standard_unit: '50kg Bag',
    standard_moisture_pct: 13.0,
    active: true
  },
  {
    id: 'c1010101-0000-0000-0000-000000000009',
    name: 'Cotton (Medium Staple)',
    hindi_name: 'कपास (मध्यम रेशा)',
    category: 'Fiber/Cash',
    standard_unit: 'Quintal',
    standard_moisture_pct: 9.0,
    active: true
  },
  {
    id: 'c1010101-0000-0000-0000-000000000010',
    name: 'Turmeric (Salem/Nizamabad)',
    hindi_name: 'हल्दी (निजामाबाद फिंगर)',
    category: 'Spices',
    standard_unit: 'Quintal',
    standard_moisture_pct: 9.5,
    active: true
  }
];

export const SEED_MANDIS = [
  {
    id: 'b2020202-0000-0000-0000-000000000001',
    name: 'Azadpur APMC',
    code: 'DL-AZD',
    state: 'Delhi',
    district: 'North Delhi',
    standard_cess_pct: 1.0,
    commission_agent_pct: 2.0,
    hamali_fee_per_unit: 14.0,
    weighment_fee_per_unit: 4.0,
    default_distance_km: 125.0,
    active: true
  },
  {
    id: 'b2020202-0000-0000-0000-000000000002',
    name: 'Karnal Grain Market',
    code: 'HR-KNL',
    state: 'Haryana',
    district: 'Karnal',
    standard_cess_pct: 1.5,
    commission_agent_pct: 1.5,
    hamali_fee_per_unit: 10.0,
    weighment_fee_per_unit: 2.5,
    default_distance_km: 18.0,
    active: true
  },
  {
    id: 'b2020202-0000-0000-0000-000000000003',
    name: 'Khanna Grain Market',
    code: 'PB-KHN',
    state: 'Punjab',
    district: 'Ludhiana',
    standard_cess_pct: 2.0,
    commission_agent_pct: 2.5,
    hamali_fee_per_unit: 12.0,
    weighment_fee_per_unit: 3.0,
    default_distance_km: 140.0,
    active: true
  },
  {
    id: 'b2020202-0000-0000-0000-000000000004',
    name: 'Lasalgaon APMC',
    code: 'MH-LSG',
    state: 'Maharashtra',
    district: 'Nashik',
    standard_cess_pct: 1.05,
    commission_agent_pct: 2.0,
    hamali_fee_per_unit: 15.0,
    weighment_fee_per_unit: 3.5,
    default_distance_km: 35.0,
    active: true
  },
  {
    id: 'b2020202-0000-0000-0000-000000000005',
    name: 'Vashi APMC',
    code: 'MH-VSH',
    state: 'Maharashtra',
    district: 'Navi Mumbai',
    standard_cess_pct: 1.0,
    commission_agent_pct: 2.0,
    hamali_fee_per_unit: 18.0,
    weighment_fee_per_unit: 5.0,
    default_distance_km: 195.0,
    active: true
  },
  {
    id: 'b2020202-0000-0000-0000-000000000006',
    name: 'Neemuch Mandi',
    code: 'MP-NMC',
    state: 'Madhya Pradesh',
    district: 'Neemuch',
    standard_cess_pct: 1.2,
    commission_agent_pct: 1.75,
    hamali_fee_per_unit: 11.0,
    weighment_fee_per_unit: 2.5,
    default_distance_km: 85.0,
    active: true
  },
  {
    id: 'b2020202-0000-0000-0000-000000000007',
    name: 'Gondal APMC',
    code: 'GJ-GND',
    state: 'Gujarat',
    district: 'Rajkot',
    standard_cess_pct: 0.8,
    commission_agent_pct: 1.5,
    hamali_fee_per_unit: 12.0,
    weighment_fee_per_unit: 3.0,
    default_distance_km: 95.0,
    active: true
  },
  {
    id: 'b2020202-0000-0000-0000-000000000008',
    name: 'Nizamabad APMC',
    code: 'TS-NZB',
    state: 'Telangana',
    district: 'Nizamabad',
    standard_cess_pct: 1.0,
    commission_agent_pct: 2.0,
    hamali_fee_per_unit: 13.0,
    weighment_fee_per_unit: 3.0,
    default_distance_km: 60.0,
    active: true
  }
];

export const SEED_PRICES = [
  {
    id: 'a3030303-0000-0000-0000-000000000001',
    crop_id: 'c1010101-0000-0000-0000-000000000001',
    mandi_id: 'b2020202-0000-0000-0000-000000000001',
    price_date: '2026-10-26',
    quality_grade: 'Grade A / FAQ',
    min_price: 2420.0,
    modal_price: 2520.0,
    max_price: 2600.0,
    unit: 'Quintal',
    data_source: 'seeded_demo',
    verified: true,
    verified_by: '33333333-3333-4333-8333-333333333333',
    distance_km: 125.0,
    transport_estimate_per_unit: 85.0,
    commission_pct_applied: 2.0,
    labor_fee_per_unit_applied: 18.0,
    cess_pct_applied: 1.0,
    estimated_net_realization: 2341.4,
    notes: 'High mill buying interest from flour mills in Delhi NCR.',
    created_by: '33333333-3333-4333-8333-333333333333',
    created_at: new Date('2026-10-26T08:30:00Z').toISOString()
  },
  {
    id: 'a3030303-0000-0000-0000-000000000002',
    crop_id: 'c1010101-0000-0000-0000-000000000001',
    mandi_id: 'b2020202-0000-0000-0000-000000000002',
    price_date: '2026-10-26',
    quality_grade: 'Grade A / FAQ',
    min_price: 2350.0,
    modal_price: 2410.0,
    max_price: 2450.0,
    unit: 'Quintal',
    data_source: 'seeded_demo',
    verified: true,
    verified_by: '33333333-3333-4333-8333-333333333333',
    distance_km: 18.0,
    transport_estimate_per_unit: 25.0,
    commission_pct_applied: 1.5,
    labor_fee_per_unit_applied: 12.5,
    cess_pct_applied: 1.5,
    estimated_net_realization: 2300.2,
    notes: 'Local Karnal grain arrivals steady, low transit friction.',
    created_by: '11111111-1111-4111-8111-111111111111',
    created_at: new Date('2026-10-26T09:15:00Z').toISOString()
  },
  {
    id: 'a3030303-0000-0000-0000-000000000003',
    crop_id: 'c1010101-0000-0000-0000-000000000001',
    mandi_id: 'b2020202-0000-0000-0000-000000000003',
    price_date: '2026-10-26',
    quality_grade: 'Grade A / FAQ',
    min_price: 2380.0,
    modal_price: 2460.0,
    max_price: 2510.0,
    unit: 'Quintal',
    data_source: 'market_survey',
    verified: false,
    verified_by: null,
    distance_km: 140.0,
    transport_estimate_per_unit: 95.0,
    commission_pct_applied: 2.5,
    labor_fee_per_unit_applied: 15.0,
    cess_pct_applied: 2.0,
    estimated_net_realization: 2239.3,
    notes: 'Khanna spot survey shows moderate procurement rates.',
    created_by: '33333333-3333-4333-8333-333333333333',
    created_at: new Date('2026-10-26T10:00:00Z').toISOString()
  },
  {
    id: 'a3030303-0000-0000-0000-000000000004',
    crop_id: 'c1010101-0000-0000-0000-000000000002',
    mandi_id: 'b2020202-0000-0000-0000-000000000002',
    price_date: '2026-10-26',
    quality_grade: 'Grade A / FAQ',
    min_price: 3800.0,
    modal_price: 3950.0,
    max_price: 4120.0,
    unit: 'Quintal',
    data_source: 'manual_entry',
    verified: true,
    verified_by: '33333333-3333-4333-8333-333333333333',
    distance_km: 18.0,
    transport_estimate_per_unit: 30.0,
    commission_pct_applied: 1.5,
    labor_fee_per_unit_applied: 12.5,
    cess_pct_applied: 1.5,
    estimated_net_realization: 3789.0,
    notes: 'Karnal yard exporters active for premium 1121 lots.',
    created_by: '11111111-1111-4111-8111-111111111111',
    created_at: new Date('2026-10-26T10:30:00Z').toISOString()
  },
  {
    id: 'a3030303-0000-0000-0000-000000000005',
    crop_id: 'c1010101-0000-0000-0000-000000000002',
    mandi_id: 'b2020202-0000-0000-0000-000000000001',
    price_date: '2026-10-26',
    quality_grade: 'Grade A / FAQ',
    min_price: 4050.0,
    modal_price: 4200.0,
    max_price: 4350.0,
    unit: 'Quintal',
    data_source: 'seeded_demo',
    verified: true,
    verified_by: '33333333-3333-4333-8333-333333333333',
    distance_km: 125.0,
    transport_estimate_per_unit: 95.0,
    commission_pct_applied: 2.0,
    labor_fee_per_unit_applied: 18.0,
    cess_pct_applied: 1.0,
    estimated_net_realization: 3961.0,
    notes: 'Premium quote in Delhi, covers transport cost with surplus.',
    created_by: '33333333-3333-4333-8333-333333333333',
    created_at: new Date('2026-10-26T11:00:00Z').toISOString()
  },
  {
    id: 'a3030303-0000-0000-0000-000000000006',
    crop_id: 'c1010101-0000-0000-0000-000000000006',
    mandi_id: 'b2020202-0000-0000-0000-000000000004',
    price_date: '2026-10-26',
    quality_grade: 'Grade A / FAQ',
    min_price: 1900.0,
    modal_price: 2050.0,
    max_price: 2200.0,
    unit: 'Quintal',
    data_source: 'seeded_demo',
    verified: true,
    verified_by: '33333333-3333-4333-8333-333333333333',
    distance_km: 35.0,
    transport_estimate_per_unit: 40.0,
    commission_pct_applied: 2.0,
    labor_fee_per_unit_applied: 18.5,
    cess_pct_applied: 1.05,
    estimated_net_realization: 1928.98,
    notes: 'Heavy daily auction volume at Asia largest onion yard.',
    created_by: '22222222-2222-4222-8222-222222222222',
    created_at: new Date('2026-10-26T11:30:00Z').toISOString()
  },
  {
    id: 'a3030303-0000-0000-0000-000000000007',
    crop_id: 'c1010101-0000-0000-0000-000000000006',
    mandi_id: 'b2020202-0000-0000-0000-000000000005',
    price_date: '2026-10-26',
    quality_grade: 'Grade A / FAQ',
    min_price: 2450.0,
    modal_price: 2600.0,
    max_price: 2750.0,
    unit: 'Quintal',
    data_source: 'market_survey',
    verified: false,
    verified_by: null,
    distance_km: 195.0,
    transport_estimate_per_unit: 140.0,
    commission_pct_applied: 2.0,
    labor_fee_per_unit_applied: 23.0,
    cess_pct_applied: 1.0,
    estimated_net_realization: 2359.0,
    notes: 'Mumbai terminal market trades at significant premium.',
    created_by: '33333333-3333-4333-8333-333333333333',
    created_at: new Date('2026-10-26T12:00:00Z').toISOString()
  },
  {
    id: 'a3030303-0000-0000-0000-000000000008',
    crop_id: 'c1010101-0000-0000-0000-000000000004',
    mandi_id: 'b2020202-0000-0000-0000-000000000006',
    price_date: '2026-10-26',
    quality_grade: 'Grade A / FAQ',
    min_price: 5300.0,
    modal_price: 5450.0,
    max_price: 5600.0,
    unit: 'Quintal',
    data_source: 'seeded_demo',
    verified: true,
    verified_by: '33333333-3333-4333-8333-333333333333',
    distance_km: 85.0,
    transport_estimate_per_unit: 75.0,
    commission_pct_applied: 1.75,
    labor_fee_per_unit_applied: 13.5,
    cess_pct_applied: 1.2,
    estimated_net_realization: 5200.73,
    notes: 'Neemuch oil mill crushing demand strong.',
    created_by: '33333333-3333-4333-8333-333333333333',
    created_at: new Date('2026-10-26T12:30:00Z').toISOString()
  }
];

export const SEED_DECISIONS = [
  {
    id: 'd4040404-0000-0000-0000-000000000001',
    lot_reference: 'LOT-2026-WHT-01',
    crop_id: 'c1010101-0000-0000-0000-000000000001',
    quantity: 85.0,
    unit: 'Quintal',
    quality_grade: 'Grade A / FAQ',
    harvest_date: '2026-10-20',
    chosen_mandi_id: 'b2020202-0000-0000-0000-000000000001',
    status: 'SETTLED',
    expected_gross_price: 2520.0,
    expected_freight_cost: 7225.0,
    expected_commission_fee: 4284.0,
    expected_handling_fee: 1530.0,
    expected_net_price_per_unit: 2366.6,
    expected_total_net_realization: 201161.0,
    alternative_mandis_evaluated: [
      { mandi_name: 'Karnal Grain Market', modal_price: 2410, net_realization: 195517 },
      { mandi_name: 'Azadpur APMC', modal_price: 2520, net_realization: 201161 }
    ],
    decision_rationale: 'Azadpur buyer agreed to pay Rs 2520/qtl which gave Rs 5,644 extra net realization over Karnal after deducting 125km freight and agent commission.',
    buyer_name: 'Rajdhani Agro Foods Pvt Ltd',
    commission_agent_name: 'M/s Aggarwal & Sons (Aadathiya)',
    actual_sale_date: '2026-10-22',
    actual_gross_price: 2530.0,
    actual_freight_cost: 7200.0,
    actual_commission_fee: 4301.0,
    actual_handling_fee: 1530.0,
    actual_net_price_per_unit: 2376.69,
    actual_total_net_realization: 202019.0,
    variance_net_revenue: 858.0,
    settlement_status: 'RECEIVED',
    payment_mode: 'NEFT_RTGS',
    created_by: '11111111-1111-4111-8111-111111111111',
    created_at: new Date('2026-10-20T14:00:00Z').toISOString(),
    updated_at: new Date('2026-10-22T17:00:00Z').toISOString()
  },
  {
    id: 'd4040404-0000-0000-0000-000000000002',
    lot_reference: 'LOT-2026-BAS-02',
    crop_id: 'c1010101-0000-0000-0000-000000000002',
    quantity: 120.0,
    unit: 'Quintal',
    quality_grade: 'Grade A / FAQ',
    harvest_date: '2026-10-22',
    chosen_mandi_id: 'b2020202-0000-0000-0000-000000000002',
    status: 'EXECUTED',
    expected_gross_price: 3950.0,
    expected_freight_cost: 3600.0,
    expected_commission_fee: 7110.0,
    expected_handling_fee: 1500.0,
    expected_net_price_per_unit: 3848.25,
    expected_total_net_realization: 461790.0,
    alternative_mandis_evaluated: [
      { mandi_name: 'Karnal Grain Market', modal_price: 3950, net_realization: 461790 },
      { mandi_name: 'Khanna Grain Market', modal_price: 4010, net_realization: 458200 }
    ],
    decision_rationale: 'Sold locally at Karnal because prompt cash payment and zero inter-state road checkpost delays made local realization faster and risk-free.',
    buyer_name: 'Karnal Rice Mills Ltd',
    commission_agent_name: 'Chaudhary Dataram & Co.',
    actual_sale_date: '2026-10-25',
    actual_gross_price: 3940.0,
    actual_freight_cost: 3600.0,
    actual_commission_fee: 7092.0,
    actual_handling_fee: 1500.0,
    actual_net_price_per_unit: 3838.4,
    actual_total_net_realization: 460608.0,
    variance_net_revenue: -1182.0,
    settlement_status: 'PARTIAL',
    payment_mode: 'NEFT_RTGS',
    created_by: '11111111-1111-4111-8111-111111111111',
    created_at: new Date('2026-10-22T16:00:00Z').toISOString(),
    updated_at: new Date('2026-10-25T18:00:00Z').toISOString()
  },
  {
    id: 'd4040404-0000-0000-0000-000000000003',
    lot_reference: 'LOT-2026-MST-03',
    crop_id: 'c1010101-0000-0000-0000-000000000004',
    quantity: 60.0,
    unit: 'Quintal',
    quality_grade: 'Grade A / FAQ',
    harvest_date: '2026-10-24',
    chosen_mandi_id: 'b2020202-0000-0000-0000-000000000006',
    status: 'IN_TRANSIT',
    expected_gross_price: 5450.0,
    expected_freight_cost: 4500.0,
    expected_commission_fee: 5722.5,
    expected_handling_fee: 810.0,
    expected_net_price_per_unit: 5266.12,
    expected_total_net_realization: 315967.5,
    alternative_mandis_evaluated: [
      { mandi_name: 'Neemuch Mandi', modal_price: 5450, net_realization: 315967 }
    ],
    decision_rationale: 'High oil percentage (41.5%) certified in sample test. Neemuch oil crushers paying Rs 150 premium over local Kota rate.',
    buyer_name: 'Neemuch Oil & Solvents',
    commission_agent_name: 'M/s Porwal Brothers',
    actual_sale_date: null,
    actual_gross_price: null,
    actual_freight_cost: null,
    actual_commission_fee: null,
    actual_handling_fee: null,
    actual_net_price_per_unit: null,
    actual_total_net_realization: null,
    variance_net_revenue: null,
    settlement_status: 'PENDING',
    payment_mode: null,
    created_by: '11111111-1111-4111-8111-111111111111',
    created_at: new Date('2026-10-24T10:00:00Z').toISOString(),
    updated_at: new Date('2026-10-24T10:00:00Z').toISOString()
  },
  {
    id: 'd4040404-0000-0000-0000-000000000004',
    lot_reference: 'LOT-2026-ONN-04',
    crop_id: 'c1010101-0000-0000-0000-000000000006',
    quantity: 150.0,
    unit: 'Quintal',
    quality_grade: 'Grade A / FAQ',
    harvest_date: '2026-10-25',
    chosen_mandi_id: 'b2020202-0000-0000-0000-000000000005',
    status: 'PLANNED',
    expected_gross_price: 2600.0,
    expected_freight_cost: 21000.0,
    expected_commission_fee: 7800.0,
    expected_handling_fee: 3450.0,
    expected_net_price_per_unit: 2385.0,
    expected_total_net_realization: 357750.0,
    alternative_mandis_evaluated: [
      { mandi_name: 'Lasalgaon APMC', modal_price: 2050, net_realization: 289350 },
      { mandi_name: 'Vashi APMC', modal_price: 2600, net_realization: 357750 }
    ],
    decision_rationale: 'Comparative realization analysis confirms Vashi yields +Rs 68,400 higher total profit even after paying Rs 21,000 in truck transport from Nashik to Navi Mumbai.',
    buyer_name: 'Direct Wholesaler Syndicate',
    commission_agent_name: 'Patil Traders Vashi',
    actual_sale_date: null,
    actual_gross_price: null,
    actual_freight_cost: null,
    actual_commission_fee: null,
    actual_handling_fee: null,
    actual_net_price_per_unit: null,
    actual_total_net_realization: null,
    variance_net_revenue: null,
    settlement_status: 'PENDING',
    payment_mode: null,
    created_by: '22222222-2222-4222-8222-222222222222',
    created_at: new Date('2026-10-25T09:00:00Z').toISOString(),
    updated_at: new Date('2026-10-25T09:00:00Z').toISOString()
  }
];

export const SEED_AUDIT_LOGS = [
  {
    id: 'a5050505-0000-0000-0000-000000000001',
    user_id: '44444444-4444-4444-8444-444444444444',
    role: 'admin',
    action: 'SYSTEM_INIT',
    entity_type: 'system',
    entity_id: 'sys-01',
    details: { event: 'MandiLens system seeded with standard crops and APMC mandis' },
    ip_address: '127.0.0.1',
    created_at: new Date('2026-10-26T00:00:00Z').toISOString()
  },
  {
    id: 'a5050505-0000-0000-0000-000000000002',
    user_id: '11111111-1111-4111-8111-111111111111',
    role: 'member',
    action: 'CREATE_DECISION',
    entity_type: 'decision',
    entity_id: 'd4040404-0000-0000-0000-000000000001',
    details: { lot: 'LOT-2026-WHT-01', mandi: 'Azadpur APMC', status: 'SETTLED' },
    ip_address: '127.0.0.1',
    created_at: new Date('2026-10-20T14:00:00Z').toISOString()
  },
  {
    id: 'a5050505-0000-0000-0000-000000000003',
    user_id: '22222222-2222-4222-8222-222222222222',
    role: 'member',
    action: 'CREATE_DECISION',
    entity_type: 'decision',
    entity_id: 'd4040404-0000-0000-0000-000000000004',
    details: { lot: 'LOT-2026-ONN-04', mandi: 'Vashi APMC', status: 'PLANNED' },
    ip_address: '127.0.0.1',
    created_at: new Date('2026-10-25T09:00:00Z').toISOString()
  }
];

// Local Repository Store (Deterministic, Persistent in-memory with strict schema constraints)
class LocalRepository {
  constructor() {
    this.reset();
  }

  reset() {
    this.users = JSON.parse(JSON.stringify(SEED_USERS));
    this.crops = JSON.parse(JSON.stringify(SEED_CROPS));
    this.mandis = JSON.parse(JSON.stringify(SEED_MANDIS));
    this.marketPrices = JSON.parse(JSON.stringify(SEED_PRICES));
    this.sellingDecisions = JSON.parse(JSON.stringify(SEED_DECISIONS));
    this.auditLogs = JSON.parse(JSON.stringify(SEED_AUDIT_LOGS));
  }

  // --- Users ---
  getUserById(id) {
    return this.users.find((u) => u.id === id) || null;
  }
  getUserByRole(role) {
    return this.users.find((u) => u.role === role) || this.users[0];
  }

  // --- Crops ---
  getAllCrops() {
    return [...this.crops];
  }
  getCropById(id) {
    return this.crops.find((c) => c.id === id) || null;
  }
  createCrop(data) {
    if (this.crops.some((c) => c.name.toLowerCase() === data.name.trim().toLowerCase())) {
      const err = new Error(`Crop with name "${data.name}" already exists.`);
      err.statusCode = 409;
      throw err;
    }
    const newCrop = {
      id: data.id || crypto.randomUUID(),
      name: data.name.trim(),
      hindi_name: data.hindi_name?.trim() || data.name.trim(),
      category: data.category || 'Cereals',
      standard_unit: data.standard_unit || 'Quintal',
      standard_moisture_pct: Number(data.standard_moisture_pct) || 12.0,
      active: data.active !== false,
      created_at: new Date().toISOString()
    };
    this.crops.push(newCrop);
    return newCrop;
  }

  // --- Mandis ---
  getAllMandis() {
    return [...this.mandis];
  }
  getMandiById(id) {
    return this.mandis.find((m) => m.id === id) || null;
  }
  createMandi(data) {
    if (this.mandis.some((m) => m.code.toUpperCase() === data.code.trim().toUpperCase())) {
      const err = new Error(`Mandi with code "${data.code}" already exists.`);
      err.statusCode = 409;
      throw err;
    }
    const newMandi = {
      id: data.id || crypto.randomUUID(),
      name: data.name.trim(),
      code: data.code.trim().toUpperCase(),
      state: data.state.trim(),
      district: data.district.trim(),
      standard_cess_pct: Number(data.standard_cess_pct) || 1.0,
      commission_agent_pct: Number(data.commission_agent_pct) || 2.0,
      hamali_fee_per_unit: Number(data.hamali_fee_per_unit) || 12.0,
      weighment_fee_per_unit: Number(data.weighment_fee_per_unit) || 3.0,
      default_distance_km: Number(data.default_distance_km) || 35.0,
      active: data.active !== false,
      created_at: new Date().toISOString()
    };
    this.mandis.push(newMandi);
    return newMandi;
  }
  updateMandi(id, data) {
    const mandi = this.getMandiById(id);
    if (!mandi) return null;
    if (data.name) mandi.name = data.name.trim();
    if (data.standard_cess_pct !== undefined) mandi.standard_cess_pct = Number(data.standard_cess_pct);
    if (data.commission_agent_pct !== undefined) mandi.commission_agent_pct = Number(data.commission_agent_pct);
    if (data.hamali_fee_per_unit !== undefined) mandi.hamali_fee_per_unit = Number(data.hamali_fee_per_unit);
    if (data.weighment_fee_per_unit !== undefined) mandi.weighment_fee_per_unit = Number(data.weighment_fee_per_unit);
    if (data.default_distance_km !== undefined) mandi.default_distance_km = Number(data.default_distance_km);
    if (data.active !== undefined) mandi.active = Boolean(data.active);
    return mandi;
  }

  // --- Market Prices ---
  getAllMarketPrices(filters = {}) {
    let list = this.marketPrices.map((p) => {
      const crop = this.getCropById(p.crop_id);
      const mandi = this.getMandiById(p.mandi_id);
      return {
        ...p,
        crop_name: crop ? crop.name : 'Unknown Crop',
        crop_hindi: crop ? crop.hindi_name : '',
        crop_category: crop ? crop.category : '',
        mandi_name: mandi ? mandi.name : 'Unknown Mandi',
        mandi_state: mandi ? mandi.state : '',
        mandi_district: mandi ? mandi.district : '',
        mandi_code: mandi ? mandi.code : ''
      };
    });

    if (filters.crop_id) {
      list = list.filter((p) => p.crop_id === filters.crop_id);
    }
    if (filters.mandi_id) {
      list = list.filter((p) => p.mandi_id === filters.mandi_id);
    }
    if (filters.grade) {
      list = list.filter((p) => p.quality_grade === filters.grade);
    }
    if (filters.data_source) {
      list = list.filter((p) => p.data_source === filters.data_source);
    }
    if (filters.verified !== undefined && filters.verified !== '') {
      const isVer = filters.verified === 'true' || filters.verified === true;
      list = list.filter((p) => p.verified === isVer);
    }
    if (filters.date_from) {
      list = list.filter((p) => p.price_date >= filters.date_from);
    }
    if (filters.date_to) {
      list = list.filter((p) => p.price_date <= filters.date_to);
    }
    if (filters.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(
        (p) =>
          p.crop_name.toLowerCase().includes(q) ||
          p.mandi_name.toLowerCase().includes(q) ||
          p.mandi_state.toLowerCase().includes(q) ||
          (p.notes && p.notes.toLowerCase().includes(q))
      );
    }

    // Default sort: price_date DESC, modal_price DESC
    list.sort((a, b) => {
      if (b.price_date !== a.price_date) {
        return b.price_date.localeCompare(a.price_date);
      }
      return b.modal_price - a.modal_price;
    });

    return list;
  }

  getPriceById(id) {
    const p = this.marketPrices.find((x) => x.id === id);
    if (!p) return null;
    const crop = this.getCropById(p.crop_id);
    const mandi = this.getMandiById(p.mandi_id);
    return {
      ...p,
      crop_name: crop ? crop.name : 'Unknown Crop',
      crop_hindi: crop ? crop.hindi_name : '',
      crop_category: crop ? crop.category : '',
      mandi_name: mandi ? mandi.name : 'Unknown Mandi',
      mandi_state: mandi ? mandi.state : '',
      mandi_district: mandi ? mandi.district : '',
      mandi_code: mandi ? mandi.code : ''
    };
  }

  createMarketPrice(data, user) {
    // Validate Crop and Mandi
    const crop = this.getCropById(data.crop_id);
    if (!crop) {
      const err = new Error('Invalid crop_id: Crop not found.');
      err.statusCode = 400;
      throw err;
    }
    const mandi = this.getMandiById(data.mandi_id);
    if (!mandi) {
      const err = new Error('Invalid mandi_id: Mandi not found.');
      err.statusCode = 400;
      throw err;
    }

    // Uniqueness constraint check
    const priceDate = data.price_date || new Date().toISOString().split('T')[0];
    const qualityGrade = data.quality_grade || 'Grade A / FAQ';
    const dataSource = data.data_source || 'manual_entry';

    const duplicate = this.marketPrices.find(
      (p) =>
        p.crop_id === data.crop_id &&
        p.mandi_id === data.mandi_id &&
        p.price_date === priceDate &&
        p.quality_grade === qualityGrade &&
        p.data_source === dataSource
    );
    if (duplicate) {
      const err = new Error(
        `Duplicate Price Entry: A quote for ${crop.name} at ${mandi.name} on ${priceDate} (${qualityGrade}, ${dataSource}) already exists.`
      );
      err.statusCode = 409;
      throw err;
    }

    const minPrice = Number(data.min_price);
    const modalPrice = Number(data.modal_price);
    const maxPrice = Number(data.max_price);

    if (minPrice <= 0 || modalPrice <= 0 || maxPrice <= 0) {
      const err = new Error('Prices must be positive numbers.');
      err.statusCode = 400;
      throw err;
    }
    if (minPrice > modalPrice || modalPrice > maxPrice) {
      const err = new Error('Price consistency check failed: Min Price <= Modal Price <= Max Price.');
      err.statusCode = 400;
      throw err;
    }

    const distanceKm = Number(data.distance_km ?? mandi.default_distance_km ?? 0);
    const transportPerUnit = Number(data.transport_estimate_per_unit ?? 0);
    const commPct = Number(data.commission_pct_applied ?? mandi.commission_agent_pct ?? 2.0);
    const laborPerUnit = Number(data.labor_fee_per_unit_applied ?? mandi.hamali_fee_per_unit ?? 12.0);
    const cessPct = Number(data.cess_pct_applied ?? mandi.standard_cess_pct ?? 1.0);

    // Business rule: Net realization calculation
    const totalPercentageDeductions = modalPrice * ((commPct + cessPct) / 100);
    const estimatedNetRealization = Math.max(
      0,
      Math.round((modalPrice - transportPerUnit - laborPerUnit - totalPercentageDeductions) * 100) / 100
    );

    const isVerified = Boolean(data.verified && (user.role === 'operator' || user.role === 'admin'));

    const newRecord = {
      id: data.id || crypto.randomUUID(),
      crop_id: data.crop_id,
      mandi_id: data.mandi_id,
      price_date: priceDate,
      quality_grade: qualityGrade,
      min_price: minPrice,
      modal_price: modalPrice,
      max_price: maxPrice,
      unit: data.unit || crop.standard_unit || 'Quintal',
      data_source: dataSource,
      verified: isVerified,
      verified_by: isVerified ? user.id : null,
      distance_km: distanceKm,
      transport_estimate_per_unit: transportPerUnit,
      commission_pct_applied: commPct,
      labor_fee_per_unit_applied: laborPerUnit,
      cess_pct_applied: cessPct,
      estimated_net_realization: estimatedNetRealization,
      notes: data.notes?.trim() || null,
      created_by: user.id || null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    this.marketPrices.push(newRecord);
    return this.getPriceById(newRecord.id);
  }

  updateMarketPrice(id, data, user) {
    const existingIndex = this.marketPrices.findIndex((p) => p.id === id);
    if (existingIndex === -1) return null;

    const existing = this.marketPrices[existingIndex];

    // Authorization check: Admin & Operator can edit any; Member can only edit their own
    if (user.role === 'member' && existing.created_by && existing.created_by !== user.id) {
      const err = new Error('Forbidden: Members can only modify price quotes they created.');
      err.statusCode = 403;
      throw err;
    }

    const minPrice = data.min_price !== undefined ? Number(data.min_price) : existing.min_price;
    const modalPrice = data.modal_price !== undefined ? Number(data.modal_price) : existing.modal_price;
    const maxPrice = data.max_price !== undefined ? Number(data.max_price) : existing.max_price;

    if (minPrice <= 0 || modalPrice <= 0 || maxPrice <= 0 || minPrice > modalPrice || modalPrice > maxPrice) {
      const err = new Error('Price consistency check failed: Min Price <= Modal Price <= Max Price.');
      err.statusCode = 400;
      throw err;
    }

    const transportPerUnit =
      data.transport_estimate_per_unit !== undefined
        ? Number(data.transport_estimate_per_unit)
        : existing.transport_estimate_per_unit;
    const commPct =
      data.commission_pct_applied !== undefined ? Number(data.commission_pct_applied) : existing.commission_pct_applied;
    const laborPerUnit =
      data.labor_fee_per_unit_applied !== undefined
        ? Number(data.labor_fee_per_unit_applied)
        : existing.labor_fee_per_unit_applied;
    const cessPct = data.cess_pct_applied !== undefined ? Number(data.cess_pct_applied) : existing.cess_pct_applied;

    const totalPercentageDeductions = modalPrice * ((commPct + cessPct) / 100);
    const estimatedNetRealization = Math.max(
      0,
      Math.round((modalPrice - transportPerUnit - laborPerUnit - totalPercentageDeductions) * 100) / 100
    );

    let isVerified = existing.verified;
    let verifiedBy = existing.verified_by;
    if (data.verified !== undefined && (user.role === 'operator' || user.role === 'admin')) {
      isVerified = Boolean(data.verified);
      verifiedBy = isVerified ? user.id : null;
    }

    const updated = {
      ...existing,
      min_price: minPrice,
      modal_price: modalPrice,
      max_price: maxPrice,
      quality_grade: data.quality_grade || existing.quality_grade,
      transport_estimate_per_unit: transportPerUnit,
      distance_km: data.distance_km !== undefined ? Number(data.distance_km) : existing.distance_km,
      commission_pct_applied: commPct,
      labor_fee_per_unit_applied: laborPerUnit,
      cess_pct_applied: cessPct,
      estimated_net_realization: estimatedNetRealization,
      verified: isVerified,
      verified_by: verifiedBy,
      notes: data.notes !== undefined ? data.notes?.trim() : existing.notes,
      updated_at: new Date().toISOString()
    };

    this.marketPrices[existingIndex] = updated;
    return this.getPriceById(id);
  }

  deleteMarketPrice(id, user) {
    const existingIndex = this.marketPrices.findIndex((p) => p.id === id);
    if (existingIndex === -1) return false;

    const existing = this.marketPrices[existingIndex];
    if (user.role === 'member' && existing.created_by && existing.created_by !== user.id) {
      const err = new Error('Forbidden: Members can only delete price records they submitted.');
      err.statusCode = 403;
      throw err;
    }

    this.marketPrices.splice(existingIndex, 1);
    return true;
  }

  // --- Selling Decisions (Journal) ---
  getAllSellingDecisions(filters = {}, user) {
    let list = this.sellingDecisions.map((d) => {
      const crop = this.getCropById(d.crop_id);
      const mandi = this.getMandiById(d.chosen_mandi_id);
      return {
        ...d,
        crop_name: crop ? crop.name : 'Unknown Crop',
        crop_hindi: crop ? crop.hindi_name : '',
        chosen_mandi_name: mandi ? mandi.name : 'Unknown Mandi',
        chosen_mandi_state: mandi ? mandi.state : ''
      };
    });

    // Role-based visibility: Members view their own or unassigned demo records; Staff view all
    if (user.role === 'member') {
      list = list.filter((d) => !d.created_by || d.created_by === user.id);
    }

    if (filters.status) {
      list = list.filter((d) => d.status === filters.status);
    }
    if (filters.crop_id) {
      list = list.filter((d) => d.crop_id === filters.crop_id);
    }
    if (filters.chosen_mandi_id) {
      list = list.filter((d) => d.chosen_mandi_id === filters.chosen_mandi_id);
    }
    if (filters.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(
        (d) =>
          d.lot_reference.toLowerCase().includes(q) ||
          d.crop_name.toLowerCase().includes(q) ||
          d.chosen_mandi_name.toLowerCase().includes(q) ||
          d.decision_rationale.toLowerCase().includes(q) ||
          (d.buyer_name && d.buyer_name.toLowerCase().includes(q))
      );
    }

    // Sort by created_at DESC
    list.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    return list;
  }

  getDecisionById(id, user) {
    const d = this.sellingDecisions.find((x) => x.id === id);
    if (!d) return null;
    if (user.role === 'member' && d.created_by && d.created_by !== user.id) {
      const err = new Error('Forbidden: Access denied to this decision record.');
      err.statusCode = 403;
      throw err;
    }
    const crop = this.getCropById(d.crop_id);
    const mandi = this.getMandiById(d.chosen_mandi_id);
    return {
      ...d,
      crop_name: crop ? crop.name : 'Unknown Crop',
      crop_hindi: crop ? crop.hindi_name : '',
      chosen_mandi_name: mandi ? mandi.name : 'Unknown Mandi',
      chosen_mandi_state: mandi ? mandi.state : ''
    };
  }

  createSellingDecision(data, user) {
    const crop = this.getCropById(data.crop_id);
    if (!crop) {
      const err = new Error('Invalid crop_id: Crop not found.');
      err.statusCode = 400;
      throw err;
    }
    const mandi = this.getMandiById(data.chosen_mandi_id);
    if (!mandi) {
      const err = new Error('Invalid chosen_mandi_id: Mandi not found.');
      err.statusCode = 400;
      throw err;
    }

    const quantity = Number(data.quantity);
    if (quantity <= 0) {
      const err = new Error('Quantity must be greater than 0.');
      err.statusCode = 400;
      throw err;
    }

    // Generate unique lot reference if not provided
    const year = new Date().getFullYear();
    const shortCrop = crop.name.substring(0, 3).toUpperCase();
    const count = this.sellingDecisions.length + 1;
    const lotReference = data.lot_reference?.trim() || `LOT-${year}-${shortCrop}-${String(count).padStart(3, '0')}`;

    if (this.sellingDecisions.some((d) => d.lot_reference.toLowerCase() === lotReference.toLowerCase())) {
      const err = new Error(`Lot reference "${lotReference}" already exists. Must be unique.`);
      err.statusCode = 409;
      throw err;
    }

    const expectedGross = Number(data.expected_gross_price);
    if (expectedGross <= 0) {
      const err = new Error('Expected gross price must be a positive number.');
      err.statusCode = 400;
      throw err;
    }

    const expectedFreight = Number(data.expected_freight_cost || 0);
    const expectedCommission = Number(data.expected_commission_fee || 0);
    const expectedHandling = Number(data.expected_handling_fee || 0);

    const expectedTotalGross = expectedGross * quantity;
    const expectedTotalDeductions = expectedFreight + expectedCommission + expectedHandling;
    const expectedTotalNet = Math.max(0, Math.round((expectedTotalGross - expectedTotalDeductions) * 100) / 100);
    const expectedNetPerUnit = Math.round((expectedTotalNet / quantity) * 100) / 100;

    const newDecision = {
      id: data.id || crypto.randomUUID(),
      lot_reference: lotReference,
      crop_id: data.crop_id,
      quantity,
      unit: data.unit || crop.standard_unit || 'Quintal',
      quality_grade: data.quality_grade || 'Grade A / FAQ',
      harvest_date: data.harvest_date || new Date().toISOString().split('T')[0],
      chosen_mandi_id: data.chosen_mandi_id,
      status: data.status || 'PLANNED',
      expected_gross_price: expectedGross,
      expected_freight_cost: expectedFreight,
      expected_commission_fee: expectedCommission,
      expected_handling_fee: expectedHandling,
      expected_net_price_per_unit: expectedNetPerUnit,
      expected_total_net_realization: expectedTotalNet,
      alternative_mandis_evaluated: data.alternative_mandis_evaluated || [],
      decision_rationale: data.decision_rationale?.trim() || 'Chosen based on net realization advantage.',
      buyer_name: data.buyer_name?.trim() || null,
      commission_agent_name: data.commission_agent_name?.trim() || null,
      actual_sale_date: data.actual_sale_date || null,
      actual_gross_price: data.actual_gross_price ? Number(data.actual_gross_price) : null,
      actual_freight_cost: data.actual_freight_cost !== undefined ? Number(data.actual_freight_cost) : null,
      actual_commission_fee: data.actual_commission_fee !== undefined ? Number(data.actual_commission_fee) : null,
      actual_handling_fee: data.actual_handling_fee !== undefined ? Number(data.actual_handling_fee) : null,
      actual_net_price_per_unit: null,
      actual_total_net_realization: null,
      variance_net_revenue: null,
      settlement_status: data.settlement_status || 'PENDING',
      payment_mode: data.payment_mode || null,
      created_by: user.id || null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    // Calculate actuals if already executed or settled
    if (['EXECUTED', 'SETTLED'].includes(newDecision.status) && newDecision.actual_gross_price) {
      const actGross = newDecision.actual_gross_price * quantity;
      const actDeductions =
        (newDecision.actual_freight_cost || 0) +
        (newDecision.actual_commission_fee || 0) +
        (newDecision.actual_handling_fee || 0);
      newDecision.actual_total_net_realization = Math.round((actGross - actDeductions) * 100) / 100;
      newDecision.actual_net_price_per_unit = Math.round((newDecision.actual_total_net_realization / quantity) * 100) / 100;
      newDecision.variance_net_revenue =
        Math.round((newDecision.actual_total_net_realization - newDecision.expected_total_net_realization) * 100) / 100;
    }

    this.sellingDecisions.push(newDecision);
    return this.getDecisionById(newDecision.id, user);
  }

  updateDecisionStatus(id, transitionData, user) {
    const existingIndex = this.sellingDecisions.findIndex((d) => d.id === id);
    if (existingIndex === -1) return null;

    const existing = this.sellingDecisions[existingIndex];
    if (user.role === 'member' && existing.created_by && existing.created_by !== user.id) {
      const err = new Error('Forbidden: You can only transition status for your own lots.');
      err.statusCode = 403;
      throw err;
    }

    const newStatus = transitionData.status;
    const allowedTransitions = {
      PLANNED: ['IN_TRANSIT', 'EXECUTED', 'CANCELLED'],
      IN_TRANSIT: ['EXECUTED', 'CANCELLED'],
      EXECUTED: ['SETTLED'],
      SETTLED: [],
      CANCELLED: ['PLANNED']
    };

    if (!allowedTransitions[existing.status]?.includes(newStatus)) {
      const err = new Error(
        `Invalid status transition: Cannot change status from "${existing.status}" to "${newStatus}". Allowed: ${
          allowedTransitions[existing.status]?.join(', ') || 'None (terminal)'
        }`
      );
      err.statusCode = 400;
      throw err;
    }

    existing.status = newStatus;
    existing.updated_at = new Date().toISOString();

    if (newStatus === 'EXECUTED' || newStatus === 'SETTLED') {
      if (transitionData.actual_gross_price) {
        existing.actual_gross_price = Number(transitionData.actual_gross_price);
      }
      if (transitionData.actual_freight_cost !== undefined) {
        existing.actual_freight_cost = Number(transitionData.actual_freight_cost);
      }
      if (transitionData.actual_commission_fee !== undefined) {
        existing.actual_commission_fee = Number(transitionData.actual_commission_fee);
      }
      if (transitionData.actual_handling_fee !== undefined) {
        existing.actual_handling_fee = Number(transitionData.actual_handling_fee);
      }
      if (transitionData.actual_sale_date) {
        existing.actual_sale_date = transitionData.actual_sale_date;
      }
      if (transitionData.buyer_name) {
        existing.buyer_name = transitionData.buyer_name.trim();
      }
      if (transitionData.commission_agent_name) {
        existing.commission_agent_name = transitionData.commission_agent_name.trim();
      }
      if (transitionData.settlement_status) {
        existing.settlement_status = transitionData.settlement_status;
      }
      if (transitionData.payment_mode) {
        existing.payment_mode = transitionData.payment_mode;
      }

      // Compute realization actuals and variance
      if (existing.actual_gross_price) {
        const actGross = existing.actual_gross_price * existing.quantity;
        const actDeduct =
          (existing.actual_freight_cost || 0) +
          (existing.actual_commission_fee || 0) +
          (existing.actual_handling_fee || 0);
        existing.actual_total_net_realization = Math.round((actGross - actDeduct) * 100) / 100;
        existing.actual_net_price_per_unit =
          Math.round((existing.actual_total_net_realization / existing.quantity) * 100) / 100;
        existing.variance_net_revenue =
          Math.round((existing.actual_total_net_realization - existing.expected_total_net_realization) * 100) / 100;
      }
    }

    if (newStatus === 'CANCELLED' && transitionData.cancellation_reason) {
      existing.decision_rationale += ` [CANCELLED: ${transitionData.cancellation_reason}]`;
    }

    this.sellingDecisions[existingIndex] = existing;
    return this.getDecisionById(id, user);
  }

  deleteSellingDecision(id, user) {
    const existingIndex = this.sellingDecisions.findIndex((d) => d.id === id);
    if (existingIndex === -1) return false;

    const existing = this.sellingDecisions[existingIndex];
    if (user.role === 'member' && existing.created_by && existing.created_by !== user.id) {
      const err = new Error('Forbidden: Members can only delete their own selling decisions.');
      err.statusCode = 403;
      throw err;
    }

    this.sellingDecisions.splice(existingIndex, 1);
    return true;
  }

  // --- Comparative Calculator ---
  compareMandis({ crop_id, quantity, unit, quality_grade, mandi_ids = [], overrides = {} }) {
    const crop = this.getCropById(crop_id);
    if (!crop) {
      const err = new Error('Crop not found for comparison.');
      err.statusCode = 400;
      throw err;
    }

    const qty = Number(quantity);
    if (qty <= 0) {
      const err = new Error('Comparison quantity must be greater than zero.');
      err.statusCode = 400;
      throw err;
    }

    const selectedMandiIds = mandi_ids.length > 0 ? mandi_ids : this.mandis.map((m) => m.id);

    const results = selectedMandiIds
      .map((mandiId) => {
        const mandi = this.getMandiById(mandiId);
        if (!mandi) return null;

        // Find latest quote for this crop and mandi
        const quotes = this.marketPrices.filter((p) => p.crop_id === crop_id && p.mandi_id === mandiId);
        quotes.sort((a, b) => b.price_date.localeCompare(a.price_date));
        const latestQuote = quotes[0];

        const override = overrides[mandiId] || {};

        const distanceKm = Number(override.distance_km ?? mandi.default_distance_km ?? 0);
        // Default freight estimation: ~Rs 0.70 per quintal per km, or custom
        const freightPerUnit = Number(override.freight_per_unit ?? Math.round(distanceKm * 0.75 * 100) / 100);
        const commissionPct = Number(override.commission_pct ?? mandi.commission_agent_pct ?? 2.0);
        const cessPct = Number(override.cess_pct ?? mandi.standard_cess_pct ?? 1.0);
        const laborFeePerUnit = Number(
          override.labor_fee_per_unit ?? override.labor_per_unit ?? mandi.hamali_fee_per_unit + mandi.weighment_fee_per_unit ?? 15.0
        );

        const modalPrice = Number(override.modal_price ?? (latestQuote ? latestQuote.modal_price : 2400.0));
        const minPrice = latestQuote ? latestQuote.min_price : modalPrice * 0.95;
        const maxPrice = latestQuote ? latestQuote.max_price : modalPrice * 1.05;

        // Math calculations
        const grossRealization = Math.round(modalPrice * qty * 100) / 100;
        const totalFreight = Math.round(freightPerUnit * qty * 100) / 100;
        const totalCommission = Math.round(grossRealization * (commissionPct / 100) * 100) / 100;
        const totalCess = Math.round(grossRealization * (cessPct / 100) * 100) / 100;
        const totalLabor = Math.round(laborFeePerUnit * qty * 100) / 100;

        const totalDeductions = Math.round((totalFreight + totalCommission + totalCess + totalLabor) * 100) / 100;
        const netRealization = Math.round((grossRealization - totalDeductions) * 100) / 100;
        const netPricePerUnit = Math.round((netRealization / qty) * 100) / 100;

        return {
          mandi_id: mandi.id,
          mandi_name: mandi.name,
          mandi_code: mandi.code,
          state: mandi.state,
          district: mandi.district,
          distance_km: distanceKm,
          has_live_quote: Boolean(latestQuote),
          quote_source: latestQuote ? latestQuote.data_source : 'default_benchmark',
          quote_date: latestQuote ? latestQuote.price_date : null,
          is_verified: latestQuote ? latestQuote.verified : false,
          nominal_prices: {
            min: minPrice,
            modal: modalPrice,
            max: maxPrice,
            unit: unit || crop.standard_unit || 'Quintal'
          },
          cost_breakdown_per_unit: {
            freight: freightPerUnit,
            commission: Math.round(modalPrice * (commissionPct / 100) * 100) / 100,
            cess: Math.round(modalPrice * (cessPct / 100) * 100) / 100,
            labor: laborFeePerUnit,
            total_deductions_per_unit: Math.round((totalDeductions / qty) * 100) / 100
          },
          total_financials: {
            quantity: qty,
            unit: unit || crop.standard_unit || 'Quintal',
            gross_revenue: grossRealization,
            total_freight: totalFreight,
            total_commission: totalCommission,
            total_cess: totalCess,
            total_labor: totalLabor,
            total_deductions: totalDeductions,
            net_realization: netRealization,
            net_price_per_unit: netPricePerUnit
          }
        };
      })
      .filter(Boolean);

    // Rank mandis by Net Realization descending
    results.sort((a, b) => b.total_financials.net_realization - a.total_financials.net_realization);

    // Compute net advantage over baseline/lowest
    const benchmark = results[results.length - 1];
    const topPick = results[0];

    results.forEach((item, index) => {
      item.rank = index + 1;
      item.is_highest_profit = index === 0;
      item.incremental_gain_vs_lowest =
        benchmark ? Math.round((item.total_financials.net_realization - benchmark.total_financials.net_realization) * 100) / 100 : 0;
      item.gain_per_unit_vs_lowest =
        benchmark ? Math.round((item.total_financials.net_price_per_unit - benchmark.total_financials.net_price_per_unit) * 100) / 100 : 0;
    });

    return {
      crop: { id: crop.id, name: crop.name, hindi_name: crop.hindi_name, standard_unit: crop.standard_unit },
      input_quantity: qty,
      unit: unit || crop.standard_unit,
      best_recommendation: {
        mandi_name: topPick ? topPick.mandi_name : null,
        net_price_per_unit: topPick ? topPick.total_financials.net_price_per_unit : 0,
        total_net_realization: topPick ? topPick.total_financials.net_realization : 0,
        net_advantage: benchmark && topPick ? Math.round((topPick.total_financials.net_realization - benchmark.total_financials.net_realization) * 100) / 100 : 0
      },
      comparisons: results
    };
  }

  // --- Dynamic Dashboard Aggregations strictly computed from persisted records ---
  getDashboardMetrics(user) {
    const totalCrops = this.crops.filter((c) => c.active).length;
    const totalMandis = this.mandis.filter((m) => m.active).length;
    const totalPrices = this.marketPrices.length;
    const verifiedPrices = this.marketPrices.filter((p) => p.verified).length;
    const manualPrices = this.marketPrices.filter((p) => p.data_source === 'manual_entry').length;
    const seededPrices = this.marketPrices.filter((p) => p.data_source === 'seeded_demo').length;
    const surveyPrices = this.marketPrices.filter((p) => p.data_source === 'market_survey').length;
    const liveApiPrices = this.marketPrices.filter((p) => p.data_source === 'verified_live_api').length;

    // Decisions summary
    const decisions = this.getAllSellingDecisions({}, user);
    const totalDecisions = decisions.length;

    const plannedCount = decisions.filter((d) => d.status === 'PLANNED').length;
    const inTransitCount = decisions.filter((d) => d.status === 'IN_TRANSIT').length;
    const executedCount = decisions.filter((d) => d.status === 'EXECUTED').length;
    const settledCount = decisions.filter((d) => d.status === 'SETTLED').length;
    const cancelledCount = decisions.filter((d) => d.status === 'CANCELLED').length;

    // Total quantity logged across decisions
    const totalVolumeQuintals = decisions.reduce((acc, d) => acc + (Number(d.quantity) || 0), 0);

    // Total Realized Revenue from Executed & Settled decisions
    const closedDecisions = decisions.filter((d) => ['EXECUTED', 'SETTLED'].includes(d.status));
    const totalRealizedRevenue = closedDecisions.reduce((acc, d) => {
      const rev = d.actual_total_net_realization ?? d.expected_total_net_realization;
      return acc + (Number(rev) || 0);
    }, 0);

    // Net optimization gain captured (difference from alternative second-best or lowest mandis)
    const netOptimizationValue = closedDecisions.reduce((acc, d) => {
      const alts = Array.isArray(d.alternative_mandis_evaluated) ? d.alternative_mandis_evaluated : [];
      if (alts.length > 1) {
        const altRevs = alts.map((a) => Number(a.net_realization || 0)).sort((a, b) => b - a);
        const chosenNet = d.actual_total_net_realization ?? d.expected_total_net_realization;
        const secondBest = altRevs[1] ?? altRevs[0];
        const gain = Math.max(0, chosenNet - secondBest);
        return acc + gain;
      }
      return acc;
    }, 0);

    // Latest price quotes feed
    const recentPrices = this.getAllMarketPrices({ limit: 5 }).slice(0, 5);

    // Crop price distribution & comparison across mandis
    const cropSummaries = this.crops.slice(0, 6).map((crop) => {
      const prices = this.marketPrices.filter((p) => p.crop_id === crop.id);
      const modals = prices.map((p) => p.modal_price);
      const min = modals.length ? Math.min(...modals) : 0;
      const max = modals.length ? Math.max(...modals) : 0;
      const avg = modals.length ? Math.round((modals.reduce((a, b) => a + b, 0) / modals.length) * 100) / 100 : 0;
      const spread = max - min;
      return {
        crop_id: crop.id,
        crop_name: crop.name,
        quote_count: prices.length,
        min_modal: min,
        avg_modal: avg,
        max_modal: max,
        spread
      };
    });

    return {
      overview: {
        active_crops: totalCrops,
        monitored_mandis: totalMandis,
        total_price_records: totalPrices,
        verified_prices_count: verifiedPrices,
        total_decisions: totalDecisions,
        total_volume_quintals: Math.round(totalVolumeQuintals * 100) / 100,
        total_realized_revenue: Math.round(totalRealizedRevenue * 100) / 100,
        net_optimization_value: Math.round(netOptimizationValue * 100) / 100
      },
      sources_breakdown: {
        manual_entry: manualPrices,
        seeded_demo: seededPrices,
        market_survey: surveyPrices,
        verified_live_api: liveApiPrices
      },
      decisions_pipeline: {
        planned: plannedCount,
        in_transit: inTransitCount,
        executed: executedCount,
        settled: settledCount,
        cancelled: cancelledCount
      },
      crop_summaries: cropSummaries,
      recent_prices: recentPrices
    };
  }

  // --- Audit Logging ---
  addAuditLog({ user_id, role, action, entity_type, entity_id, details = {}, ip_address = '127.0.0.1' }) {
    const entry = {
      id: crypto.randomUUID(),
      user_id: user_id || null,
      role: role || 'member',
      action,
      entity_type,
      entity_id: String(entity_id),
      details,
      ip_address,
      created_at: new Date().toISOString()
    };
    this.auditLogs.unshift(entry);
    if (this.auditLogs.length > 500) this.auditLogs.pop();
    if (isSupabaseConfigured && supabaseClient) {
      supabaseClient.from('audit_logs').insert([entry]).then(null, () => {});
    }
    return entry;
  }

  getAuditLogs(limit = 50) {
    return this.auditLogs.slice(0, limit);
  }
}

// Singleton repository instance
export const localStore = new LocalRepository();

// Unified Database Service Facade
export const dbService = {
  isRemote: isSupabaseConfigured,

  async getCrops() {
    if (isSupabaseConfigured && supabaseClient) {
      const { data, error } = await supabaseClient.from('crops').select('*').order('name');
      if (!error && data) return data;
    }
    return localStore.getAllCrops();
  },

  async getCropById(id) {
    if (isSupabaseConfigured && supabaseClient) {
      const { data, error } = await supabaseClient.from('crops').select('*').eq('id', id).single();
      if (!error && data) return data;
    }
    return localStore.getCropById(id);
  },

  async createCrop(data, user) {
    const crop = localStore.createCrop(data);
    localStore.addAuditLog({
      user_id: user.id,
      role: user.role,
      action: 'CREATE_CROP',
      entity_type: 'crop',
      entity_id: crop.id,
      details: { name: crop.name }
    });
    if (isSupabaseConfigured && supabaseClient) {
      try {
        await supabaseClient.from('crops').insert([crop]);
      } catch (err) {
        console.warn('[Database] Supabase createCrop remote insert warning:', err.message);
      }
    }
    return crop;
  },

  async getMandis() {
    if (isSupabaseConfigured && supabaseClient) {
      const { data, error } = await supabaseClient.from('mandis').select('*').order('name');
      if (!error && data) return data;
    }
    return localStore.getAllMandis();
  },

  async getMandiById(id) {
    if (isSupabaseConfigured && supabaseClient) {
      const { data, error } = await supabaseClient.from('mandis').select('*').eq('id', id).single();
      if (!error && data) return data;
    }
    return localStore.getMandiById(id);
  },

  async createMandi(data, user) {
    const mandi = localStore.createMandi(data);
    localStore.addAuditLog({
      user_id: user.id,
      role: user.role,
      action: 'CREATE_MANDI',
      entity_type: 'mandi',
      entity_id: mandi.id,
      details: { name: mandi.name, code: mandi.code }
    });
    if (isSupabaseConfigured && supabaseClient) {
      try {
        await supabaseClient.from('mandis').insert([mandi]);
      } catch (err) {
        console.warn('[Database] Supabase createMandi remote insert warning:', err.message);
      }
    }
    return mandi;
  },

  async updateMandi(id, data, user) {
    const mandi = localStore.updateMandi(id, data);
    if (!mandi) return null;
    localStore.addAuditLog({
      user_id: user.id,
      role: user.role,
      action: 'UPDATE_MANDI',
      entity_type: 'mandi',
      entity_id: mandi.id,
      details: { name: mandi.name, changes: Object.keys(data) }
    });
    if (isSupabaseConfigured && supabaseClient) {
      try {
        await supabaseClient.from('mandis').update(data).eq('id', id);
      } catch (err) {
        console.warn('[Database] Supabase updateMandi remote update warning:', err.message);
      }
    }
    return mandi;
  },

  async getMarketPrices(filters) {
    if (isSupabaseConfigured && supabaseClient) {
      try {
        let query = supabaseClient.from('market_prices').select('*, crops(name, hindi_name), mandis(name, state)');
        if (filters?.crop_id) query = query.eq('crop_id', filters.crop_id);
        if (filters?.mandi_id) query = query.eq('mandi_id', filters.mandi_id);
        if (filters?.data_source) query = query.eq('data_source', filters.data_source);
        if (filters?.verified !== undefined && filters?.verified !== '') {
          query = query.eq('verified', filters.verified === 'true' || filters.verified === true);
        }
        const { data, error } = await query.order('price_date', { ascending: false });
        if (!error && data && data.length > 0) {
          return data.map((p) => ({
            ...p,
            crop_name: p.crops?.name || 'Unknown Crop',
            crop_hindi: p.crops?.hindi_name || '',
            mandi_name: p.mandis?.name || 'Unknown Mandi',
            mandi_state: p.mandis?.state || ''
          }));
        }
      } catch (err) {
        console.warn('[Database] Supabase query market_prices fallback to localStore:', err.message);
      }
    }
    return localStore.getAllMarketPrices(filters);
  },

  async getMarketPriceById(id) {
    if (isSupabaseConfigured && supabaseClient) {
      try {
        const { data, error } = await supabaseClient
          .from('market_prices')
          .select('*, crops(name, hindi_name), mandis(name, state)')
          .eq('id', id)
          .single();
        if (!error && data) {
          return {
            ...data,
            crop_name: data.crops?.name || 'Unknown Crop',
            crop_hindi: data.crops?.hindi_name || '',
            mandi_name: data.mandis?.name || 'Unknown Mandi',
            mandi_state: data.mandis?.state || ''
          };
        }
      } catch (err) {
        console.warn('[Database] Supabase getMarketPriceById fallback to localStore:', err.message);
      }
    }
    return localStore.getPriceById(id);
  },

  async createMarketPrice(data, user, ip) {
    const price = localStore.createMarketPrice(data, user);
    localStore.addAuditLog({
      user_id: user.id,
      role: user.role,
      action: 'CREATE_PRICE',
      entity_type: 'market_price',
      entity_id: price.id,
      details: { crop_name: price.crop_name, mandi_name: price.mandi_name, modal_price: price.modal_price },
      ip_address: ip
    });
    if (isSupabaseConfigured && supabaseClient) {
      try {
        // Strip denormalized join fields before Supabase table insert
        const { crop_name, crop_hindi, mandi_name, mandi_state, ...supabaseRecord } = price;
        await supabaseClient.from('market_prices').insert([supabaseRecord]);
      } catch (err) {
        console.warn('[Database] Supabase createMarketPrice remote insert warning:', err.message);
      }
    }
    return price;
  },

  async updateMarketPrice(id, data, user, ip) {
    const price = localStore.updateMarketPrice(id, data, user);
    if (!price) return null;
    localStore.addAuditLog({
      user_id: user.id,
      role: user.role,
      action: 'UPDATE_PRICE',
      entity_type: 'market_price',
      entity_id: price.id,
      details: { crop_name: price.crop_name, modal_price: price.modal_price },
      ip_address: ip
    });
    if (isSupabaseConfigured && supabaseClient) {
      try {
        const { crop_name, crop_hindi, mandi_name, mandi_state, ...supabaseRecord } = price;
        await supabaseClient.from('market_prices').update(supabaseRecord).eq('id', id);
      } catch (err) {
        console.warn('[Database] Supabase updateMarketPrice remote update warning:', err.message);
      }
    }
    return price;
  },

  async deleteMarketPrice(id, user, ip) {
    const existing = localStore.getPriceById(id);
    const success = localStore.deleteMarketPrice(id, user);
    if (success && existing) {
      localStore.addAuditLog({
        user_id: user.id,
        role: user.role,
        action: 'DELETE_PRICE',
        entity_type: 'market_price',
        entity_id: id,
        details: { crop_name: existing.crop_name, mandi_name: existing.mandi_name },
        ip_address: ip
      });
      if (isSupabaseConfigured && supabaseClient) {
        try {
          await supabaseClient.from('market_prices').delete().eq('id', id);
        } catch (err) {
          console.warn('[Database] Supabase deleteMarketPrice remote delete warning:', err.message);
        }
      }
    }
    return success;
  },

  async getSellingDecisions(filters, user) {
    if (isSupabaseConfigured && supabaseClient) {
      try {
        let query = supabaseClient
          .from('selling_decisions')
          .select('*, crops(name, hindi_name), mandis(name, state)');
        if (user.role === 'member') {
          query = query.or(`created_by.eq.${user.id},created_by.is.null`);
        }
        if (filters?.status) query = query.eq('status', filters.status);
        if (filters?.crop_id) query = query.eq('crop_id', filters.crop_id);
        if (filters?.chosen_mandi_id) query = query.eq('chosen_mandi_id', filters.chosen_mandi_id);
        const { data, error } = await query.order('created_at', { ascending: false });
        if (!error && data && data.length > 0) {
          return data.map((d) => ({
            ...d,
            crop_name: d.crops?.name || 'Unknown Crop',
            crop_hindi: d.crops?.hindi_name || '',
            chosen_mandi_name: d.mandis?.name || 'Unknown Mandi',
            chosen_mandi_state: d.mandis?.state || ''
          }));
        }
      } catch (err) {
        console.warn('[Database] Supabase getSellingDecisions fallback to localStore:', err.message);
      }
    }
    return localStore.getAllSellingDecisions(filters, user);
  },

  async getSellingDecisionById(id, user) {
    if (isSupabaseConfigured && supabaseClient) {
      try {
        const { data, error } = await supabaseClient
          .from('selling_decisions')
          .select('*, crops(name, hindi_name), mandis(name, state)')
          .eq('id', id)
          .single();
        if (!error && data) {
          return {
            ...data,
            crop_name: data.crops?.name || 'Unknown Crop',
            crop_hindi: data.crops?.hindi_name || '',
            chosen_mandi_name: data.mandis?.name || 'Unknown Mandi',
            chosen_mandi_state: data.mandis?.state || ''
          };
        }
      } catch (err) {
        console.warn('[Database] Supabase getSellingDecisionById fallback to localStore:', err.message);
      }
    }
    return localStore.getDecisionById(id, user);
  },

  async createSellingDecision(data, user, ip) {
    const decision = localStore.createSellingDecision(data, user);
    localStore.addAuditLog({
      user_id: user.id,
      role: user.role,
      action: 'CREATE_DECISION',
      entity_type: 'selling_decision',
      entity_id: decision.id,
      details: { lot_reference: decision.lot_reference, crop_name: decision.crop_name, status: decision.status },
      ip_address: ip
    });
    if (isSupabaseConfigured && supabaseClient) {
      try {
        const { crop_name, crop_hindi, chosen_mandi_name, chosen_mandi_state, ...supabaseRecord } = decision;
        await supabaseClient.from('selling_decisions').insert([supabaseRecord]);
      } catch (err) {
        console.warn('[Database] Supabase createSellingDecision remote insert warning:', err.message);
      }
    }
    return decision;
  },

  async updateDecisionStatus(id, transitionData, user, ip) {
    const decision = localStore.updateDecisionStatus(id, transitionData, user);
    if (!decision) return null;
    localStore.addAuditLog({
      user_id: user.id,
      role: user.role,
      action: 'STATUS_TRANSITION',
      entity_type: 'selling_decision',
      entity_id: decision.id,
      details: {
        lot_reference: decision.lot_reference,
        new_status: decision.status,
        variance: decision.variance_net_revenue
      },
      ip_address: ip
    });
    if (isSupabaseConfigured && supabaseClient) {
      try {
        const { crop_name, crop_hindi, chosen_mandi_name, chosen_mandi_state, ...supabaseRecord } = decision;
        await supabaseClient.from('selling_decisions').update(supabaseRecord).eq('id', id);
      } catch (err) {
        console.warn('[Database] Supabase updateDecisionStatus remote update warning:', err.message);
      }
    }
    return decision;
  },

  async deleteSellingDecision(id, user, ip) {
    const existing = localStore.getDecisionById(id, user);
    const success = localStore.deleteSellingDecision(id, user);
    if (success && existing) {
      localStore.addAuditLog({
        user_id: user.id,
        role: user.role,
        action: 'DELETE_DECISION',
        entity_type: 'selling_decision',
        entity_id: id,
        details: { lot_reference: existing.lot_reference },
        ip_address: ip
      });
      if (isSupabaseConfigured && supabaseClient) {
        try {
          await supabaseClient.from('selling_decisions').delete().eq('id', id);
        } catch (err) {
          console.warn('[Database] Supabase deleteSellingDecision remote delete warning:', err.message);
        }
      }
    }
    return success;
  },

  compareMandis(params) {
    return localStore.compareMandis(params);
  },

  getDashboardMetrics(user) {
    return localStore.getDashboardMetrics(user);
  },

  async getAuditLogs(limit) {
    if (isSupabaseConfigured && supabaseClient) {
      try {
        const { data, error } = await supabaseClient
          .from('audit_logs')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(limit || 50);
        if (!error && data && data.length > 0) {
          return data;
        }
      } catch (err) {
        console.warn('[Database] Supabase getAuditLogs fallback to localStore:', err.message);
      }
    }
    return localStore.getAuditLogs(limit);
  },

  resetDemoData(user) {
    localStore.reset();
    localStore.addAuditLog({
      user_id: user?.id,
      role: user?.role || 'admin',
      action: 'SYSTEM_RESET_DEMO',
      entity_type: 'system',
      entity_id: 'sys',
      details: { note: 'Database reset to initial deterministic seed state' }
    });
    return true;
  }
};
