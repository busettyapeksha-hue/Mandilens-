/**
 * Schema Validation Middleware and Validation Utilities
 */

export function validatePriceInput(req, res, next) {
  const { crop_id, mandi_id, min_price, modal_price, max_price, unit, quality_grade, data_source } = req.body;

  const errors = [];

  if (!crop_id || typeof crop_id !== 'string') {
    errors.push('crop_id is required and must be a valid ID string.');
  }
  if (!mandi_id || typeof mandi_id !== 'string') {
    errors.push('mandi_id is required and must be a valid ID string.');
  }

  const minP = Number(min_price);
  const modP = Number(modal_price);
  const maxP = Number(max_price);

  if (isNaN(minP) || minP <= 0) {
    errors.push('min_price must be a positive number greater than 0.');
  }
  if (isNaN(modP) || modP <= 0) {
    errors.push('modal_price must be a positive number greater than 0.');
  }
  if (isNaN(maxP) || maxP <= 0) {
    errors.push('max_price must be a positive number greater than 0.');
  }

  if (!isNaN(minP) && !isNaN(modP) && !isNaN(maxP)) {
    if (minP > modP) {
      errors.push('min_price cannot exceed modal_price.');
    }
    if (modP > maxP) {
      errors.push('modal_price cannot exceed max_price.');
    }
  }

  const validGrades = ['Grade A / FAQ', 'Grade B', 'Grade C', 'Export Quality', 'Organic Certified'];
  if (quality_grade && !validGrades.includes(quality_grade)) {
    errors.push(`quality_grade must be one of: ${validGrades.join(', ')}`);
  }

  const validSources = ['manual_entry', 'market_survey', 'seeded_demo', 'verified_live_api'];
  if (data_source && !validSources.includes(data_source)) {
    errors.push(`data_source must be one of: ${validSources.join(', ')}`);
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      error: 'Validation Failed',
      details: errors
    });
  }

  next();
}

export function validateDecisionInput(req, res, next) {
  const { crop_id, chosen_mandi_id, quantity, expected_gross_price } = req.body;
  const errors = [];

  if (!crop_id || typeof crop_id !== 'string') {
    errors.push('crop_id is required.');
  }
  if (!chosen_mandi_id || typeof chosen_mandi_id !== 'string') {
    errors.push('chosen_mandi_id is required.');
  }

  const qty = Number(quantity);
  if (isNaN(qty) || qty <= 0) {
    errors.push('quantity must be a number greater than 0.');
  }

  const grossP = Number(expected_gross_price);
  if (isNaN(grossP) || grossP <= 0) {
    errors.push('expected_gross_price must be a positive number.');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      error: 'Validation Failed',
      details: errors
    });
  }

  next();
}

export function validateStatusTransition(req, res, next) {
  const { status } = req.body;
  const validStatuses = ['PLANNED', 'IN_TRANSIT', 'EXECUTED', 'SETTLED', 'CANCELLED'];

  if (!status || !validStatuses.includes(status)) {
    return res.status(400).json({
      success: false,
      error: `Invalid status. Must be one of: ${validStatuses.join(', ')}`
    });
  }

  if (status === 'EXECUTED' || status === 'SETTLED') {
    if (req.body.actual_gross_price !== undefined) {
      const actualGross = Number(req.body.actual_gross_price);
      if (isNaN(actualGross) || actualGross <= 0) {
        return res.status(400).json({
          success: false,
          error: 'actual_gross_price must be a positive number when recording execution/settlement.'
        });
      }
    }
  }

  next();
}

export function validateCalculatorInput(req, res, next) {
  const { crop_id, quantity } = req.body;
  const errors = [];

  if (!crop_id || typeof crop_id !== 'string') {
    errors.push('crop_id is required.');
  }

  const qty = Number(quantity);
  if (isNaN(qty) || qty <= 0) {
    errors.push('quantity must be a number greater than 0.');
  }

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      error: 'Validation Failed',
      details: errors
    });
  }

  next();
}
