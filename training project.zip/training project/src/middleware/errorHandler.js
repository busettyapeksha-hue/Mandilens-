/**
 * Standardized API Error Handling Middleware
 * Sanitizes errors, suppresses stack traces in production, and redacts sensitive data.
 */
export function errorHandler(err, req, res, next) {
  const statusCode = err.statusCode || (err.status ? Number(err.status) : 500);

  // Redacted log message without sensitive data
  const logMessage = `[API Error] ${req.method} ${req.originalUrl} - Status: ${statusCode} - ${err.message}`;
  if (statusCode >= 500) {
    console.error(logMessage, err.stack);
  } else {
    console.warn(logMessage);
  }

  res.status(statusCode).json({
    success: false,
    error: err.message || 'An unexpected internal server error occurred.',
    details: err.details || null,
    statusCode
  });
}

/**
 * 404 Route Not Found handler
 */
export function notFoundHandler(req, res) {
  res.status(404).json({
    success: false,
    error: `Endpoint not found: ${req.method} ${req.originalUrl}`,
    statusCode: 404
  });
}
