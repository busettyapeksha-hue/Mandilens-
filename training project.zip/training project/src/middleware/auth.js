import { localStore } from '../services/db.js';

/**
 * Role-aware authentication middleware.
 * Supports:
 * 1. Bearer Token for Supabase / JWT sessions
 * 2. Explicit 'x-demo-role' (or 'x-user-id') for seamless role testing in local demo mode
 * 3. Default fallback to standard 'member' role (Ramesh Kumar)
 */
export function authMiddleware(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    const demoRoleHeader = req.headers['x-demo-role'];
    const demoUserIdHeader = req.headers['x-user-id'];

    let matchedUser = null;

    if (demoUserIdHeader) {
      matchedUser = localStore.getUserById(demoUserIdHeader);
    }

    if (!matchedUser && demoRoleHeader) {
      const normalizedRole = demoRoleHeader.toLowerCase().trim();
      if (['member', 'operator', 'admin'].includes(normalizedRole)) {
        matchedUser = localStore.getUserByRole(normalizedRole);
      }
    }

    if (!matchedUser && authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7).trim();
      // Safe token parsing or role extraction
      if (token === 'admin-demo-token') {
        matchedUser = localStore.getUserByRole('admin');
      } else if (token === 'operator-demo-token') {
        matchedUser = localStore.getUserByRole('operator');
      } else if (token === 'member-demo-token') {
        matchedUser = localStore.getUserByRole('member');
      }
    }

    // Default fallback to Member for frictionless interactive exploration
    if (!matchedUser) {
      matchedUser = localStore.getUserByRole('member');
    }

    req.user = matchedUser;
    next();
  } catch (err) {
    next(err);
  }
}

/**
 * Middleware to require authenticated user
 */
export function requireAuth(req, res, next) {
  if (!req.user) {
    return res.status(401).json({
      success: false,
      error: 'Authentication Required: Please provide valid credentials.'
    });
  }
  next();
}

/**
 * Middleware to enforce specific roles
 * @param {string[]} allowedRoles
 */
export function requireRole(allowedRoles = []) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        error: 'Authentication Required'
      });
    }

    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        success: false,
        error: `Forbidden: This action requires one of the following roles: [${allowedRoles.join(
          ', '
        )}]. Your current role is "${req.user.role}".`
      });
    }

    next();
  };
}
