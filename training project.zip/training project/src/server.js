import dotenv from 'dotenv';
import app from './app.js';
import { isSupabaseConfigured } from './config/database.js';

dotenv.config();

const PORT = process.env.PORT || 3000;

const server = app.listen(PORT, () => {
  console.log(`=======================================================`);
  console.log(` MandiLens Agricultural Market Intelligence & Decision Log `);
  console.log(` Server running on http://localhost:${PORT}`);
  console.log(` Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(` Supabase PostgreSQL Connected: ${isSupabaseConfigured}`);
  console.log(`=======================================================`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[Server] SIGTERM signal received: closing HTTP server.');
  server.close(() => {
    console.log('[Server] HTTP server closed gracefully.');
  });
});

process.on('SIGINT', () => {
  console.log('[Server] SIGINT received: closing HTTP server.');
  server.close(() => {
    console.log('[Server] HTTP server closed gracefully.');
    process.exit(0);
  });
});
