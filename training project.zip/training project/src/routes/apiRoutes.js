import express from 'express';
import rateLimit from 'express-rate-limit';

import { authMiddleware, requireRole } from '../middleware/auth.js';
import {
  validatePriceInput,
  validateDecisionInput,
  validateStatusTransition,
  validateCalculatorInput
} from '../validators/schemaValidators.js';

import { pricesController } from '../controllers/pricesController.js';
import { decisionsController } from '../controllers/decisionsController.js';
import { calculatorController } from '../controllers/calculatorController.js';
import { masterDataController } from '../controllers/masterDataController.js';
import { analyticsController } from '../controllers/analyticsController.js';
import { systemController } from '../controllers/systemController.js';

const router = express.Router();

// General API Rate Limiter
const standardLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 300,
  message: { success: false, error: 'Too many requests from this IP, please try again later.' }
});

// Stricter limiter for sensitive creation routes
const writeLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 120,
  message: { success: false, error: 'Rate limit exceeded for write operations. Please wait a moment.' }
});

router.use(standardLimiter);
router.use(authMiddleware);

// --- System & Health ---
router.get('/health', systemController.getHealth);
router.get('/users', systemController.getAvailableUsers);
router.get('/audit-logs', requireRole(['operator', 'admin']), systemController.getAuditLogs);
router.post('/system/reset-demo', requireRole(['operator', 'admin']), systemController.resetDemo);

// --- Analytics ---
router.get('/analytics/dashboard', analyticsController.getDashboard);

// --- Master Data (Crops & Mandis) ---
router.get('/crops', masterDataController.listCrops);
router.post('/crops', requireRole(['admin']), writeLimiter, masterDataController.createCrop);

router.get('/mandis', masterDataController.listMandis);
router.post('/mandis', requireRole(['operator', 'admin']), writeLimiter, masterDataController.createMandi);
router.patch('/mandis/:id', requireRole(['operator', 'admin']), masterDataController.updateMandi);

// --- Market Prices ---
router.get('/prices', pricesController.listPrices);
router.get('/prices/:id', pricesController.getPrice);
router.post('/prices', writeLimiter, validatePriceInput, pricesController.createPrice);
router.put('/prices/:id', writeLimiter, pricesController.updatePrice);
router.delete('/prices/:id', pricesController.deletePrice);

// --- Comparative Calculator ---
router.post('/calculator/compare', validateCalculatorInput, calculatorController.compareMandis);

// --- Selling Decisions (Journal) ---
router.get('/decisions', decisionsController.listDecisions);
router.get('/decisions/:id', decisionsController.getDecision);
router.post('/decisions', writeLimiter, validateDecisionInput, decisionsController.createDecision);
router.patch('/decisions/:id/status', validateStatusTransition, decisionsController.transitionStatus);
router.delete('/decisions/:id', decisionsController.deleteDecision);

export default router;
