-- ====================================================================
-- MandiLens Deterministic Seed Data (supabase/seed.sql)
-- Realistic Indian Agricultural Market Data with Authentic Fee Structures
-- ====================================================================

-- 1. Insert Initial User Profiles
INSERT INTO user_profiles (id, email, full_name, role, phone, hub_location) VALUES
('11111111-1111-4111-8111-111111111111', 'farmer.ramesh@mandilens.in', 'Ramesh Kumar (Kisan)', 'member', '+91 98120 44211', 'Karnal, Haryana'),
('22222222-2222-4222-8222-222222222222', 'farmer.sunita@mandilens.in', 'Sunita Patil (FPO Lead)', 'member', '+91 94220 88319', 'Nashik, Maharashtra'),
('33333333-3333-4333-8333-333333333333', 'operator.rajesh@mandilens.in', 'Rajesh Sharma (Mandi Surveyor)', 'operator', '+91 97110 55321', 'Azadpur Yard 4'),
('44444444-4444-4444-8444-444444444444', 'admin.director@mandilens.in', 'Devendra Singh (APMC Admin)', 'admin', '+91 99990 00100', 'New Delhi APMC Board')
ON CONFLICT (id) DO NOTHING;

-- 2. Insert Core Agricultural Crops
INSERT INTO crops (id, name, hindi_name, category, standard_unit, standard_moisture_pct, active) VALUES
('c1010101-0000-0000-0000-000000000001', 'Wheat (Sharbati/HD-2967)', 'गेहूं (शरबती / HD-2967)', 'Cereals', 'Quintal', 12.00, true),
('c1010101-0000-0000-0000-000000000002', 'Basmati Rice (1121 Paddy)', 'बासमती धान (1121 पैडी)', 'Cereals', 'Quintal', 13.50, true),
('c1010101-0000-0000-0000-000000000003', 'Chana (Desi Bengal Gram)', 'चना (देसी चना)', 'Pulses', 'Quintal', 11.00, true),
('c1010101-0000-0000-0000-000000000004', 'Mustard (Sarson / Black)', 'सरसों (काली सरसों)', 'Oilseeds', 'Quintal', 8.00, true),
('c1010101-0000-0000-0000-000000000005', 'Soybean (Yellow Seed)', 'सोयाबीन (पीला दाना)', 'Oilseeds', 'Quintal', 10.00, true),
('c1010101-0000-0000-0000-000000000006', 'Onion (Nashik Red)', 'प्याज (नासिक लाल)', 'Vegetables', 'Quintal', 14.00, true),
('c1010101-0000-0000-0000-000000000007', 'Tomato (Hybrid Desi)', 'टमाटर (हाइब्रिड)', 'Vegetables', 'Crate', 15.00, true),
('c1010101-0000-0000-0000-000000000008', 'Potato (Kufri Jyoti)', 'आलू (कुफरी ज्योति)', 'Vegetables', '50kg Bag', 13.00, true),
('c1010101-0000-0000-0000-000000000009', 'Cotton (Medium Staple)', 'कपास (मध्यम रेशा)', 'Fiber/Cash', 'Quintal', 9.00, true),
('c1010101-0000-0000-0000-000000000010', 'Turmeric (Salem/Nizamabad)', 'हल्दी (निजामाबाद फिंगर)', 'Spices', 'Quintal', 9.50, true)
ON CONFLICT (name) DO NOTHING;

-- 3. Insert Major Mandis (APMCs)
INSERT INTO mandis (id, name, code, state, district, standard_cess_pct, commission_agent_pct, hamali_fee_per_unit, weighment_fee_per_unit, default_distance_km, active) VALUES
('b2020202-0000-0000-0000-000000000001', 'Azadpur APMC', 'DL-AZD', 'Delhi', 'North Delhi', 1.00, 2.00, 14.00, 4.00, 125.00, true),
('b2020202-0000-0000-0000-000000000002', 'Karnal Grain Market', 'HR-KNL', 'Haryana', 'Karnal', 1.50, 1.50, 10.00, 2.50, 18.00, true),
('b2020202-0000-0000-0000-000000000003', 'Khanna Grain Market', 'PB-KHN', 'Punjab', 'Ludhiana', 2.00, 2.50, 12.00, 3.00, 140.00, true),
('b2020202-0000-0000-0000-000000000004', 'Lasalgaon APMC', 'MH-LSG', 'Maharashtra', 'Nashik', 1.05, 2.00, 15.00, 3.50, 35.00, true),
('b2020202-0000-0000-0000-000000000005', 'Vashi APMC', 'MH-VSH', 'Maharashtra', 'Navi Mumbai', 1.00, 2.00, 18.00, 5.00, 195.00, true),
('b2020202-0000-0000-0000-000000000006', 'Neemuch Mandi', 'MP-NMC', 'Madhya Pradesh', 'Neemuch', 1.20, 1.75, 11.00, 2.50, 85.00, true),
('b2020202-0000-0000-0000-000000000007', 'Gondal APMC', 'GJ-GND', 'Gujarat', 'Rajkot', 0.80, 1.50, 12.00, 3.00, 95.00, true),
('b2020202-0000-0000-0000-000000000008', 'Nizamabad APMC', 'TS-NZB', 'Telangana', 'Nizamabad', 1.00, 2.00, 13.00, 3.00, 60.00, true)
ON CONFLICT (code) DO NOTHING;

-- 4. Insert Market Prices (Sample Quotes Across Mandis)
INSERT INTO market_prices (
    id, crop_id, mandi_id, price_date, quality_grade, 
    min_price, modal_price, max_price, unit, data_source, 
    verified, verified_by, distance_km, transport_estimate_per_unit, 
    commission_pct_applied, labor_fee_per_unit_applied, cess_pct_applied, 
    estimated_net_realization, notes, created_by
) VALUES
-- Wheat quotes
('a3030303-0000-0000-0000-000000000001', 'c1010101-0000-0000-0000-000000000001', 'b2020202-0000-0000-0000-000000000001', '2026-10-26', 'Grade A / FAQ', 2420.00, 2520.00, 2600.00, 'Quintal', 'seeded_demo', true, '33333333-3333-4333-8333-333333333333', 125.00, 85.00, 2.00, 18.00, 1.00, 2341.40, 'High mill buying interest from flour mills in Delhi NCR.', '33333333-3333-4333-8333-333333333333'),
('a3030303-0000-0000-0000-000000000002', 'c1010101-0000-0000-0000-000000000002', 'b2020202-0000-0000-0000-000000000002', '2026-10-26', 'Grade A / FAQ', 2350.00, 2410.00, 2450.00, 'Quintal', 'seeded_demo', true, '33333333-3333-4333-8333-333333333333', 18.00, 25.00, 1.50, 12.50, 1.50, 2300.20, 'Local Karnal grain arrivals steady, low transit friction.', '11111111-1111-4111-8111-111111111111'),
('a3030303-0000-0000-0000-000000000003', 'c1010101-0000-0000-0000-000000000003', 'b2020202-0000-0000-0000-000000000003', '2026-10-26', 'Grade A / FAQ', 2380.00, 2460.00, 2510.00, 'Quintal', 'market_survey', false, NULL, 140.00, 95.00, 2.50, 15.00, 2.00, 2239.30, 'Khanna spot survey shows moderate procurement rates.', '33333333-3333-4333-8333-333333333333'),

-- Basmati Rice 1121 quotes
('a3030303-0000-0000-0000-000000000004', 'c1010101-0000-0000-0000-000000000002', 'b2020202-0000-0000-0000-000000000002', '2026-10-26', 'Grade A / FAQ', 3800.00, 3950.00, 4120.00, 'Quintal', 'manual_entry', true, '33333333-3333-4333-8333-333333333333', 18.00, 30.00, 1.50, 12.50, 1.50, 3789.00, 'Karnal yard exporters active for premium 1121 lots.', '11111111-1111-4111-8111-111111111111'),
('a3030303-0000-0000-0000-000000000005', 'c1010101-0000-0000-0000-000000000001', 'b2020202-0000-0000-0000-000000000001', '2026-10-26', 'Grade A / FAQ', 4050.00, 4200.00, 4350.00, 'Quintal', 'seeded_demo', true, '33333333-3333-4333-8333-333333333333', 125.00, 95.00, 2.00, 18.00, 1.00, 3961.00, 'Premium quote in Delhi, covers transport cost with surplus.', '33333333-3333-4333-8333-333333333333'),

-- Onion (Nashik Red) quotes
('a3030303-0000-0000-0000-000000000006', 'c1010101-0000-0000-0000-000000000006', 'b2020202-0000-0000-0000-000000000004', '2026-10-26', 'Grade A / FAQ', 1900.00, 2050.00, 2200.00, 'Quintal', 'seeded_demo', true, '33333333-3333-4333-8333-333333333333', 35.00, 40.00, 2.00, 18.50, 1.05, 1928.98, 'Heavy daily auction volume at Asia largest onion yard.', '22222222-2222-4222-8222-222222222222'),
('a3030303-0000-0000-0000-000000000007', 'c1010101-0000-0000-0000-000000000005', 'b2020202-0000-0000-0000-000000000005', '2026-10-26', 'Grade A / FAQ', 2450.00, 2600.00, 2750.00, 'market_survey', false, NULL, 195.00, 140.00, 2.00, 23.00, 1.00, 2359.00, 'Mumbai terminal market trades at significant premium.', '33333333-3333-4333-8333-333333333333'),

-- Mustard Quotes
('a3030303-0000-0000-0000-000000000008', 'c1010101-0000-0000-0000-000000000004', 'b2020202-0000-0000-0000-000000000006', '2026-10-26', 'Grade A / FAQ', 5300.00, 5450.00, 5600.00, 'Quintal', 'seeded_demo', true, '33333333-3333-4333-8333-333333333333', 85.00, 75.00, 1.75, 13.50, 1.20, 5200.73, 'Neemuch oil mill crushing demand strong.', '33333333-3333-4333-8333-333333333333')
ON CONFLICT (crop_id, mandi_id, price_date, quality_grade, data_source) DO NOTHING;

-- 5. Insert Selling Decisions
INSERT INTO selling_decisions (
    id, lot_reference, crop_id, quantity, unit, quality_grade, harvest_date,
    chosen_mandi_id, status, expected_gross_price, expected_freight_cost,
    expected_commission_fee, expected_handling_fee, expected_net_price_per_unit,
    expected_total_net_realization, alternative_mandis_evaluated, decision_rationale,
    buyer_name, commission_agent_name, actual_sale_date,
    actual_gross_price, actual_freight_cost, actual_commission_fee, actual_handling_fee,
    actual_net_price_per_unit, actual_total_net_realization, variance_net_revenue,
    settlement_status, payment_mode, created_by
) VALUES
-- Settled lot: Wheat sold at Azadpur
(
    'd4040404-0000-0000-0000-000000000001', 'LOT-2026-WHT-01', 'c1010101-0000-0000-0000-000000000001',
    85.00, 'Quintal', 'Grade A / FAQ', '2026-10-20', 'b2020202-0000-0000-0000-000000000001',
    'SETTLED', 2520.00, 7225.00, 4284.00, 1530.00, 2366.60, 201161.00,
    '[{"mandi_name": "Karnal Grain Market", "modal_price": 2410, "net_realization": 195517}, {"mandi_name": "Azadpur APMC", "modal_price": 2520, "net_realization": 201161}]'::jsonb,
    'Azadpur buyer agreed to pay Rs 2520/qtl which gave Rs 5,644 extra net realization over Karnal after deducting 125km freight and agent commission.',
    'Rajdhani Agro Foods Pvt Ltd', 'M/s Aggarwal & Sons (Aadathiya)', '2026-10-22',
    2530.00, 7200.00, 4301.00, 1530.00, 2376.69, 202019.00, 858.00,
    'RECEIVED', 'NEFT_RTGS', '11111111-1111-4111-8111-111111111111'
),
-- Executed lot: Basmati Dhan sold at Karnal
(
    'd4040404-0000-0000-0000-000000000002', 'LOT-2026-BAS-02', 'c1010101-0000-0000-0000-000000000002',
    120.00, 'Quintal', 'Grade A / FAQ', '2026-10-22', 'b2020202-0000-0000-0000-000000000002',
    'EXECUTED', 3950.00, 3600.00, 7110.00, 1500.00, 3848.25, 461790.00,
    '[{"mandi_name": "Karnal Grain Market", "modal_price": 3950, "net_realization": 461790}, {"mandi_name": "Khanna Grain Market", "modal_price": 4010, "net_realization": 458200}]'::jsonb,
    'Sold locally at Karnal because prompt cash payment and zero inter-state road checkpost delays made local realization faster and risk-free.',
    'Karnal Rice Mills Ltd', 'Chaudhary Dataram & Co.', '2026-10-25',
    3940.00, 3600.00, 7092.00, 1500.00, 3838.40, 460608.00, -1182.00,
    'PARTIAL', 'NEFT_RTGS', '11111111-1111-4111-8111-111111111111'
),
-- In Transit lot: Mustard to Neemuch
(
    'd4040404-0000-0000-0000-000000000003', 'LOT-2026-MST-03', 'c1010101-0000-0000-0000-000000000004',
    60.00, 'Quintal', 'Grade A / FAQ', '2026-10-24', 'b2020202-0000-0000-0000-000000000006',
    'IN_TRANSIT', 5450.00, 4500.00, 5722.50, 810.00, 5266.12, 315967.50,
    '[{"mandi_name": "Neemuch Mandi", "modal_price": 5450, "net_realization": 315967}]'::jsonb,
    'High oil percentage (41.5%) certified in sample test. Neemuch oil crushers paying Rs 150 premium over local Kota rate.',
    'Neemuch Oil & Solvents', 'M/s Porwal Brothers', NULL,
    NULL, NULL, NULL, NULL,
    NULL, NULL, NULL,
    'PENDING', NULL, '11111111-1111-4111-8111-111111111111'
),
-- Planned lot: Onion batch from Nashik
(
    'd4040404-0000-0000-0000-000000000004', 'LOT-2026-ONN-04', 'c1010101-0000-0000-0000-000000000006',
    150.00, 'Quintal', 'Grade A / FAQ', '2026-10-25', 'b2020202-0000-0000-0000-000000000005',
    'PLANNED', 2600.00, 21000.00, 7800.00, 3450.00, 2385.00, 357750.00,
    '[{"mandi_name": "Lasalgaon APMC", "modal_price": 2050, "net_realization": 289350}, {"mandi_name": "Vashi APMC", "modal_price": 2600, "net_realization": 357750}]'::jsonb,
    'Comparative realization analysis confirms Vashi yields +Rs 68,400 higher total profit even after paying Rs 21,000 in truck transport from Nashik to Navi Mumbai.',
    'Direct Wholesaler Syndicate', 'Patil Traders Vashi', NULL,
    NULL, NULL, NULL, NULL,
    NULL, NULL, NULL,
    'PENDING', NULL, '22222222-2222-4222-8222-222222222222'
)
ON CONFLICT (lot_reference) DO NOTHING;

-- 6. Insert Initial Audit Logs
INSERT INTO audit_logs (id, user_id, role, action, entity_type, entity_id, details, ip_address) VALUES
('a5050505-0000-0000-0000-000000000001', '44444444-4444-4444-8444-444444444444', 'admin', 'SYSTEM_INIT', 'system', 'sys-01', '{"event": "MandiLens system seeded with standard crops and APMC mandis"}'::jsonb, '127.0.0.1'),
('a5050505-0000-0000-0000-000000000002', '11111111-1111-4111-8111-111111111111', 'member', 'CREATE_DECISION', 'decision', 'd4040404-0000-0000-0000-000000000001', '{"lot": "LOT-2026-WHT-01", "mandi": "Azadpur APMC", "status": "SETTLED"}'::jsonb, '127.0.0.1'),
('a5050505-0000-0000-0000-000000000003', '22222222-2222-4222-8222-222222222222', 'member', 'CREATE_DECISION', 'decision', 'd4040404-0000-0000-0000-000000000004', '{"lot": "LOT-2026-ONN-04", "mandi": "Vashi APMC", "status": "PLANNED"}'::jsonb, '127.0.0.1')
ON CONFLICT (id) DO NOTHING;
