-- ====================================================================
-- MandiLens PostgreSQL Migration: 20261027000002_rls_and_security.sql
-- Description: Row Level Security (RLS) policies and role-based permissions
-- ====================================================================

-- 1. Enable RLS on core tables
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE crops ENABLE ROW LEVEL SECURITY;
ALTER TABLE mandis ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_prices ENABLE ROW LEVEL SECURITY;
ALTER TABLE selling_decisions ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- 2. Crops Policies (Public read; Operator/Admin manage)
CREATE POLICY "Public crops viewable by everyone" 
    ON crops FOR SELECT USING (true);

CREATE POLICY "Operators and Admins can insert crops" 
    ON crops FOR INSERT WITH CHECK (
        auth.role() = 'service_role' OR 
        EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role IN ('operator', 'admin'))
    );

CREATE POLICY "Operators and Admins can update crops" 
    ON crops FOR UPDATE USING (
        auth.role() = 'service_role' OR 
        EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role IN ('operator', 'admin'))
    );

-- 3. Mandis Policies (Public read; Operator/Admin manage)
CREATE POLICY "Public mandis viewable by everyone" 
    ON mandis FOR SELECT USING (true);

CREATE POLICY "Operators and Admins can insert mandis" 
    ON mandis FOR INSERT WITH CHECK (
        auth.role() = 'service_role' OR 
        EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role IN ('operator', 'admin'))
    );

CREATE POLICY "Operators and Admins can update mandis" 
    ON mandis FOR UPDATE USING (
        auth.role() = 'service_role' OR 
        EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role IN ('operator', 'admin'))
    );

-- 4. Market Prices Policies
-- Anyone can view market prices
CREATE POLICY "Market prices readable by all" 
    ON market_prices FOR SELECT USING (true);

-- Authenticated users (members, operators, admins) can submit market prices
CREATE POLICY "Authenticated users can submit market prices" 
    ON market_prices FOR INSERT WITH CHECK (
        auth.role() = 'service_role' OR 
        auth.uid() IS NOT NULL
    );

-- Operators and Admins can update or verify any price; Members can update their own
CREATE POLICY "Price updates controlled by ownership and role" 
    ON market_prices FOR UPDATE USING (
        auth.role() = 'service_role' OR 
        created_by = auth.uid() OR
        EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role IN ('operator', 'admin'))
    );

CREATE POLICY "Price deletion controlled by admin or owner" 
    ON market_prices FOR DELETE USING (
        auth.role() = 'service_role' OR 
        created_by = auth.uid() OR
        EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role = 'admin')
    );

-- 5. Selling Decisions Policies
-- Members can only view their own decisions; Operators and Admins can view all
CREATE POLICY "Decisions viewable by owner or staff" 
    ON selling_decisions FOR SELECT USING (
        auth.role() = 'service_role' OR 
        created_by = auth.uid() OR
        EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role IN ('operator', 'admin'))
    );

CREATE POLICY "Members and staff can create selling decisions" 
    ON selling_decisions FOR INSERT WITH CHECK (
        auth.role() = 'service_role' OR 
        auth.uid() IS NOT NULL
    );

CREATE POLICY "Decisions updatable by owner or staff" 
    ON selling_decisions FOR UPDATE USING (
        auth.role() = 'service_role' OR 
        created_by = auth.uid() OR
        EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role IN ('operator', 'admin'))
    );

CREATE POLICY "Decisions deletable by owner or admin" 
    ON selling_decisions FOR DELETE USING (
        auth.role() = 'service_role' OR 
        created_by = auth.uid() OR
        EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role = 'admin')
    );

-- 6. Audit Logs Policies (Staff readable only; Insertable by service role/system)
CREATE POLICY "Audit logs viewable by operators and admins" 
    ON audit_logs FOR SELECT USING (
        auth.role() = 'service_role' OR 
        EXISTS (SELECT 1 FROM user_profiles WHERE id = auth.uid() AND role IN ('operator', 'admin'))
    );

CREATE POLICY "Audit logs insertable by system" 
    ON audit_logs FOR INSERT WITH CHECK (true);
