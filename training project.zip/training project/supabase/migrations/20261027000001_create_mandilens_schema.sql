-- ====================================================================
-- MandiLens PostgreSQL Migration: 20261027000001_create_mandilens_schema.sql
-- Description: Core schema for MandiLens Market Price Comparison & Decision Log
-- ====================================================================

-- 1. Enable UUID Extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. Drop existing tables if re-running in development
DROP TABLE IF EXISTS audit_logs CASCADE;
DROP TABLE IF EXISTS selling_decisions CASCADE;
DROP TABLE IF EXISTS market_prices CASCADE;
DROP TABLE IF EXISTS mandis CASCADE;
DROP TABLE IF EXISTS crops CASCADE;
DROP TABLE IF EXISTS user_profiles CASCADE;

-- 3. User Profiles (Mirrors Supabase auth.users or standalone auth)
CREATE TABLE user_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member', 'operator', 'admin')),
    phone TEXT,
    hub_location TEXT DEFAULT 'Karnal, Haryana',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 4. Crops Master Table
CREATE TABLE crops (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT UNIQUE NOT NULL,
    hindi_name TEXT NOT NULL,
    category TEXT NOT NULL CHECK (category IN ('Cereals', 'Pulses', 'Oilseeds', 'Vegetables', 'Fruits', 'Spices', 'Fiber/Cash')),
    standard_unit TEXT NOT NULL DEFAULT 'Quintal' CHECK (standard_unit IN ('Quintal', 'Tonne', 'Kg', '50kg Bag', 'Crate')),
    standard_moisture_pct NUMERIC(5,2) DEFAULT 12.00 CHECK (standard_moisture_pct >= 0 AND standard_moisture_pct <= 100),
    active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 5. Mandis (APMC Markets) Master Table
CREATE TABLE mandis (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    state TEXT NOT NULL,
    district TEXT NOT NULL,
    standard_cess_pct NUMERIC(5,2) NOT NULL DEFAULT 1.00 CHECK (standard_cess_pct >= 0 AND standard_cess_pct <= 10.00),
    commission_agent_pct NUMERIC(5,2) NOT NULL DEFAULT 2.00 CHECK (commission_agent_pct >= 0 AND commission_agent_pct <= 10.00),
    hamali_fee_per_unit NUMERIC(8,2) NOT NULL DEFAULT 12.00 CHECK (hamali_fee_per_unit >= 0),
    weighment_fee_per_unit NUMERIC(8,2) NOT NULL DEFAULT 3.00 CHECK (weighment_fee_per_unit >= 0),
    default_distance_km NUMERIC(8,2) NOT NULL DEFAULT 35.00 CHECK (default_distance_km >= 0),
    active BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 6. Market Prices Table
CREATE TABLE market_prices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    crop_id UUID NOT NULL REFERENCES crops(id) ON DELETE CASCADE,
    mandi_id UUID NOT NULL REFERENCES mandis(id) ON DELETE CASCADE,
    price_date DATE NOT NULL DEFAULT CURRENT_DATE,
    quality_grade TEXT NOT NULL CHECK (quality_grade IN ('Grade A / FAQ', 'Grade B', 'Grade C', 'Export Quality', 'Organic Certified')),
    min_price NUMERIC(10,2) NOT NULL CHECK (min_price > 0),
    modal_price NUMERIC(10,2) NOT NULL CHECK (modal_price >= min_price),
    max_price NUMERIC(10,2) NOT NULL CHECK (max_price >= modal_price),
    unit TEXT NOT NULL DEFAULT 'Quintal' CHECK (unit IN ('Quintal', 'Tonne', 'Kg', '50kg Bag', 'Crate')),
    data_source TEXT NOT NULL CHECK (data_source IN ('manual_entry', 'market_survey', 'seeded_demo', 'verified_live_api')),
    verified BOOLEAN NOT NULL DEFAULT false,
    verified_by UUID REFERENCES user_profiles(id) ON DELETE SET NULL,
    distance_km NUMERIC(8,2) NOT NULL DEFAULT 0.0 CHECK (distance_km >= 0),
    transport_estimate_per_unit NUMERIC(10,2) NOT NULL DEFAULT 0.0 CHECK (transport_estimate_per_unit >= 0),
    commission_pct_applied NUMERIC(5,2) NOT NULL DEFAULT 2.00 CHECK (commission_pct_applied >= 0),
    labor_fee_per_unit_applied NUMERIC(8,2) NOT NULL DEFAULT 12.00 CHECK (labor_fee_per_unit_applied >= 0),
    cess_pct_applied NUMERIC(5,2) NOT NULL DEFAULT 1.00 CHECK (cess_pct_applied >= 0),
    estimated_net_realization NUMERIC(10,2) NOT NULL,
    notes TEXT,
    created_by UUID REFERENCES user_profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT uq_crop_mandi_date_grade_source UNIQUE (crop_id, mandi_id, price_date, quality_grade, data_source)
);

-- 7. Selling Decisions Table
CREATE TABLE selling_decisions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lot_reference TEXT UNIQUE NOT NULL,
    crop_id UUID NOT NULL REFERENCES crops(id) ON DELETE RESTRICT,
    quantity NUMERIC(10,2) NOT NULL CHECK (quantity > 0),
    unit TEXT NOT NULL DEFAULT 'Quintal' CHECK (unit IN ('Quintal', 'Tonne', 'Kg', '50kg Bag', 'Crate')),
    quality_grade TEXT NOT NULL,
    harvest_date DATE,
    chosen_mandi_id UUID NOT NULL REFERENCES mandis(id) ON DELETE RESTRICT,
    status TEXT NOT NULL DEFAULT 'PLANNED' CHECK (status IN ('PLANNED', 'IN_TRANSIT', 'EXECUTED', 'SETTLED', 'CANCELLED')),
    expected_gross_price NUMERIC(10,2) NOT NULL CHECK (expected_gross_price > 0),
    expected_freight_cost NUMERIC(10,2) NOT NULL DEFAULT 0.0 CHECK (expected_freight_cost >= 0),
    expected_commission_fee NUMERIC(10,2) NOT NULL DEFAULT 0.0 CHECK (expected_commission_fee >= 0),
    expected_handling_fee NUMERIC(10,2) NOT NULL DEFAULT 0.0 CHECK (expected_handling_fee >= 0),
    expected_net_price_per_unit NUMERIC(10,2) NOT NULL,
    expected_total_net_realization NUMERIC(12,2) NOT NULL,
    alternative_mandis_evaluated JSONB DEFAULT '[]'::jsonb,
    decision_rationale TEXT NOT NULL,
    buyer_name TEXT,
    commission_agent_name TEXT,
    actual_sale_date DATE,
    actual_gross_price NUMERIC(10,2) CHECK (actual_gross_price IS NULL OR actual_gross_price > 0),
    actual_freight_cost NUMERIC(10,2) CHECK (actual_freight_cost IS NULL OR actual_freight_cost >= 0),
    actual_commission_fee NUMERIC(10,2) CHECK (actual_commission_fee IS NULL OR actual_commission_fee >= 0),
    actual_handling_fee NUMERIC(10,2) CHECK (actual_handling_fee IS NULL OR actual_handling_fee >= 0),
    actual_net_price_per_unit NUMERIC(10,2),
    actual_total_net_realization NUMERIC(12,2),
    variance_net_revenue NUMERIC(12,2),
    settlement_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (settlement_status IN ('PENDING', 'PARTIAL', 'RECEIVED')),
    payment_mode TEXT CHECK (payment_mode IN ('CASH', 'NEFT_RTGS', 'UPI', 'CHEQUE', 'APMC_PORTAL', NULL)),
    created_by UUID REFERENCES user_profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 8. Audit Logs Table
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES user_profiles(id) ON DELETE SET NULL,
    role TEXT NOT NULL DEFAULT 'member',
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    ip_address TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- 9. Performance Indexes
CREATE INDEX idx_prices_crop_date ON market_prices (crop_id, price_date DESC);
CREATE INDEX idx_prices_mandi_date ON market_prices (mandi_id, price_date DESC);
CREATE INDEX idx_prices_source ON market_prices (data_source);
CREATE INDEX idx_prices_verified ON market_prices (verified);
CREATE INDEX idx_decisions_status ON selling_decisions (status);
CREATE INDEX idx_decisions_crop ON selling_decisions (crop_id);
CREATE INDEX idx_decisions_user ON selling_decisions (created_by);
CREATE INDEX idx_audit_created ON audit_logs (created_at DESC);
