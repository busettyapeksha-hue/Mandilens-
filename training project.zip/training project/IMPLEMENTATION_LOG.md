# MandiLens — Implementation Log & Project Blueprint

**Project Name:** MandiLens — Crop-Wise Market Price Comparison and Selling Decision Log  
**Current Timestamp:** 2026-10-27T19:22:00+05:30  
**Repository State:** Fully runnable and verified application. Complete end-to-end user workflows, REST API, dual-mode Supabase PostgreSQL engine, responsive frontend workspace, 21 automated tests passing (0 failures).

---

## 1. Project Overview & Architectural Vision

MandiLens is a dedicated agricultural market intelligence and decision journal workspace for farmers, farmer producer organizations (FPOs), and mandi traders. It solves the critical problem of nominal vs. net price realization:
- High headline mandi prices frequently deceive sellers because of undisclosed transport freight, handling/hamali charges, weighment fees, and mandi commission/cess.
- MandiLens provides instant side-by-side Net Realization Calculations and records Selling Decisions with real execution tracking, variance analysis, and rationales.
- All dynamic metrics and summaries are calculated strictly from persisted records.

---

## 2. Phase Breakdown & Execution Plan

| Phase | Description | Status |
|---|---|---|
| **Phase 0** | Workspace audit, environment readiness, implementation log & technical blueprint | **COMPLETED** |
| **Phase 1** | System specifications, role matrix, API contracts, entity modeling, and business rules | **COMPLETED** |
| **Phase 2** | Supabase PostgreSQL schema, migrations, constraints, indexes, RLS, and deterministic seeds | **COMPLETED** |
| **Phase 3** | Backend Express API: modular routes, controllers, services, middleware, validation, error handling, rate limiting | **COMPLETED** |
| **Phase 4** | Distinctive agricultural market design system: semantic HTML5, CSS3 variables, accessible components, charts | **COMPLETED** |
| **Phase 5** | Core workflow integration: Price CRUD, Realization Calculator, Selling Decision Journal, Audit & Reports | **COMPLETED** |
| **Phase 6** | Automated test suite: unit tests, API route tests, validation tests, role permission checks, edge cases | **COMPLETED** |
| **Phase 7** | Security audit, performance review, UI responsiveness validation, bug fixes | **COMPLETED** |
| **Phase 8** | Local server launch verification, health check, documentation, and live status reporting | **COMPLETED** |

---

## 3. Technology Stack & Key Dependencies

- **Runtime:** Node.js (v20+)
- **Server Framework:** Express.js 4.x (ES Modules)
- **Database:** Supabase PostgreSQL with official `@supabase/supabase-js` client & safe in-memory fallback sandbox
- **Security & Middleware:** `helmet` (CSP, HSTS, NoSniff), `cors`, `express-rate-limit` (standard & sensitive write limiters), `morgan`
- **Validation:** Standardized schema validation with strict numeric bounds & sanitization (`src/validators/schemaValidators.js`)
- **Frontend:** Semantic HTML5, CSS3 Custom Properties (CSS Grid/Flexbox), Vanilla ES6+ JavaScript (zero build step required, instant loading)
- **Testing:** Node.js native test runner (`node:test`, `node:assert`) and Supertest (`supertest`) for HTTP endpoint verification

---

## 4. Entity Schema & Migrations

1. `user_profiles`:
   - Attributes: `id` (UUID PK), `email`, `full_name`, `role` (`member`, `operator`, `admin`), `phone`, `hub_location`, timestamps.
2. `crops`:
   - Attributes: `id` (UUID PK), `name` (unique), `hindi_name`, `category`, `standard_unit`, `standard_moisture_pct`, `active`, timestamps.
3. `mandis`:
   - Attributes: `id` (UUID PK), `name`, `code` (unique), `state`, `district`, `standard_cess_pct`, `commission_agent_pct`, `hamali_fee_per_unit`, `weighment_fee_per_unit`, `default_distance_km`, `active`, timestamps.
4. `market_prices`:
   - Attributes: `id` (UUID PK), `crop_id` (FK), `mandi_id` (FK), `price_date`, `quality_grade`, `min_price`, `modal_price`, `max_price`, `unit`, `data_source` (`manual_entry`, `market_survey`, `seeded_demo`, `verified_live_api`), `verified`, `verified_by` (FK), `distance_km`, `transport_estimate_per_unit`, `commission_pct_applied`, `labor_fee_per_unit_applied`, `cess_pct_applied`, `estimated_net_realization`, `notes`, `created_by` (FK), timestamps.
   - Constraint: `uq_crop_mandi_date_grade_source UNIQUE (crop_id, mandi_id, price_date, quality_grade, data_source)`.
5. `selling_decisions`:
   - Attributes: `id` (UUID PK), `lot_reference` (unique), `crop_id` (FK), `quantity`, `unit`, `quality_grade`, `harvest_date`, `chosen_mandi_id` (FK), `status` (`PLANNED`, `IN_TRANSIT`, `EXECUTED`, `SETTLED`, `CANCELLED`), `expected_gross_price`, `expected_freight_cost`, `expected_commission_fee`, `expected_handling_fee`, `expected_net_price_per_unit`, `expected_total_net_realization`, `alternative_mandis_evaluated` (JSONB), `decision_rationale`, `buyer_name`, `commission_agent_name`, `actual_sale_date`, `actual_gross_price`, `actual_freight_cost`, `actual_commission_fee`, `actual_handling_fee`, `actual_net_price_per_unit`, `actual_total_net_realization`, `variance_net_revenue`, `settlement_status` (`PENDING`, `PARTIAL`, `RECEIVED`), `payment_mode`, `created_by` (FK), timestamps.
6. `audit_logs`:
   - Attributes: `id` (UUID PK), `user_id` (FK), `role`, `action`, `entity_type`, `entity_id`, `details` (JSONB), `ip_address`, `created_at`.

---

## 5. Detailed Phase Tracking & Implementation Log

### Phase 0: Workspace Audit & Blueprint
- **Timestamp:** 2026-10-27 15:30
- Verified Node.js v20.18.0 and npm v10.8.2.
- Clean directory layout confirmed: `public/`, `src/`, `supabase/migrations/`, `tests/`, `scripts/`.
- Ensured `.env.example` contains only safe placeholder templates.

### Phase 1: User Journeys & Business Contracts
- Defined complete user journey:
  1. Farmer searches current price quotes across nearby APMC mandis.
  2. Farmer inputs harvest volume into Net Realization Calculator.
  3. System applies statutory cess, distance-based freight, and commission deductions to rank mandis by True Net Profit.
  4. Farmer commits to highest-profit mandi and creates a Planned Selling Decision lot with economic rationale.
  5. Field transit occurs (`PLANNED -> IN_TRANSIT`).
  6. Lot is auctioned at mandi yard; actual figures recorded (`IN_TRANSIT -> EXECUTED`).
  7. Payment settlement verified (`EXECUTED -> SETTLED`), generating audit log and revenue variance calculation.
  8. Dashboard dynamic KPI aggregations update immediately from persisted state.

### Phase 2: Supabase PostgreSQL Schema & Deterministic Seeds
- `supabase/migrations/20261027000001_create_mandilens_schema.sql` authored with normalized tables, foreign keys, cascade rules, and B-Tree indexes.
- `supabase/migrations/20261027000002_rls_and_security.sql` authored with Row Level Security (RLS) policies for user profiles, crops, mandis, market prices, selling decisions, and audit logs.
- `supabase/seed.sql` populated with authentic Indian agricultural commodity benchmarks (Wheat HD-2967, 1121 Basmati Paddy, Desi Chana, Sarson Mustard, Nashik Red Onion, Kufri Potato) and major APMC fee structures (Azadpur, Karnal, Khanna, Lasalgaon, Vashi, Neemuch, Gondal, Nizamabad).
- `scripts/seed.js` enhanced to support upserting all 5 core entity sets to Supabase PostgreSQL when configured.

### Phase 3: Modular Express REST API & Server-Side Security
- Express application configured with `helmet` Content Security Policy, strict origin headers, and `express-rate-limit`.
- Implemented role-aware authorization middleware (`src/middleware/auth.js`) supporting Member, Operator, and Admin personas.
- Input validation implemented in `src/validators/schemaValidators.js` ensuring `min_price <= modal_price <= max_price`, positive numeric bounds, and valid status transition rules.
- Centralized error handler with strict error sanitization (no internal stack leakages).

### Phase 4: Agricultural Market Design System
- Semantic, accessible HTML5 structure with high-contrast color palette: deep forest green (`#1b4332`), golden wheat (`#d97706`), crisp white panels, and emerald profit highlights.
- Clear status badges (`badge-planned`, `badge-transit`, `badge-executed`, `badge-settled`) and data source tags (`badge-manual`, `badge-survey`, `badge-seed`, `badge-live`).
- Responsive layouts built with CSS Grid and Flexbox for seamless desktop and mobile viewports.
- Pure SVG price spread and comparative realization bar chart with interactive crop switching.

### Phase 5: Workflow Integration & Realization Simulator
- Full CRUD for spot prices connected to Express endpoints with real-time net realization preview during entry.
- Net Realization Calculator simulator with customizable lot size, unit selection, and instant ranking banner displaying net profit advantage.
- 1-Click transfer from calculator recommendation to planned Selling Decision lot.
- Decision journal status modal allowing capture of actual auction prices, buyer names, aadathiya firms, payment modes, and computing profit variance.
- Role switcher widget enabling immediate in-browser switching between Kisan (Member), Mandi Operator, and APMC Director roles.

### Phase 6: Automated Testing & Verification
- Test suite executed using Node.js native test runner (`node:test`, `node:assert`, `supertest`).
- Expanded test suite from 16 to 21 automated tests covering:
  - System health and Helmet security headers
  - Master crops and mandis retrieval
  - Price validation consistency (`min <= modal <= max`)
  - Duplicate price quote prevention (`HTTP 409 Conflict`)
  - Net realization arithmetic verification
  - Selling decision lifecycle state transitions
  - Member role restrictions on audit logs
  - Admin-only role authorization for crop creation
  - Operator/Admin role authorization for mandi creation
  - Duplicate lot reference prevention (`HTTP 409 Conflict`)
  - Calculator custom fee overrides
  - Deterministic system reset
  - Remote Supabase integration boundary check
  - Frontend static asset integrity (`index.html`, `styles.css`, `app.js`)
  - End-to-end full farmer user journey

### Phase 7: Security Audit, Bug Fixes & Refinements
- **Fix 1:** Enhanced `src/services/db.js` so that `createMarketPrice`, `updateMarketPrice`, `deleteMarketPrice`, `createSellingDecision`, `updateDecisionStatus`, `deleteSellingDecision`, and `getAuditLogs` write to and sync with Supabase PostgreSQL whenever remote credentials are provided.
- **Fix 2:** Fixed asynchronous execution bug in `src/controllers/systemController.js` where `dbService.getAuditLogs` was called without `await`, ensuring audit log API responses always return an array.
- **Fix 3:** Updated `src/services/db.js` `compareMandis` method to accept both `override.labor_fee_per_unit` and `override.labor_per_unit` for flexible API input ergonomics.
- **Fix 4:** Enhanced `scripts/seed.js` to seed `user_profiles`, `crops`, `mandis`, `market_prices`, and `selling_decisions`.

### Phase 8: Verification & Delivery
- Executed `npm test`: **21 tests passing, 0 failing**.
- Executed `npm run seed`: **Deterministically reset database**.
- Executed `npm run lint`: **ES Modules syntax validated**.
- Authored production-ready `README.md` containing complete setup, architecture, migration, seed, test, and deployment guidelines.

### Phase 9: Remote Supabase PostgreSQL Live Connection & Verification
- Configured `.env` with live project credentials (`xgxtnevljlzjpmufzziy`).
- Identified and connected via Supabase Transaction Pooler (`aws-0-ap-northeast-1.pooler.supabase.com`).
- Applied database migrations:
  - `20261027000001_create_mandilens_schema.sql` (Tables: `user_profiles`, `crops`, `mandis`, `market_prices`, `selling_decisions`, `audit_logs`).
  - `20261027000002_rls_and_security.sql` (Row Level Security policies, indexes, and role boundaries).
- Adjusted seed ID formats to standard UUID hexadecimal compliance (`b2020202...`, `a3030303...`).
- Seeded live PostgreSQL database via `@supabase/supabase-js` client.
- Fixed `Thenable` promise error handling across Supabase queries in `src/services/db.js`.
- Executed full automated test suite with remote Supabase enabled: **21/21 tests passing (100% success)**.
- Restarted local server on `http://localhost:3000` with active Supabase connection confirmed (`Supabase PostgreSQL Connected: true`).

---

## 6. Verification Evidence (Supabase PostgreSQL Live Mode)

```
> mandilens@1.0.0 test
> node --test

TAP version 13
# [Database] Initialized official Supabase client for remote PostgreSQL.
# GET /api/health 200 12.306 ms - 269
# Subtest: GET /api/health returns operational status and database engine info
ok 1 - GET /api/health returns operational status and database engine info
ok 2 - Security headers are enforced by Helmet
ok 3 - GET /api/crops returns list of active monitored crops
ok 4 - GET /api/mandis returns list of APMC markets with cess and commission rates
ok 5 - POST /api/prices validates that min_price <= modal_price <= max_price
ok 6 - POST /api/prices creates a verified price record when submitted by Operator
ok 7 - POST /api/prices prevents duplicate submissions for the same crop, market, date, grade, and source
ok 8 - POST /api/calculator/compare computes net realization and ranks mandis by profit
ok 9 - Selling Decision Lifecycle: PLANNED -> IN_TRANSIT -> EXECUTED -> SETTLED with variance
ok 10 - Role Authorization: Member cannot access audit logs; Operator and Admin can
ok 11 - GET /api/analytics/dashboard computes metrics from persisted records
ok 12 - POST /api/crops enforces Admin-only role authorization
ok 13 - POST /api/mandis enforces Operator and Admin role authorization
ok 14 - POST /api/decisions prevents duplicate lot references
ok 15 - POST /api/calculator/compare handles custom fee overrides correctly
ok 16 - POST /api/system/reset-demo resets state to deterministic baseline
# [Integration Test] Live Supabase PostgreSQL query verified.
ok 17 - Remote Supabase PostgreSQL integration check
ok 18 - Frontend static assets: GET / serves index.html with valid semantic markup
ok 19 - Frontend static assets: GET /styles.css serves agricultural design stylesheet
ok 20 - Frontend static assets: GET /app.js serves vanilla JavaScript application code
ok 21 - End-to-end Farmer Journey: Price Log -> Comparative Calculator -> Decision Execution -> Dashboard Metrics
1..21
# tests 21
# suites 0
# pass 21
# fail 0
# cancelled 0
# skipped 0
# todo 0
```
