# MandiLens — Crop-Wise Market Price Comparison and Selling Decision Log

> **Empowering farmers, FPOs, and APMC traders with transparent net price realization, market comparison analytics, and an audit-ready selling decision journal.**

---

## 1. Executive Summary & Problem Context

In agricultural commodity trading across Indian APMCs (Agricultural Produce Market Committees), headline nominal prices are frequently deceptive. A market quoting ₹2,550/Quintal 120 km away may yield substantially lower net profit than a local mandi quoting ₹2,450/Quintal once transit freight, loading/unloading (hamali), weighment charges, statutory mandi cess, and commission agent (aadathiya) percentages are deducted.

**MandiLens** bridges this asymmetry by calculating **True Net Realization** in real time across multiple markets and providing a **Selling Decision Journal** to log trade rationales, monitor execution variance, and audit payment settlements.

---

## 2. Architecture & Design Principles

```
  ┌─────────────────────────────────────────────────────────────┐
  │                 Modern Browser Workspace                   │
  │     (Semantic HTML5, CSS Custom Properties, Vanilla JS)     │
  └──────────────────────────────┬──────────────────────────────┘
                                 │ HTTP / JSON (REST)
                                 ▼
  ┌─────────────────────────────────────────────────────────────┐
  │                   Node.js Express Server                    │
  │  ├── Security: Helmet (CSP, HSTS, NoSniff) & CORS Narrowing │
  │  ├── Rate Limiting: standardLimiter (300) & writeLimiter    │
  │  ├── RBAC & Middleware: Member, Operator, Admin Auth Check  │
  │  ├── Schema Validators: Strict numeric consistency checks    │
  │  └── Mathematical Engine: Net Realization & Fee Deductions  │
  └──────────────────────────────┬──────────────────────────────┘
                                 │
                 ┌───────────────┴───────────────┐
                 ▼                               ▼
  ┌─────────────────────────────┐ ┌─────────────────────────────┐
  │    Supabase PostgreSQL      │ │   Safe Local In-Memory      │
  │      (Remote Database)      │ │     Repository Sandbox      │
  │  • Foreign Keys & Constraints│ │  • Zero-config local run   │
  │  • Row Level Security (RLS) │ │  • Deterministic baseline   │
  │  • B-Tree Performance Index │ │  • Full parity fallback     │
  └─────────────────────────────┘ └─────────────────────────────┘
```

- **Server-Authoritative Business Logic:** The browser never writes directly to the database. All financial computations, transitions, validation bounds, and authorizations occur strictly on the Express backend.
- **Dual-Mode Persistence Architecture:** Seamlessly connects to remote **Supabase PostgreSQL** via official client libraries when credentials are configured. In offline or development modes without external credentials, MandiLens automatically runs its high-fidelity in-memory repository with zero mock compromises.
- **Dynamic Aggregation Guarantee:** All dashboard metrics, pipeline counts, volume calculations, and realization numbers are computed dynamically from persisted records. No hardcoded counters.
- **Clear Data Provenance:** Every price quote and transaction is explicitly tagged: `manual_entry`, `market_survey`, `seeded_demo`, or `verified_live_api`.

---

## 3. Core Functional Workflows

### 3.1. Market Price Exploration & CRUD Management
- **Create:** Farmers, traders, or survey staff log spot prices with quality grades (`Grade A / FAQ`, `Grade B`, `Grade C`, `Export Quality`, `Organic Certified`), price ranges (min, modal, max), units (`Quintal`, `Tonne`, `50kg Bag`, `Crate`), and verified field notes.
- **Read & Filter:** Instant multi-parameter filtering by search term, crop, mandi, verification state, and data provenance.
- **Update & Delete:** Role-governed edit and deletion with confirmation protections (Admins/Operators can manage any; Members can manage their own submissions).
- **Price Consistency Rule:** Enforces strict constraint `min_price <= modal_price <= max_price`.
- **Duplicate Protection:** Prevents duplicate quotes for the same crop, market, date, grade, and source.

### 3.2. Net Realization Comparative Simulator
- Evaluates candidate APMC markets side-by-side for a specified crop and lot quantity.
- Deducts distance-based freight, aadathiya commissions, APMC statutory cess, and hamali/weighment labor fees.
- Ranks mandis by **True Net Return (₹/Unit)** and **Total Lot Realization (₹)**.
- Visual stacked breakdown illustrates where deductions occur across logistics, commissions, and taxes.
- **1-Click Conversion:** Allows exporting the top-ranked recommendation directly into a planned Selling Decision lot.

### 3.3. Selling Decision Journal & Lifecycle Tracker
- **Planned:** Records lot reference, target market, expected gross and net prices, and economic rationale for market selection.
- **In-Transit:** Marks crop lot as dispatched from farm/storage to the target yard.
- **Executed:** Records auction sale date, actual gross price achieved, actual freight paid, buyer name, and aadathiya firm.
- **Settled:** Records payment mode (`NEFT_RTGS`, `UPI`, `CHEQUE`, `CASH`, `APMC_PORTAL`), payment receipt status, and computes **Net Variance (Actual vs. Planned)**.
- **Status Machine:** Enforces valid lifecycle transitions: `PLANNED -> IN_TRANSIT -> EXECUTED -> SETTLED`. Prevents illegal transitions (e.g. transitioning settled records directly back to planned).

### 3.4. Role-Aware Access Control (RBAC)
- **Kisan / Member (`member`):** Submit spot quotes, simulate returns, track own lots and decisions, view market directory.
- **Mandi Operator (`operator`):** Verify field quotes, record market survey data, access system audit trail, add mandi profiles.
- **APMC Director (`admin`):** Full configuration governance, master crop creation, system reset to deterministic seeds, and audit review.

---

## 4. Technology Stack

- **Backend:** Node.js (v20+ ES Modules), Express 4.x
- **Database:** Supabase PostgreSQL (`@supabase/supabase-js`)
- **Security:** `helmet`, `cors`, `express-rate-limit`
- **Frontend:** Semantic HTML5, CSS3 Custom Properties (CSS Grid/Flexbox), Vanilla ES6+ JavaScript
- **Test Framework:** Node.js Test Runner (`node:test`, `node:assert`), `supertest`

---

## 5. Directory Structure

```
mandilens/
├── .env.example                               # Environment template with placeholders
├── .gitignore                                 # Git ignore rules
├── package.json                               # Dependencies and npm scripts
├── README.md                                  # Comprehensive setup & operational guide
├── IMPLEMENTATION_LOG.md                      # Audit evidence, phase milestones, verification
├── public/                                    # Vanilla Frontend (No build step required)
│   ├── index.html                             # Semantic HTML5 single-page application
│   ├── styles.css                             # Custom agricultural theme design system
│   └── app.js                                 # Client state, reactive forms, API bridge, SVG charts
├── src/
│   ├── server.js                              # HTTP server entry point & graceful shutdown
│   ├── app.js                                 # Express application configuration & middleware
│   ├── config/
│   │   └── database.js                        # Supabase client initialization & connection health
│   ├── controllers/
│   │   ├── masterDataController.js            # Crops and mandis REST handlers
│   │   ├── pricesController.js                # Spot price CRUD handlers
│   │   ├── calculatorController.js            # Net realization simulation handler
│   │   ├── decisionsController.js             # Decision journal lifecycle handlers
│   │   ├── analyticsController.js             # Persisted KPI aggregation handler
│   │   └── systemController.js                # Health, audit logs, reset endpoints
│   ├── middleware/
│   │   ├── auth.js                            # Role extraction & permission enforcement
│   │   └── errorHandler.js                    # Centralized error formatting & sanitization
│   ├── services/
│   │   └── db.js                              # Database service facade & in-memory fallback
│   └── validators/
│       └── schemaValidators.js                # Input schema & business rule validators
├── supabase/
│   ├── seed.sql                               # Deterministic SQL seed data
│   └── migrations/
│       ├── 20261027000001_create_mandilens_schema.sql  # Core normalized DDL schema
│       └── 20261027000002_rls_and_security.sql         # Row Level Security (RLS) policies
├── scripts/
│   └── seed.js                                # Deterministic database seeder script
└── tests/
    ├── api.test.js                            # Comprehensive REST API & RBAC test suite
    └── frontend_integration.test.js           # Static asset delivery & end-to-end user journeys
```

---

## 6. Installation & Local Setup

### Prerequisites
- **Node.js** >= v20.0.0
- **npm** >= v10.0.0
- (Optional) **Supabase Project** with PostgreSQL database

### Step 1: Clone and Install Dependencies
```bash
git clone <repository-url>
cd "training project"
npm install
```

### Step 2: Configure Environment Variables
Copy `.env.example` to create your local `.env`:
```bash
cp .env.example .env
```
Edit `.env` as appropriate:
```ini
PORT=3000
NODE_ENV=development
APP_ORIGIN=http://localhost:3000

# To run with Remote Supabase PostgreSQL:
SUPABASE_URL=https://your-project-id.supabase.co
SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Market Data API (Optional external feed)
MARKET_DATA_API_KEY=
MARKET_DATA_API_ENDPOINT=
```
*Note: If `SUPABASE_URL` is omitted or left as a placeholder, MandiLens automatically runs in Safe Local Storage mode without any errors.*

### Step 3: Run Database Migrations (Supabase PostgreSQL)
When using a live Supabase project, execute the migration scripts located in `supabase/migrations/`:
1. In the Supabase Dashboard, navigate to the **SQL Editor**.
2. Run `supabase/migrations/20261027000001_create_mandilens_schema.sql` to generate tables, indices, and constraints.
3. Run `supabase/migrations/20261027000002_rls_and_security.sql` to configure Row Level Security policies.

### Step 4: Populate Seed Data
To populate the database with authentic benchmark agricultural records:
```bash
npm run seed
```
This inserts:
- **4 User Profiles** (Farmer Ramesh, FPO Lead Sunita, Mandi Surveyor Rajesh, APMC Admin Devendra)
- **10 Core Monitored Crops** (Wheat, Basmati Paddy, Desi Chana, Mustard, Soybean, Nashik Onion, etc.)
- **8 Major APMC Mandis** (Azadpur, Karnal, Khanna, Lasalgaon, Vashi, Neemuch, Gondal, Nizamabad)
- **8 Market Price Quotes** with detailed fee breakdowns
- **4 Selling Decisions** spanning Planned, Executed, and Settled lots

### Step 5: Start the Application
```bash
# Production Start
npm start

# Development Start (with file watcher)
npm run dev
```

Visit the application in your browser:
```
http://localhost:3000
```

---

## 7. Verification & Automated Testing

MandiLens includes an automated test suite executed via Node.js native test runner:

```bash
npm test
```

### Test Coverage Breakdown:
1. **System Health & Security Headers:** Verifies operational status, Content Security Policy, and X-Content-Type-Options via Helmet.
2. **Master Data Retrieval:** Verifies crop and mandi master registries.
3. **Price Validation & Consistency:** Verifies bounds (`min <= modal <= max`), negative rejection, and required attributes.
4. **Duplicate Submission Protection:** Asserts that duplicate price quotes for the same crop, market, date, grade, and source return `HTTP 409 Conflict`.
5. **Net Realization Math:** Tests accurate deduction of freight, hamali, cess, and agent commissions.
6. **Selling Decision Lifecycle:** Verifies state machine transitions (`PLANNED -> IN_TRANSIT -> EXECUTED -> SETTLED`) and variance calculations.
7. **Role-Based Authorization:** Verifies that Members cannot access administrative audit logs while Operators and Admins can.
8. **Admin-Only Operations:** Verifies that only Admins can create new crop entities.
9. **Operator & Admin Mandi Governance:** Verifies that Members cannot create new mandi entries.
10. **Duplicate Lot References:** Verifies that duplicate decision lot identifiers return `HTTP 409 Conflict`.
11. **Calculator Fee Overrides:** Verifies that custom simulated transport and labor overrides compute as expected.
12. **Persisted Analytics Aggregations:** Tests dynamic calculation of revenue, total volume, and quote counts.
13. **Frontend Static Asset Delivery:** Tests HTTP serving of semantic `index.html`, `styles.css`, and `app.js`.
14. **End-to-End Farmer User Journey:** Simulates spot quote recording -> simulation run -> decision planning -> execution with actual receipt -> dashboard metric validation -> audit verification.

---

## 8. REST API Reference

| Endpoint | Method | Allowed Roles | Description |
|---|---|---|---|
| `/api/health` | `GET` | All | System operational status, DB engine info, user profile |
| `/api/crops` | `GET` | All | Master list of monitored crops and benchmarks |
| `/api/crops` | `POST` | `admin` | Create new monitored crop specification |
| `/api/mandis` | `GET` | All | List of APMC markets with statutory fee rates |
| `/api/mandis` | `POST` | `operator`, `admin` | Register a new APMC mandi profile |
| `/api/mandis/:id` | `PATCH` | `operator`, `admin` | Update mandi fee schedules or distances |
| `/api/prices` | `GET` | All | Filter and list market price quotes |
| `/api/prices/:id` | `GET` | All | Detailed quote breakdown with fee deductions |
| `/api/prices` | `POST` | All | Record spot price quote (Rate limited) |
| `/api/prices/:id` | `PUT` | Owner, `operator`, `admin` | Update spot price quote |
| `/api/prices/:id` | `DELETE` | Owner, `admin` | Delete spot price quote |
| `/api/calculator/compare` | `POST` | All | Compute comparative net returns across all mandis |
| `/api/decisions` | `GET` | Role-filtered | List selling decision journal records |
| `/api/decisions/:id` | `GET` | Role-filtered | Get individual selling decision record |
| `/api/decisions` | `POST` | All | Create a planned selling decision lot |
| `/api/decisions/:id/status` | `PATCH` | Owner, `operator`, `admin` | Transition lot status (`IN_TRANSIT`, `EXECUTED`, `SETTLED`) |
| `/api/decisions/:id` | `DELETE` | Owner, `admin` | Delete decision lot |
| `/api/analytics/dashboard` | `GET` | All | Aggregated KPI metrics computed from database |
| `/api/audit-logs` | `GET` | `operator`, `admin` | System audit trail entries |
| `/api/system/reset-demo` | `POST` | `operator`, `admin` | Deterministically reset database to seed baseline |

---

## 9. Security & Production Guardrails

- **Parameter Redaction:** No database passwords, service-role keys, or tokens are logged or returned to client responses.
- **Strict Content Security Policy:** Nonce-free origin enforcement restricting external scripts and blocking injection vectors.
- **Rate Limiting:** Prevents denial-of-service and brute-force submissions on sensitive write endpoints.
- **Row Level Security (RLS):** Supabase database policies restrict anonymous mutations and isolate member records.
- **Disclosed Disclaimers:** Clearly differentiates between manual entries, field surveys, seeded demo data, and live verified feeds.

---

## 10. License
Distributed under the **MIT License**. Created by the MandiLens Engineering Team.
